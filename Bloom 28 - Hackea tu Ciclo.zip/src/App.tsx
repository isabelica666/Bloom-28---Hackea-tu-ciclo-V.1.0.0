import { useState } from 'react';
import { Home, Calendar, Activity, Lightbulb, Smartphone } from 'lucide-react';
import { Onboarding } from './components/Onboarding';
import { Dashboard } from './components/Dashboard';
import { Symptoms } from './components/Symptoms';
import { PeriodHistory } from './components/PeriodHistory';
import { StartPeriod } from './components/StartPeriod';
import { CycleCalendar } from './components/CycleCalendar';
import { BiometricData } from './components/BiometricData';
import { TemperatureDetail } from './components/TemperatureDetail';
import { HeartRateDetail } from './components/HeartRateDetail';
import { SleepQualityDetail } from './components/SleepQualityDetail';
import { Recommendations } from './components/Recommendations';
import { NutritionDetail } from './components/NutritionDetail';
import { Community } from './components/Community';
import { DeviceConnection } from './components/DeviceConnection';
import { ClassPassIntegration } from './components/ClassPassIntegration';
import { StravaIntegration } from './components/StravaIntegration';
import { BottomNavigation } from './components/BottomNavigation';
import { UserProfile } from './components/UserProfile';
import type { CycleData } from './utils/cycleCalculations';

type ScreenType = 'onboarding' | 'app';
type TabType = 'dashboard' | 'calendar' | 'data' | 'recommendations' | 'community' | 'devices';

export default function App() {
  const [currentScreen, setCurrentScreen] = useState<ScreenType>('onboarding');
  const [activeTab, setActiveTab] = useState<TabType>('dashboard');
  const [cycleData, setCycleData] = useState<CycleData | null>(null);
  const [showSymptoms, setShowSymptoms] = useState(false);
  const [showPeriodHistory, setShowPeriodHistory] = useState(false);
  const [showStartPeriod, setShowStartPeriod] = useState(false);
  const [showTemperatureDetail, setShowTemperatureDetail] = useState(false);
  const [showHeartRateDetail, setShowHeartRateDetail] = useState(false);
  const [showSleepDetail, setShowSleepDetail] = useState(false);
  const [showNutritionDetail, setShowNutritionDetail] = useState(false);
  const [selectedNutrition, setSelectedNutrition] = useState<{ item: any; phase: string } | null>(null);
  const [userName, setUserName] = useState('');
  const [showClassPass, setShowClassPass] = useState(false);
  const [showStrava, setShowStrava] = useState(false);
  const [selectedActivity, setSelectedActivity] = useState('');
  const [showUserProfile, setShowUserProfile] = useState(false);

  // Función para manejar clicks en ejercicios
  const handleExerciseClick = (exerciseType: string) => {
    setSelectedActivity(exerciseType);
    
    // Determinar si va a ClassPass o Strava
    const stravaActivities = ['Running', 'Caminata ligera', 'Caminata moderada', 'Natación'];
    const isStravaActivity = stravaActivities.some(activity => 
      exerciseType.toLowerCase().includes(activity.toLowerCase())
    );
    
    if (isStravaActivity) {
      setShowStrava(true);
    } else {
      setShowClassPass(true);
    }
  };

  // Onboarding screen
  if (currentScreen === 'onboarding') {
    return (
      <Onboarding
        onContinue={(name, cycleData) => {
          setUserName(name);
          setCycleData(cycleData);
          setCurrentScreen('app');
        }}
      />
    );
  }

  // Main app
  return (
    <div className="min-h-screen bg-[#fbeedc]">
      {/* Mobile Container */}
      <div className="max-w-md mx-auto bg-[#fbeedc] min-h-screen shadow-2xl relative">
        {/* Content Area */}
        {!showSymptoms && !showPeriodHistory && !showStartPeriod && !showTemperatureDetail && !showHeartRateDetail && !showSleepDetail && !showNutritionDetail && !showClassPass && !showStrava && !showUserProfile && (
          <main className="pb-20">
            {activeTab === 'dashboard' && cycleData && (
              <Dashboard 
                cycleData={cycleData}
                userName={userName}
                onSymptomsClick={() => setShowSymptoms(true)} 
                onPeriodClick={() => setShowPeriodHistory(true)}
                onStartPeriodClick={() => setShowStartPeriod(true)}
                onTemperatureClick={() => setShowTemperatureDetail(true)}
                onHeartRateClick={() => setShowHeartRateDetail(true)}
                onSleepClick={() => setShowSleepDetail(true)}
                onProfileClick={() => setShowUserProfile(true)}
              />
            )}
            {activeTab === 'dashboard' && !cycleData && (
              <div className="flex items-center justify-center min-h-screen">
                <p className="text-[#130b3d]">No cycle data available</p>
              </div>
            )}
            {activeTab === 'calendar' && cycleData && <CycleCalendar cycleData={cycleData} />}
            {activeTab === 'calendar' && !cycleData && (
              <div className="flex items-center justify-center min-h-screen">
                <p className="text-[#130b3d]">No cycle data available</p>
              </div>
            )}
            {activeTab === 'data' && cycleData && (
              <BiometricData 
                cycleData={cycleData} 
                onTemperatureClick={() => setShowTemperatureDetail(true)}
                onHeartRateClick={() => setShowHeartRateDetail(true)}
                onSleepClick={() => setShowSleepDetail(true)}
              />
            )}
            {activeTab === 'data' && !cycleData && (
              <div className="flex items-center justify-center min-h-screen">
                <p className="text-[#130b3d]">No cycle data available</p>
              </div>
            )}
            {activeTab === 'recommendations' && cycleData && (
              <Recommendations 
                cycleData={cycleData}
                onNutritionClick={(item, phase) => {
                  setSelectedNutrition({ item, phase });
                  setShowNutritionDetail(true);
                }}
                onExerciseClick={handleExerciseClick}
              />
            )}
            {activeTab === 'recommendations' && !cycleData && (
              <div className="flex items-center justify-center min-h-screen">
                <p className="text-[#130b3d]">No cycle data available</p>
              </div>
            )}
            {activeTab === 'community' && cycleData && <Community cycleData={cycleData} />}
            {activeTab === 'community' && !cycleData && (
              <div className="flex items-center justify-center min-h-screen">
                <p className="text-[#130b3d]">No cycle data available</p>
              </div>
            )}
            {activeTab === 'devices' && <DeviceConnection />}
          </main>
        )}

        {/* Symptoms Screen - Overlay */}
        {showSymptoms && (
          <div className="absolute inset-0 z-50">
            <Symptoms onBack={() => setShowSymptoms(false)} />
          </div>
        )}

        {/* Period History Screen - Overlay */}
        {showPeriodHistory && (
          <div className="absolute inset-0 z-50">
            <PeriodHistory onBack={() => setShowPeriodHistory(false)} />
          </div>
        )}

        {/* Start Period Screen - Overlay */}
        {showStartPeriod && (
          <div className="absolute inset-0 z-50">
            <StartPeriod 
              onBack={() => setShowStartPeriod(false)}
              onSave={(date) => {
                // Actualizar cycleData con la nueva fecha
                if (cycleData) {
                  setCycleData({
                    ...cycleData,
                    lastPeriodStart: date
                  });
                }
              }}
            />
          </div>
        )}

        {/* Temperature Detail Screen - Overlay */}
        {showTemperatureDetail && cycleData && (
          <div className="absolute inset-0 z-50">
            <TemperatureDetail cycleData={cycleData} onBack={() => setShowTemperatureDetail(false)} />
          </div>
        )}

        {/* Heart Rate Detail Screen - Overlay */}
        {showHeartRateDetail && cycleData && (
          <div className="absolute inset-0 z-50">
            <HeartRateDetail cycleData={cycleData} onBack={() => setShowHeartRateDetail(false)} />
          </div>
        )}

        {/* Sleep Quality Detail Screen - Overlay */}
        {showSleepDetail && cycleData && (
          <div className="absolute inset-0 z-50">
            <SleepQualityDetail cycleData={cycleData} onBack={() => setShowSleepDetail(false)} />
          </div>
        )}

        {/* Nutrition Detail Screen - Overlay */}
        {showNutritionDetail && selectedNutrition && (
          <div className="absolute inset-0 z-50">
            <NutritionDetail item={selectedNutrition.item} phase={selectedNutrition.phase} onBack={() => setShowNutritionDetail(false)} />
          </div>
        )}

        {/* ClassPass Integration - Overlay */}
        {showClassPass && (
          <div className="absolute inset-0 z-50">
            <ClassPassIntegration activityType={selectedActivity} onBack={() => setShowClassPass(false)} />
          </div>
        )}

        {/* Strava Integration - Overlay */}
        {showStrava && (
          <div className="absolute inset-0 z-50">
            <StravaIntegration activityType={selectedActivity} onBack={() => setShowStrava(false)} />
          </div>
        )}

        {/* User Profile - Overlay */}
        {showUserProfile && (
          <UserProfile userName={userName} onClose={() => setShowUserProfile(false)} />
        )}

        {/* Bottom Navigation */}
        {!showSymptoms && !showPeriodHistory && !showStartPeriod && !showTemperatureDetail && !showHeartRateDetail && !showSleepDetail && !showNutritionDetail && !showClassPass && !showStrava && !showUserProfile && (
          <BottomNavigation
            activeTab={activeTab}
            onTabChange={setActiveTab}
          />
        )}
      </div>
    </div>
  );
}
import { useEffect } from 'react';
import svgPaths from "../imports/svg-s8tefs82e1";

interface SplashProps {
  onComplete: () => void;
}

export function Splash({ onComplete }: SplashProps) {
  useEffect(() => {
    const timer = setTimeout(() => {
      onComplete();
    }, 2500);

    return () => clearTimeout(timer);
  }, [onComplete]);

  return (
    <div className="bg-gradient-to-b from-[#ffe0c6] to-[#f5ebc3] overflow-clip relative min-h-screen w-full max-w-md mx-auto">
      {/* Home Indicator */}
      <div className="absolute bottom-0 h-[34px] left-1/2 translate-x-[-50%] w-[393px]">
        <div className="absolute h-[34px] left-0 right-0 top-0" />
        <div className="absolute bottom-[7.67px] flex h-[5px] items-center justify-center left-1/2 translate-x-[-50%] w-[139.938px]">
          <div className="flex-none rotate-[180deg] scale-y-[-100%]">
            <div className="bg-[#121212] h-[5px] rounded-[100px] w-[139.938px]" />
          </div>
        </div>
      </div>

      {/* Blur Effect 1 - Pink */}
      <div className="absolute flex inset-[6.34%_-28.87%_61.76%_66.92%] items-center justify-center">
        <div className="flex-none h-[186.378px] rotate-[226.129deg] skew-x-[6.174deg] w-[178.744px]">
          <div className="relative size-full">
            <div className="absolute inset-[-91.85%_-95.77%]">
              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 522 529">
                <g filter="url(#filter0_f_6_1741)" opacity="0.8">
                  <ellipse cx="260.561" cy="264.378" fill="#FD587A" fillOpacity="0.24" rx="89.3719" ry="93.1892" />
                </g>
                <defs>
                  <filter colorInterpolationFilters="sRGB" filterUnits="userSpaceOnUse" height="528.755" id="filter0_f_6_1741" width="521.121" x="0" y="0">
                    <feFlood floodOpacity="0" result="BackgroundImageFix" />
                    <feBlend in="SourceGraphic" in2="BackgroundImageFix" mode="normal" result="shape" />
                    <feGaussianBlur result="effect1_foregroundBlur_6_1741" stdDeviation="85.5943" />
                  </filter>
                </defs>
              </svg>
            </div>
          </div>
        </div>
      </div>

      {/* Blur Effect 2 - Purple */}
      <div className="absolute flex inset-[36.97%_55.73%_24.25%_-44.27%] items-center justify-center">
        <div className="flex-none h-[243.129px] rotate-[221.503deg] skew-x-[356.979deg] w-[236.982px]">
          <div className="relative size-full">
            <div className="absolute inset-[-65.43%_-67.13%]">
              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 556 562">
                <g filter="url(#filter0_f_6_1732)" opacity="0.8">
                  <ellipse cx="277.579" cy="280.652" fill="#C294EC" fillOpacity="0.44" rx="118.491" ry="121.564" />
                </g>
                <defs>
                  <filter colorInterpolationFilters="sRGB" filterUnits="userSpaceOnUse" height="561.304" id="filter0_f_6_1732" width="555.157" x="0" y="0">
                    <feFlood floodOpacity="0" result="BackgroundImageFix" />
                    <feBlend in="SourceGraphic" in2="BackgroundImageFix" mode="normal" result="shape" />
                    <feGaussianBlur result="effect1_foregroundBlur_6_1732" stdDeviation="79.5438" />
                  </filter>
                </defs>
              </svg>
            </div>
          </div>
        </div>
      </div>

      {/* Logo Group */}
      <div className="absolute contents leading-[normal] left-[65px] not-italic text-[#130b3d] text-nowrap top-[284px] whitespace-pre">
        <p className="absolute font-['Gebuk:Regular',sans-serif] left-[196.6px] text-[218.875px] text-center top-[284px] translate-x-[-50%]">
          8
        </p>
        <p className="absolute font-['Gebuk:Regular',sans-serif] left-[248.39px] text-[69.981px] top-[461.6px]">
          28
        </p>
        <p className="absolute font-['Cal_Sans:Regular',sans-serif] left-[65px] text-[62.456px] top-[456.67px]">
          Bloom
        </p>
      </div>

      {/* Loading Spinner */}
      <div className="absolute left-1/2 -translate-x-1/2 top-[560px] flex items-center justify-center">
        <div className="w-8 h-8 border-3 border-[#f58020] border-t-transparent rounded-full animate-spin" 
             style={{ borderWidth: '3px' }} />
      </div>

      {/* Disclaimer Text */}
      <div className="absolute bottom-[60px] left-0 right-0 px-8">
        <p className="font-['Inter:Regular',sans-serif] text-[11px] text-[#5250a2] text-center leading-[1.4]">
          Bloom 28 es una herramienta informativa y educativa. La aplicación no diagnostica, trata, cura ni previene ninguna enfermedad.
        </p>
      </div>

      {/* Status Bar */}
      <div className="absolute h-[44px] left-0 overflow-clip top-0 w-full max-w-[393px]">
        <div className="absolute h-[30px] left-1/2 top-[-2px] translate-x-[-50%] w-[219px]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 219 30">
            <path d={svgPaths.p7f98200} fill="#121212" />
          </svg>
        </div>
        <p className="absolute font-['SF_Pro_Text:Semibold',sans-serif] leading-[21px] left-[32px] not-italic text-[#121212] text-[15px] text-nowrap top-[13px] tracking-[-0.32px] whitespace-pre">
          9:41
        </p>
        
        {/* Status Bar Icons */}
        <div className="absolute content-stretch flex gap-[2px] items-start right-[15px] top-[15px]">
          {/* Mobile Signal */}
          <div className="h-[16px] relative shrink-0 w-[20px]">
            <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 16">
              <path d={svgPaths.p15d4ae30} fill="#121212" />
            </svg>
          </div>
          
          {/* Wifi */}
          <div className="relative shrink-0 size-[16px]">
            <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
              <path d={svgPaths.p382fcb80} fill="#121212" />
            </svg>
          </div>
          
          {/* Battery */}
          <div className="h-[16px] relative shrink-0 w-[25px]">
            <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 25 16">
              <g clipPath="url(#clip0_6_1715)">
                <path d={svgPaths.p15509f50} opacity="0.35" stroke="#121212" />
                <path d={svgPaths.p307e0200} fill="#121212" opacity="0.4" />
                <path d={svgPaths.p365f7580} fill="#121212" />
              </g>
              <defs>
                <clipPath id="clip0_6_1715">
                  <rect fill="white" height="16" width="25" />
                </clipPath>
              </defs>
            </svg>
          </div>
        </div>
      </div>
    </div>
  );
}
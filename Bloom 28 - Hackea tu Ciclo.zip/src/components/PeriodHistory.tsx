import { motion } from 'motion/react';
import { ArrowLeft, Calendar, TrendingUp, Activity, Brain, AlertCircle, Zap } from 'lucide-react';

interface PeriodHistoryProps {
  onBack: () => void;
}

export function PeriodHistory({ onBack }: PeriodHistoryProps) {
  // Mock data - En producción vendría del backend
  const periodHistory = [
    { month: 'Enero 2026', startDate: '5 de Enero', duration: 5, cycleLength: 28 },
    { month: 'Diciembre 2025', startDate: '8 de Diciembre', duration: 4, cycleLength: 28 },
    { month: 'Noviembre 2025', startDate: '10 de Noviembre', duration: 5, cycleLength: 28 },
    { month: 'Octubre 2025', startDate: '13 de Octubre', duration: 4, cycleLength: 28 },
    { month: 'Septiembre 2025', startDate: '15 de Septiembre', duration: 5, cycleLength: 29 },
    { month: 'Agosto 2025', startDate: '17 de Agosto', duration: 4, cycleLength: 29 }
  ];

  const topSymptoms = [
    { id: 'cramping', label: 'Cólicos', icon: Activity, frequency: 85, color: 'from-[#2271b8] to-[#5250a2]' },
    { id: 'fatigue', label: 'Fatiga', icon: Zap, frequency: 72, color: 'from-[#5250a2] to-[#8b4fb8]' },
    { id: 'mood-swings', label: 'Cambios de humor', icon: Brain, frequency: 68, color: 'from-[#f58020] to-[#ef932d]' },
    { id: 'headache', label: 'Dolor de cabeza', icon: AlertCircle, frequency: 54, color: 'from-[#ef932d] to-[#e8a55c]' }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#ffe0c6] to-[#f5ebc3] pb-24">
      {/* Header */}
      <div className="sticky top-0 bg-gradient-to-r from-[#f58020] to-[#ef932d] px-6 py-5 shadow-lg z-10">
        <div className="flex items-center justify-between">
          <button 
            onClick={onBack}
            className="p-2 hover:bg-white/20 rounded-full transition-colors"
          >
            <ArrowLeft className="w-6 h-6 text-white" />
          </button>
          <h1 className="font-['Ninetea:Bold',sans-serif] text-white text-xl">
            Historial de Períodos
          </h1>
          <div className="w-10"></div>
        </div>
      </div>

      <div className="p-6 space-y-6">
        {/* Summary Card */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-gradient-to-r from-[#2271b8] to-[#5250a2] rounded-2xl p-5 shadow-lg"
        >
          <div className="flex items-center gap-3 mb-4">
            <Calendar className="w-6 h-6 text-white" />
            <h2 className="font-['Ninetea:Bold',sans-serif] text-white text-lg">
              Resumen General
            </h2>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="bg-white/20 rounded-xl p-3">
              <p className="font-['Inter:Regular',sans-serif] text-[#fbeedc] text-xs mb-1">
                Ciclo Promedio
              </p>
              <p className="font-['Ninetea:Bold',sans-serif] text-white text-2xl">
                28 días
              </p>
            </div>
            <div className="bg-white/20 rounded-xl p-3">
              <p className="font-['Inter:Regular',sans-serif] text-[#fbeedc] text-xs mb-1">
                Duración Promedio
              </p>
              <p className="font-['Ninetea:Bold',sans-serif] text-white text-2xl">
                5 días
              </p>
            </div>
          </div>
        </motion.div>

        {/* Period History */}
        <div>
          <h2 className="font-['Ninetea:Bold',sans-serif] text-[#130b3d] text-lg mb-4 flex items-center gap-2">
            <Calendar className="w-6 h-6 text-[#f58020]" strokeWidth={2} />
            Registro de Meses Anteriores
          </h2>
          <div className="space-y-3">
            {periodHistory.map((period, index) => (
              <motion.div
                key={period.month}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.1 }}
                className="bg-[#fcefdd] rounded-2xl p-4 shadow-md"
              >
                <div className="flex justify-between items-start mb-3">
                  <div>
                    <h3 className="font-['Ninetea:Semi_Bold',sans-serif] text-[#130b3d] text-base">
                      {period.month}
                    </h3>
                    <p className="font-['Inter:Regular',sans-serif] text-[#f58020] text-sm mt-1">
                      Inicio: {period.startDate}
                    </p>
                  </div>
                  <div className="bg-gradient-to-r from-[#f58020] to-[#ef932d] px-3 py-1 rounded-full">
                    <p className="font-['Inter:Bold',sans-serif] text-white text-xs">
                      {period.duration} días
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-4 text-xs">
                  <div className="flex items-center gap-1">
                    <div className="w-2 h-2 bg-[#2271b8] rounded-full"></div>
                    <span className="font-['Inter:Regular',sans-serif] text-[#130b3d]">
                      Ciclo: {period.cycleLength} días
                    </span>
                  </div>
                  <div className="flex items-center gap-1">
                    <div className="w-2 h-2 bg-[#ea4c89] rounded-full"></div>
                    <span className="font-['Inter:Regular',sans-serif] text-[#130b3d]">
                      Regular
                    </span>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Top Symptoms */}
        <div>
          <h2 className="font-['Ninetea:Bold',sans-serif] text-[#130b3d] text-lg mb-4 flex items-center gap-2">
            <TrendingUp className="w-6 h-6 text-[#2271b8]" strokeWidth={2} />
            Síntomas Más Frecuentes
          </h2>
          <div className="space-y-3">
            {topSymptoms.map((symptom, index) => {
              const IconComponent = symptom.icon;
              return (
                <motion.div
                  key={symptom.id}
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: index * 0.1 }}
                  className="bg-[#fcefdd] rounded-2xl p-4 shadow-md"
                >
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-3">
                      <div className={`p-2 rounded-xl bg-gradient-to-r ${symptom.color}`}>
                        <IconComponent className="w-5 h-5 text-white" strokeWidth={2} />
                      </div>
                      <div>
                        <h3 className="font-['Inter:Semi_Bold',sans-serif] text-[#130b3d] text-sm">
                          {symptom.label}
                        </h3>
                        <p className="font-['Inter:Regular',sans-serif] text-[#f58020] text-xs">
                          {symptom.frequency}% de los ciclos
                        </p>
                      </div>
                    </div>
                  </div>
                  {/* Progress Bar */}
                  <div className="w-full bg-white/50 rounded-full h-2 overflow-hidden">
                    <motion.div
                      initial={{ width: 0 }}
                      animate={{ width: `${symptom.frequency}%` }}
                      transition={{ duration: 1, delay: index * 0.1 + 0.3 }}
                      className={`h-full bg-gradient-to-r ${symptom.color} rounded-full`}
                    ></motion.div>
                  </div>
                </motion.div>
              );
            })}
          </div>
        </div>

        {/* Info Card */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="bg-gradient-to-r from-[#f58020] to-[#ef932d] rounded-2xl p-5 shadow-lg"
        >
          <h3 className="font-['Ninetea:Bold',sans-serif] text-white mb-2">
            💡 Consejo
          </h3>
          <p className="font-['Inter:Regular',sans-serif] text-[#fbeedc] text-sm">
            Tu ciclo es regular. Continúa registrando tus síntomas para obtener recomendaciones más personalizadas.
          </p>
        </motion.div>
      </div>
    </div>
  );
}

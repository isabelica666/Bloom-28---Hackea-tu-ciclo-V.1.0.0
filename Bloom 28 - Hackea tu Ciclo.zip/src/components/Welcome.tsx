import svgPaths from "../imports/svg-zr31ynpj7r";

interface WelcomeProps {
  onLogin: () => void;
  onRegister: () => void;
}

export function Welcome({ onLogin, onRegister }: WelcomeProps) {
  return (
    <div className="bg-gradient-to-b from-[#ffe0c6] to-[#f5ebc3] overflow-clip relative min-h-screen w-full max-w-md mx-auto">
      {/* Home Indicator */}
      <div className="absolute bottom-0 h-[34px] left-1/2 translate-x-[-50%] w-[393px]">
        <div className="absolute h-[34px] left-0 right-0 top-0" />
        <div className="absolute bottom-[7.67px] flex h-[5px] items-center justify-center left-1/2 translate-x-[-50%] w-[139.938px]">
          <div className="flex-none rotate-[180deg] scale-y-[-100%]">
            <div className="bg-[#121212] h-[5px] rounded-[100px] w-[139.938px]" />
          </div>
        </div>
      </div>

      {/* Blur Effect 1 - Pink */}
      <div className="absolute flex inset-[6.34%_-28.87%_61.76%_66.92%] items-center justify-center">
        <div className="flex-none h-[186.378px] rotate-[226.129deg] skew-x-[6.174deg] w-[178.744px]">
          <div className="relative size-full">
            <div className="absolute inset-[-91.85%_-95.77%]">
              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 522 529">
                <g filter="url(#filter0_f_5_1122)" opacity="0.8">
                  <ellipse cx="260.561" cy="264.378" fill="#FD587A" fillOpacity="0.24" rx="89.3719" ry="93.1892" />
                </g>
                <defs>
                  <filter colorInterpolationFilters="sRGB" filterUnits="userSpaceOnUse" height="528.755" id="filter0_f_5_1122" width="521.121" x="0" y="0">
                    <feFlood floodOpacity="0" result="BackgroundImageFix" />
                    <feBlend in="SourceGraphic" in2="BackgroundImageFix" mode="normal" result="shape" />
                    <feGaussianBlur result="effect1_foregroundBlur_5_1122" stdDeviation="85.5943" />
                  </filter>
                </defs>
              </svg>
            </div>
          </div>
        </div>
      </div>

      {/* Blur Effect 2 - Purple */}
      <div className="absolute flex inset-[36.97%_55.73%_24.25%_-44.27%] items-center justify-center">
        <div className="flex-none h-[243.129px] rotate-[221.503deg] skew-x-[356.979deg] w-[236.982px]">
          <div className="relative size-full">
            <div className="absolute inset-[-65.43%_-67.13%]">
              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 556 562">
                <g filter="url(#filter0_f_5_1124)" opacity="0.8">
                  <ellipse cx="277.579" cy="280.652" fill="#C294EC" fillOpacity="0.44" rx="118.491" ry="121.564" />
                </g>
                <defs>
                  <filter colorInterpolationFilters="sRGB" filterUnits="userSpaceOnUse" height="561.304" id="filter0_f_5_1124" width="555.157" x="0" y="0">
                    <feFlood floodOpacity="0" result="BackgroundImageFix" />
                    <feBlend in="SourceGraphic" in2="BackgroundImageFix" mode="normal" result="shape" />
                    <feGaussianBlur result="effect1_foregroundBlur_5_1124" stdDeviation="79.5438" />
                  </filter>
                </defs>
              </svg>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="absolute content-stretch flex flex-col gap-[36px] items-center justify-center left-[24px] top-[133.5px] w-[345px]">
        {/* Logo Section */}
        <div className="content-stretch flex flex-col gap-[40px] h-[269px] items-center justify-center relative shrink-0 w-[287px]">
          <div className="relative shrink-0 size-[104px]">
            <div className="absolute contents left-[2.3px] top-[-54px]">
              <div className="absolute contents leading-[normal] left-[2.3px] not-italic text-[#130b3d] top-[20.84px]">
                <p className="absolute font-['Cal_Sans:Regular',sans-serif] h-[32.912px] left-[2.3px] text-[24.574px] top-[20.84px] w-[72.845px]">
                  Bloom
                </p>
                <p className="absolute font-['Gebuk:Regular',sans-serif] h-[29.401px] left-[75.14px] text-[27.865px] top-[22.59px] w-[32.473px]">
                  28
                </p>
              </div>
              <div className="absolute contents left-[29.49px] top-[-54px]">
                <p className="absolute font-['Gebuk:Regular',sans-serif] h-[76.699px] leading-[normal] left-[29.49px] not-italic text-[#130b3d] text-[84.139px] top-[-54px] w-[84.712px]">
                  8
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Text Section */}
        <div className="content-stretch flex flex-col h-[118px] items-center justify-center relative shrink-0 w-full">
          <div className="content-stretch flex flex-col gap-[8px] items-center justify-center not-italic relative shrink-0 text-center">
            <p className="font-['Ninetea:Bold',sans-serif] leading-[40px] relative shrink-0 text-[28px] w-[271px]">
              <span className="text-[#130b3d]">Tu Ciclo,</span>
              <span className="text-[#f58020]">{` Tu Poder`}</span>
            </p>
            <p className="font-['Inter:Regular',sans-serif] leading-[1.3] relative shrink-0 text-[#130b3d] text-[18px] tracking-[-0.18px] w-[271px]">
              Conecta con tu cuerpo y toma el poder de tu salud menstrual
            </p>
          </div>
        </div>

        {/* Buttons Section */}
        <div className="content-stretch flex flex-col gap-[8px] items-center justify-center relative shrink-0 w-[345px]">
          {/* Login Button */}
          <button
            onClick={onLogin}
            className="bg-[rgba(245,128,32,0.8)] backdrop-blur-xl border border-white shadow-lg relative rounded-[24px] shrink-0 w-full"
          >
            <div className="content-stretch flex gap-[4px] items-center justify-center px-[24px] py-[12px] relative w-full">
              <p className="font-['Ninetea:Medium',sans-serif] leading-[24px] not-italic relative shrink-0 text-[14px] text-center text-nowrap text-[#fbeedc] whitespace-pre">
                Iniciar Sesión
              </p>
            </div>
          </button>

          {/* Register Button */}
          <button
            onClick={onRegister}
            className="bg-[rgba(255,255,255,0.42)] backdrop-blur-xl border border-white shadow-lg relative rounded-[24px] shrink-0 w-full"
          >
            <div className="content-stretch flex gap-[4px] items-center justify-center px-[24px] py-[12px] relative w-full">
              <p className="font-['Ninetea:Medium',sans-serif] leading-[24px] not-italic relative shrink-0 text-[#f58020] text-[14px] text-center text-nowrap whitespace-pre">
                Regístrate
              </p>
            </div>
          </button>
        </div>
      </div>

      {/* Status Bar */}
      <div className="absolute h-[44px] left-0 overflow-clip top-0 w-full max-w-[393px]">
        <div className="absolute h-[30px] left-1/2 top-[-2px] translate-x-[-50%] w-[219px]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 219 30">
            <path d={svgPaths.p7f98200} fill="#121212" />
          </svg>
        </div>
        <p className="absolute font-['SF_Pro_Text:Semibold',sans-serif] leading-[21px] left-[32px] not-italic text-[#121212] text-[15px] text-nowrap top-[13px] tracking-[-0.32px] whitespace-pre">
          9:41
        </p>
        
        {/* Status Bar Icons */}
        <div className="absolute content-stretch flex gap-[2px] items-start right-[15px] top-[15px]">
          {/* Mobile Signal */}
          <div className="h-[16px] relative shrink-0 w-[20px]">
            <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 16">
              <path d={svgPaths.p15d4ae30} fill="#121212" />
            </svg>
          </div>
          
          {/* Wifi */}
          <div className="relative shrink-0 size-[16px]">
            <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
              <path d={svgPaths.p382fcb80} fill="#121212" />
            </svg>
          </div>
          
          {/* Battery */}
          <div className="h-[16px] relative shrink-0 w-[25px]">
            <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 25 16">
              <g clipPath="url(#clip0_5_1106)">
                <path d={svgPaths.p15509f50} opacity="0.35" stroke="#121212" />
                <path d={svgPaths.p307e0200} fill="#121212" opacity="0.4" />
                <path d={svgPaths.p365f7580} fill="#121212" />
              </g>
              <defs>
                <clipPath id="clip0_5_1106">
                  <rect fill="white" height="16" width="25" />
                </clipPath>
              </defs>
            </svg>
          </div>
        </div>
      </div>
    </div>
  );
}
import { motion } from 'motion/react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { ArrowLeft, Moon, TrendingUp, TrendingDown, Sparkles, Sunrise } from 'lucide-react';
import { calculateCycleInfo, type CycleData } from '../utils/cycleCalculations';
import { generateLast7DaysData, calculateAverages } from '../utils/biometricData';

interface SleepQualityDetailProps {
  cycleData: CycleData;
  onBack: () => void;
}

export function SleepQualityDetail({ cycleData, onBack }: SleepQualityDetailProps) {
  const cycleInfo = calculateCycleInfo(cycleData);
  const currentPhase = cycleInfo.currentPhase;

  // Generar datos de los últimos 7 días basados en la fase actual
  const last7DaysData = generateLast7DaysData(currentPhase);
  const sleepData = last7DaysData.map(d => ({ 
    day: d.day, 
    quality: d.sleepQuality, 
    hours: d.sleepHours 
  }));
  const { avgSleepQuality, avgSleepHours } = calculateAverages(last7DaysData);

  // Calcular tendencias basadas en la fase
  const sleepTrend = currentPhase === 'ovulation' || currentPhase === 'follicular' ? '+5%' : currentPhase === 'luteal' ? '-2%' : '-3%';
  const sleepTrendUp = currentPhase === 'ovulation' || currentPhase === 'follicular';

  // Insights específicos de sueño según la fase
  const getSleepInsights = () => {
    const insights = {
      menstrual: {
        title: "Calidad de Sueño Reducida - Es Normal",
        message: `Tu calidad de sueño disminuye durante la menstruación (${avgSleepQuality}% promedio). Los cólicos, el dolor, la inflamación y las fluctuaciones de temperatura pueden interrumpir el sueño profundo. Además, los niveles bajos de estrógeno afectan la producción de melatonina, la hormona del sueño.`,
        tips: [
          "Calidad de sueño del 70-80% es normal durante la menstruación - no te alarmes",
          "Duerme 30-60 minutos extra para compensar la calidad reducida",
          "Usa calor local (bolsa térmica) para aliviar cólicos y mejorar el descanso",
          "Evita cafeína después de las 2 PM - tu cuerpo es más sensible ahora",
          "Considera suplementos de magnesio para mejorar la relajación muscular"
        ],
        interpretation: "El sueño interrumpido durante el período es causado principalmente por la inflamación sistémica y las molestias físicas. El estrógeno bajo también reduce la fase REM del sueño, haciéndote sentir menos descansada incluso si duermes tus horas habituales.",
        sleepPhases: `Durante la menstruación pasas menos tiempo en sueño profundo (REM) y más en sueño ligero. Aunque duermas ${avgSleepHours} horas, la calidad es menor porque pasas más tiempo en estados de sueño superficial donde cualquier molestia te despierta fácilmente.`
      },
      follicular: {
        title: "Mejor Calidad de Sueño del Ciclo",
        message: `Tu calidad de sueño está en su pico (${avgSleepQuality}% promedio). El estrógeno en aumento optimiza la producción de melatonina y serotonina, regulando tu ritmo circadiano. Te despiertas más descansada y con más energía para enfrentar el día.`,
        tips: [
          "Calidad de sueño del 85-90% es excelente - aprovecha esta energía",
          "Este es el mejor momento para establecer rutinas de sueño saludables",
          "Tu cuerpo se recupera más rápido del ejercicio durante el sueño en esta fase",
          "Duerme tus horas habituales - no necesitas tiempo extra de recuperación",
          "Aprovecha para entrenamientos matutinos - te despertarás más descansada"
        ],
        interpretation: "La fase folicular ofrece la mejor calidad de sueño porque el estrógeno actúa como regulador del ciclo circadiano. Aumenta la producción de melatonina nocturna y reduce los despertares nocturnos, permitiéndote pasar más tiempo en sueño profundo reparador.",
        sleepPhases: `Con ${avgSleepHours} horas de sueño y ${avgSleepQuality}% de calidad, estás obteniendo aproximadamente 1.5-2 horas más de sueño REM profundo comparado con la fase menstrual. Esto explica por qué te sientes tan energizada al despertar.`
      },
      ovulation: {
        title: "Calidad de Sueño Óptima - Pico Hormonal",
        message: `Tu calidad de sueño alcanza su máximo (${avgSleepQuality}% promedio) durante la ovulación. El pico de estrógeno combinado con niveles óptimos de todas tus hormonas crea las condiciones perfectas para un sueño profundo y reparador. Aprovecha esta ventana de máximo rendimiento.`,
        tips: [
          "Calidad de sueño del 85-90% es tu mejor momento del mes - capitalízalo",
          "Excelente momento para ajustar horarios de sueño si lo necesitas",
          "Tu temperatura corporal ligeramente elevada puede ayudar con el sueño profundo",
          "Minimiza alcohol - tu sueño ya es óptimo, no lo sabotees",
          "Considera acostarte 30 min más temprano para maximizar las horas de sueño de calidad"
        ],
        interpretation: "Durante la ovulación, el equilibrio hormonal perfecto entre estrógeno y progesterona optimiza todos los aspectos del sueño. El estrógeno mantiene alta la melatonina mientras que la progesterona inicial tiene un efecto levemente sedante, mejorando el inicio del sueño.",
        sleepPhases: `Tus ${avgSleepHours} horas de sueño incluyen la mayor proporción de sueño REM del ciclo. Con ${avgSleepQuality}% de calidad, estás experimentando ciclos de sueño completos y eficientes, pasando aproximadamente 2-2.5 horas en sueño profundo restaurador cada noche.`
      },
      luteal: {
        title: "Calidad de Sueño Variable - Monitorea",
        message: `Tu calidad de sueño comienza a descender (${avgSleepQuality}% promedio) en la fase lútea. La progesterona alta aumenta tu temperatura corporal nocturna, lo que puede interrumpir el sueño profundo. Hacia el final de esta fase, la caída de progesterona puede causar insomnio leve o despertares nocturnos.`,
        tips: [
          "Calidad de sueño del 75-85% es normal - puede disminuir más cerca del período",
          "Mantén tu habitación más fresca (18-20°C) para compensar el aumento de temperatura",
          "Evita ejercicio intenso 3-4 horas antes de dormir - ya estás más caliente",
          "El magnesio puede ayudar con los síntomas pre-menstruales que afectan el sueño",
          "Si tienes insomnio, prueba técnicas de relajación como respiración 4-7-8"
        ],
        interpretation: "La progesterona aumenta tu temperatura corporal basal aproximadamente 0.5°C, lo que puede hacer más difícil alcanzar el sueño profundo. La temperatura corporal naturalmente baja durante el sueño, pero la progesterona contrarresta este descenso, resultando en sueño más ligero y fragmentado.",
        sleepPhases: `Aunque duermas ${avgSleepHours} horas, tu calidad del ${avgSleepQuality}% indica que pasas más tiempo en sueño ligero. La temperatura elevada y los síntomas pre-menstruales (hinchazón, ansiedad) pueden reducir tu sueño REM en aproximadamente 20-30% comparado con la fase folicular.`
      }
    };

    return insights[currentPhase as keyof typeof insights] || insights.follicular;
  };

  const sleepInsight = getSleepInsights();

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#ffe0c6] to-[#f5ebc3] pb-6">
      {/* Header */}
      <div className="sticky top-0 z-10 bg-gradient-to-b from-[#ffe0c6] to-transparent backdrop-blur-sm pb-4">
        <div className="flex items-center justify-between px-6 pt-6 pb-2">
          <button
            onClick={onBack}
            className="p-2 hover:bg-[rgba(252,239,221,0.5)] rounded-full transition-colors"
          >
            <ArrowLeft className="w-6 h-6 text-[#130b3d]" />
          </button>
          <h1 className="font-['Ninetea:Bold',sans-serif] text-[24px] text-[#130b3d]">Calidad de Sueño</h1>
          <div className="w-10" /> {/* Spacer for centering */}
        </div>
      </div>

      <div className="px-6 space-y-6">
        {/* Current Value Cards */}
        <div className="grid grid-cols-2 gap-4">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-[rgba(252,239,221,0.5)] backdrop-blur-xl border border-white shadow-lg rounded-3xl p-5"
          >
            <div className="flex items-center justify-center mb-3">
              <Moon className="w-10 h-10 text-[#ea4c89]" strokeWidth={1.5} />
            </div>
            <div className="text-center">
              <p className="font-['Ninetea:Bold',sans-serif] text-[40px] text-[#130b3d] leading-none mb-1">
                {avgSleepQuality}%
              </p>
              <p className="font-['Inter:Regular',sans-serif] text-xs text-[#130b3d]">
                Calidad
              </p>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.05 }}
            className="bg-[rgba(252,239,221,0.5)] backdrop-blur-xl border border-white shadow-lg rounded-3xl p-5"
          >
            <div className="flex items-center justify-center mb-3">
              <Sunrise className="w-10 h-10 text-[#f58020]" strokeWidth={1.5} />
            </div>
            <div className="text-center">
              <p className="font-['Ninetea:Bold',sans-serif] text-[40px] text-[#130b3d] leading-none mb-1">
                {avgSleepHours}h
              </p>
              <p className="font-['Inter:Regular',sans-serif] text-xs text-[#130b3d]">
                Duración
              </p>
            </div>
          </motion.div>
        </div>

        {/* Trend Badge */}
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="flex justify-center"
        >
          <div className="inline-flex items-center gap-2 bg-[rgba(234,76,137,0.15)] px-5 py-2.5 rounded-full">
            {sleepTrendUp ? <TrendingUp className="w-5 h-5 text-[#ea4c89]" /> : <TrendingDown className="w-5 h-5 text-[#ea4c89]" />}
            <span className="font-['Inter:Bold',sans-serif] text-sm text-[#ea4c89]">{sleepTrend} vs. semana anterior</span>
          </div>
        </motion.div>

        {/* Sleep Chart */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.15 }}
          className="bg-[rgba(252,239,221,0.5)] backdrop-blur-xl border border-white shadow-lg rounded-3xl p-6"
        >
          <h3 className="font-['Ninetea:Bold',sans-serif] text-[#130b3d] mb-4 text-center">
            Evolución de los últimos 7 días
          </h3>
          <ResponsiveContainer width="100%" height={280}>
            <AreaChart data={sleepData} margin={{ top: 10, right: 10, left: -15, bottom: 10 }}>
              <defs>
                <linearGradient id="sleepGradientDetail" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#ea4c89" stopOpacity={0.6}/>
                  <stop offset="50%" stopColor="#f58020" stopOpacity={0.3}/>
                  <stop offset="95%" stopColor="#f58020" stopOpacity={0.05}/>
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#e5d4c1" strokeOpacity={0.3} />
              <XAxis 
                dataKey="day" 
                stroke="#130b3d" 
                strokeOpacity={0.5}
                style={{ fontSize: '12px', fontFamily: 'Inter' }}
                axisLine={false}
                tickLine={false}
              />
              <YAxis 
                domain={[0, 100]} 
                stroke="#130b3d" 
                strokeOpacity={0.5}
                style={{ fontSize: '12px', fontFamily: 'Inter' }}
                axisLine={false}
                tickLine={false}
                label={{ value: 'Calidad (%)', angle: -90, position: 'insideLeft', style: { fontFamily: 'Inter', fontSize: '11px', fill: '#130b3d' } }}
              />
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: 'rgba(252, 239, 221, 0.95)', 
                  border: 'none', 
                  borderRadius: '12px', 
                  fontFamily: 'Inter', 
                  color: '#130b3d',
                  boxShadow: '0 4px 12px rgba(0,0,0,0.1)'
                }}
                formatter={(value: any, name: string) => {
                  if (name === 'quality') return [`${value}%`, 'Calidad'];
                  if (name === 'hours') return [`${value}h`, 'Duración'];
                  return [value, name];
                }}
              />
              <Area 
                type="monotone" 
                dataKey="quality" 
                stroke="#ea4c89" 
                strokeWidth={4}
                fill="url(#sleepGradientDetail)"
                dot={{ fill: '#ea4c89', r: 7, strokeWidth: 3, stroke: '#fff' }}
                activeDot={{ r: 9, strokeWidth: 3, stroke: '#fff' }}
              />
            </AreaChart>
          </ResponsiveContainer>
        </motion.div>

        {/* AI Insights */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="bg-[rgba(252,239,221,0.5)] backdrop-blur-xl border border-white shadow-lg rounded-3xl p-6"
        >
          <div className="flex items-center justify-center gap-2 mb-4">
            <Sparkles className="w-6 h-6 text-[#ea4c89]" />
            <h3 className="font-['Ninetea:Bold',sans-serif] text-[#130b3d] text-[20px]">Insight de IA</h3>
          </div>
          
          <h4 className="font-['Inter:Bold',sans-serif] text-[#130b3d] text-center mb-3 text-lg">
            {sleepInsight.title}
          </h4>
          
          <p className="font-['Inter:Regular',sans-serif] text-sm text-[#130b3d] leading-relaxed mb-4">
            {sleepInsight.message}
          </p>

          <div className="bg-[rgba(245,235,195,0.5)] rounded-2xl p-4 mb-4">
            <h5 className="font-['Inter:Bold',sans-serif] text-sm text-[#130b3d] mb-2">
              🔍 Interpretación:
            </h5>
            <p className="font-['Inter:Regular',sans-serif] text-sm text-[#130b3d] leading-relaxed mb-3">
              {sleepInsight.interpretation}
            </p>
            <div className="flex items-start gap-2 mt-3 pt-3 border-t border-[rgba(19,11,61,0.1)]">
              <Moon className="w-4 h-4 text-[#ea4c89] mt-0.5 flex-shrink-0" />
              <p className="font-['Inter:Regular',sans-serif] text-xs text-[#130b3d] leading-relaxed">
                {sleepInsight.sleepPhases}
              </p>
            </div>
          </div>

          <h5 className="font-['Inter:Bold',sans-serif] text-sm text-[#130b3d] mb-3">
            💡 Recomendaciones:
          </h5>
          <div className="space-y-3">
            {sleepInsight.tips.map((tip, index) => (
              <div key={index} className="flex items-start gap-3">
                <div className="w-2 h-2 rounded-full bg-[#ea4c89] mt-1.5 flex-shrink-0"></div>
                <p className="font-['Inter:Regular',sans-serif] text-sm text-[#130b3d] flex-1 leading-relaxed">
                  {tip}
                </p>
              </div>
            ))}
          </div>
        </motion.div>
      </div>
    </div>
  );
}
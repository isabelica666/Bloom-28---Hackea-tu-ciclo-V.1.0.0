import { motion } from 'motion/react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Area, AreaChart } from 'recharts';
import { TrendingUp, TrendingDown, Sparkles, Thermometer, Heart, Moon } from 'lucide-react';
import { calculateCycleInfo, type CycleData } from '../utils/cycleCalculations';
import { generateLast7DaysData, calculateAverages, getCurrentBiometrics } from '../utils/biometricData';

interface BiometricDataProps {
  cycleData: CycleData;
  onTemperatureClick: () => void;
  onHeartRateClick: () => void;
  onSleepClick: () => void;
}

export function BiometricData({ cycleData, onTemperatureClick, onHeartRateClick, onSleepClick }: BiometricDataProps) {
  const cycleInfo = calculateCycleInfo(cycleData);
  const currentPhase = cycleInfo.currentPhase;

  // Generar datos de los últimos 7 días basados en la fase actual
  const last7DaysData = generateLast7DaysData(currentPhase);
  
  // Separar datos para cada gráfica
  const tempData = last7DaysData.map(d => ({ day: d.day, temp: d.temp }));
  const heartRateData = last7DaysData.map(d => ({ 
    day: d.day, 
    rate: d.heartRate, 
    sleeping: d.heartRateSleep 
  }));
  const sleepData = last7DaysData.map(d => ({ 
    day: d.day, 
    quality: d.sleepQuality, 
    hours: d.sleepHours 
  }));

  // Calcular promedios
  const { avgTemp, avgHeartRate, avgSleepQuality, avgSleepHours } = calculateAverages(last7DaysData);
  
  // Obtener valores actuales
  const currentBiometrics = getCurrentBiometrics(currentPhase);

  // Calcular tendencias basadas en la fase
  const tempTrend = currentPhase === 'ovulation' || currentPhase === 'luteal' ? '+0.4°C' : currentPhase === 'follicular' ? '+0.2°C' : '-0.1°C';
  const tempTrendUp = currentPhase === 'ovulation' || currentPhase === 'luteal' || currentPhase === 'follicular';
  
  const sleepTrend = currentPhase === 'ovulation' || currentPhase === 'follicular' ? '+5%' : currentPhase === 'luteal' ? '-2%' : '-3%';
  const sleepTrendUp = currentPhase === 'ovulation' || currentPhase === 'follicular';

  // Generar insights de IA según la fase del ciclo
  const getAIInsights = () => {
    const insights = {
      menstrual: {
        title: "Fase Menstrual: Tu cuerpo necesita descanso",
        message: "Durante esta fase, tu temperatura basal es más baja (36.2°C promedio) y tu cuerpo está trabajando intensamente. Es normal que tu frecuencia cardíaca en reposo sea ligeramente más alta (68 bpm) debido a la inflamación. Prioriza el descanso y la recuperación.",
        tips: [
          "La calidad de sueño puede disminuir - intenta dormir 30 min extra",
          "Evita ejercicios de alta intensidad los primeros 2 días",
          "Tu temperatura basal baja es completamente normal"
        ]
      },
      follicular: {
        title: "Fase Folicular: Energía en aumento",
        message: "Tu temperatura basal está aumentando gradualmente (36.3°C) y tu frecuencia cardíaca en reposo es más baja (65 bpm), indicando buena recuperación. Esta es una excelente fase para entrenamientos intensos y nuevos desafíos.",
        tips: [
          "Tu calidad de sueño está en su mejor momento (85%)",
          "Aprovecha tu energía para ejercicios de fuerza",
          "Tu cuerpo se recupera más rápido - ideal para entrenar"
        ]
      },
      ovulation: {
        title: "Fase de Ovulación: Pico de rendimiento",
        message: "Tu temperatura basal ha aumentado significativamente (36.6°C), señal clara de ovulación. Tu frecuencia cardíaca en reposo puede estar ligeramente elevada (70 bpm) debido a cambios hormonales. Estás en tu pico de energía y resistencia.",
        tips: [
          "La temperatura elevada confirma la ovulación",
          "Excelente momento para ejercicios de alta intensidad",
          "Tu calidad de sueño es óptima (88%) - aprovéchala"
        ]
      },
      luteal: {
        title: "Fase Lútea: Escucha a tu cuerpo",
        message: "Tu temperatura basal se mantiene alta (36.7°C) debido a la progesterona. Es normal sentir más fatiga - tu frecuencia cardíaca puede estar ligeramente elevada (67 bpm) y la calidad de sueño puede disminuir hacia el final de esta fase.",
        tips: [
          "Reduce la intensidad del ejercicio si sientes fatiga",
          "Prioriza ejercicios de bajo impacto como yoga",
          "Si tu sueño empeora, ajusta tu rutina nocturna"
        ]
      }
    };

    return insights[currentPhase as keyof typeof insights] || insights.follicular;
  };

  const aiInsight = getAIInsights();

  return (
    <div className="p-6 space-y-6 bg-gradient-to-b from-[#ffe0c6] to-[#f5ebc3] min-h-screen">
      <h2 className="font-['Ninetea:Bold',sans-serif] text-[#130b3d] text-center text-[24px]">Datos Biométricos</h2>

      {/* Summary Stats - Moved to Top */}
      <div className="grid grid-cols-3 gap-3">
        <button 
          onClick={onTemperatureClick}
          className="bg-[rgba(252,239,221,0.5)] backdrop-blur-xl border border-white shadow-lg rounded-2xl p-4 flex flex-col items-center justify-center relative hover:bg-[rgba(252,239,221,0.7)] transition-all active:scale-95"
        >
          <Thermometer className="w-[18px] h-[18px] text-[#f58020] mb-2 absolute top-3" strokeWidth={1.5} />
          <p className="font-['Ninetea:Bold',sans-serif] text-[28px] text-[#130b3d] mt-6 mb-1">{avgTemp}°C</p>
          <p className="font-['Ninetea:Semi_Bold',sans-serif] text-[10px] text-[#ef932d] text-center leading-tight">Temperatura<br />Basal</p>
        </button>
        <button 
          onClick={onHeartRateClick}
          className="bg-[rgba(252,239,221,0.5)] backdrop-blur-xl border border-white shadow-lg rounded-2xl p-4 flex flex-col items-center justify-center relative hover:bg-[rgba(252,239,221,0.7)] transition-all active:scale-95"
        >
          <Heart className="w-[18px] h-[18px] text-[#f58020] mb-2 absolute top-3" strokeWidth={1.5} />
          <p className="font-['Ninetea:Bold',sans-serif] text-[28px] text-[#130b3d] mt-6 mb-1">{avgHeartRate}</p>
          <p className="font-['Ninetea:Semi_Bold',sans-serif] text-[10px] text-[#2271b8] text-center leading-tight">Frecuencia<br />Cardíaca</p>
        </button>
        <button 
          onClick={onSleepClick}
          className="bg-[rgba(252,239,221,0.5)] backdrop-blur-xl border border-white shadow-lg rounded-2xl p-4 flex flex-col items-center justify-center relative hover:bg-[rgba(252,239,221,0.7)] transition-all active:scale-95"
        >
          <Moon className="w-[18px] h-[18px] text-[#f58020] mb-2 absolute top-3" strokeWidth={1.5} />
          <p className="font-['Ninetea:Bold',sans-serif] text-[28px] text-[#130b3d] mt-6 mb-1">{avgSleepQuality}%</p>
          <p className="font-['Ninetea:Semi_Bold',sans-serif] text-[10px] text-[#ef932d] text-center leading-tight">Calidad de<br />Sueño</p>
        </button>
      </div>

      {/* Basal Temperature Chart */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-[rgba(252,239,221,0.5)] backdrop-blur-xl border border-white shadow-lg rounded-3xl p-5"
      >
        <div className="flex items-center justify-between mb-4">
          <div>
            <h4 className="font-['Ninetea:Bold',sans-serif] text-[#130b3d]">Temperatura Basal</h4>
            <p className="font-['Inter:Regular',sans-serif] text-sm text-[#130b3d]">Últimos 7 días</p>
          </div>
          <div className="flex items-center gap-1 text-[#f58020]">
            {tempTrendUp ? <TrendingUp className="w-4 h-4" /> : <TrendingDown className="w-4 h-4" />}
            <span className="font-['Inter:Bold',sans-serif] text-sm">{tempTrend}</span>
          </div>
        </div>
        <ResponsiveContainer width="100%" height={200}>
          <AreaChart data={tempData} margin={{ top: 5, right: 5, left: -20, bottom: 5 }}>
            <defs>
              <linearGradient id="tempGradient" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#f58020" stopOpacity={0.4}/>
                <stop offset="95%" stopColor="#f58020" stopOpacity={0.05}/>
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="#e5d4c1" strokeOpacity={0.3} />
            <XAxis 
              dataKey="day" 
              stroke="#130b3d" 
              strokeOpacity={0.5}
              style={{ fontSize: '12px', fontFamily: 'Inter' }}
              axisLine={false}
              tickLine={false}
            />
            <YAxis 
              domain={[36, 37]} 
              stroke="#130b3d" 
              strokeOpacity={0.5}
              style={{ fontSize: '12px', fontFamily: 'Inter' }}
              axisLine={false}
              tickLine={false}
            />
            <Tooltip 
              contentStyle={{ 
                backgroundColor: 'rgba(252, 239, 221, 0.95)', 
                border: 'none', 
                borderRadius: '12px', 
                fontFamily: 'Inter', 
                color: '#130b3d',
                boxShadow: '0 4px 12px rgba(0,0,0,0.1)'
              }} 
            />
            <Area 
              type="monotone" 
              dataKey="temp" 
              stroke="#f58020" 
              strokeWidth={3}
              fill="url(#tempGradient)"
              dot={{ fill: '#f58020', r: 6, strokeWidth: 3, stroke: '#fff' }}
              activeDot={{ r: 8, strokeWidth: 3, stroke: '#fff' }}
              onClick={onTemperatureClick}
            />
          </AreaChart>
        </ResponsiveContainer>
      </motion.div>

      {/* Heart Rate Chart */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="bg-[rgba(252,239,221,0.5)] backdrop-blur-xl border border-white shadow-lg rounded-3xl p-5"
      >
        <div className="flex items-center justify-between mb-4">
          <div>
            <h4 className="font-['Ninetea:Bold',sans-serif] text-[#130b3d]">Frecuencia Cardíaca</h4>
            <p className="font-['Inter:Regular',sans-serif] text-sm text-[#130b3d]">Reposo vs. Sueño</p>
          </div>
          <div className="flex items-center gap-1 text-[#2271b8]">
            <TrendingDown className="w-4 h-4" />
            <span className="font-['Inter:Bold',sans-serif] text-sm">Estable</span>
          </div>
        </div>
        <ResponsiveContainer width="100%" height={200}>
          <AreaChart data={heartRateData} margin={{ top: 5, right: 5, left: -20, bottom: 5 }}>
            <defs>
              <linearGradient id="heartRateGradient" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#f58020" stopOpacity={0.3}/>
                <stop offset="95%" stopColor="#f58020" stopOpacity={0.05}/>
              </linearGradient>
              <linearGradient id="sleepingGradient" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#2271b8" stopOpacity={0.3}/>
                <stop offset="95%" stopColor="#2271b8" stopOpacity={0.05}/>
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="#e5d4c1" strokeOpacity={0.3} />
            <XAxis 
              dataKey="day" 
              stroke="#130b3d" 
              strokeOpacity={0.5}
              style={{ fontSize: '12px', fontFamily: 'Inter' }}
              axisLine={false}
              tickLine={false}
            />
            <YAxis 
              domain={[50, 80]} 
              stroke="#130b3d" 
              strokeOpacity={0.5}
              style={{ fontSize: '12px', fontFamily: 'Inter' }}
              axisLine={false}
              tickLine={false}
            />
            <Tooltip 
              contentStyle={{ 
                backgroundColor: 'rgba(252, 239, 221, 0.95)', 
                border: 'none', 
                borderRadius: '12px', 
                fontFamily: 'Inter', 
                color: '#130b3d',
                boxShadow: '0 4px 12px rgba(0,0,0,0.1)'
              }} 
            />
            <Area 
              type="monotone" 
              dataKey="rate" 
              stroke="#f58020" 
              strokeWidth={3}
              fill="url(#heartRateGradient)"
              name="Reposo"
              dot={{ fill: '#f58020', r: 5, strokeWidth: 2, stroke: '#fff' }}
              activeDot={{ r: 7, strokeWidth: 2, stroke: '#fff' }}
              onClick={onHeartRateClick}
            />
            <Area 
              type="monotone" 
              dataKey="sleeping" 
              stroke="#2271b8" 
              strokeWidth={3}
              fill="url(#sleepingGradient)"
              name="Sueño"
              dot={{ fill: '#2271b8', r: 5, strokeWidth: 2, stroke: '#fff' }}
              activeDot={{ r: 7, strokeWidth: 2, stroke: '#fff' }}
            />
          </AreaChart>
        </ResponsiveContainer>
      </motion.div>

      {/* Sleep Quality Chart */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="bg-[rgba(252,239,221,0.5)] backdrop-blur-xl border border-white shadow-lg rounded-3xl p-5"
      >
        <div className="flex items-center justify-between mb-4">
          <div>
            <h4 className="font-['Ninetea:Bold',sans-serif] text-[#130b3d]">Calidad de Sueño</h4>
            <p className="font-['Inter:Regular',sans-serif] text-sm text-[#130b3d]">Porcentaje y horas</p>
          </div>
          <div className="flex items-center gap-1 text-[#f58020]">
            {sleepTrendUp ? <TrendingUp className="w-4 h-4" /> : <TrendingDown className="w-4 h-4" />}
            <span className="font-['Inter:Bold',sans-serif] text-sm">{sleepTrend}</span>
          </div>
        </div>
        <ResponsiveContainer width="100%" height={200}>
          <AreaChart data={sleepData} margin={{ top: 5, right: 5, left: -20, bottom: 5 }}>
            <defs>
              <linearGradient id="sleepGradient" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#ea4c89" stopOpacity={0.5}/>
                <stop offset="50%" stopColor="#f58020" stopOpacity={0.3}/>
                <stop offset="95%" stopColor="#f58020" stopOpacity={0.05}/>
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="#e5d4c1" strokeOpacity={0.3} />
            <XAxis 
              dataKey="day" 
              stroke="#130b3d" 
              strokeOpacity={0.5}
              style={{ fontSize: '12px', fontFamily: 'Inter' }}
              axisLine={false}
              tickLine={false}
            />
            <YAxis 
              domain={[0, 100]} 
              stroke="#130b3d" 
              strokeOpacity={0.5}
              style={{ fontSize: '12px', fontFamily: 'Inter' }}
              axisLine={false}
              tickLine={false}
            />
            <Tooltip 
              contentStyle={{ 
                backgroundColor: 'rgba(252, 239, 221, 0.95)', 
                border: 'none', 
                borderRadius: '12px', 
                fontFamily: 'Inter', 
                color: '#130b3d',
                boxShadow: '0 4px 12px rgba(0,0,0,0.1)'
              }} 
            />
            <Area 
              type="monotone" 
              dataKey="quality" 
              stroke="#ea4c89" 
              strokeWidth={3}
              fill="url(#sleepGradient)"
              dot={{ fill: '#ea4c89', r: 6, strokeWidth: 3, stroke: '#fff' }}
              activeDot={{ r: 8, strokeWidth: 3, stroke: '#fff' }}
              onClick={onSleepClick}
            />
          </AreaChart>
        </ResponsiveContainer>
        <div className="mt-3 text-center">
          <p className="font-['Inter:Regular',sans-serif] text-sm text-[#130b3d]">Promedio: {avgSleepHours} horas/noche</p>
        </div>
      </motion.div>

      {/* AI Insights */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3 }}
        className="bg-[rgba(252,239,221,0.5)] backdrop-blur-xl border border-white shadow-lg rounded-3xl p-5"
      >
        <div className="flex items-center justify-center gap-2 mb-3">
          <Sparkles className="w-5 h-5 text-[#f58020]" />
          <h3 className="font-['Ninetea:Bold',sans-serif] text-[#130b3d] text-[18px]">Insights de IA</h3>
        </div>
        <h4 className="font-['Inter:Bold',sans-serif] text-[#130b3d] text-center mb-2">{aiInsight.title}</h4>
        <p className="font-['Inter:Regular',sans-serif] text-sm text-[#130b3d] leading-relaxed">{aiInsight.message}</p>
        <div className="mt-4 space-y-2">
          {aiInsight.tips.map((tip, index) => (
            <div key={index} className="flex items-start gap-2">
              <div className="w-1.5 h-1.5 rounded-full bg-[#f58020] mt-2 flex-shrink-0"></div>
              <p className="font-['Inter:Regular',sans-serif] text-sm text-[#130b3d] flex-1">{tip}</p>
            </div>
          ))}
        </div>
      </motion.div>
    </div>
  );
}
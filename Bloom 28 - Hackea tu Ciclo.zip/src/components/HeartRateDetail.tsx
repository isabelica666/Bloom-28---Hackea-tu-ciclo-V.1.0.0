import { motion } from 'motion/react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';
import { ArrowLeft, Heart, Activity, Sparkles } from 'lucide-react';
import { calculateCycleInfo, type CycleData } from '../utils/cycleCalculations';
import { generateLast7DaysData, calculateAverages } from '../utils/biometricData';

interface HeartRateDetailProps {
  cycleData: CycleData;
  onBack: () => void;
}

export function HeartRateDetail({ cycleData, onBack }: HeartRateDetailProps) {
  const cycleInfo = calculateCycleInfo(cycleData);
  const currentPhase = cycleInfo.currentPhase;

  // Generar datos de los últimos 7 días basados en la fase actual
  const last7DaysData = generateLast7DaysData(currentPhase);
  const heartRateData = last7DaysData.map(d => ({ 
    day: d.day, 
    rate: d.heartRate, 
    sleeping: d.heartRateSleep 
  }));
  const { avgHeartRate } = calculateAverages(last7DaysData);

  // Insights específicos de frecuencia cardíaca según la fase
  const getHeartRateInsights = () => {
    const insights = {
      menstrual: {
        title: "Frecuencia Cardíaca Ligeramente Elevada",
        message: "Durante la menstruación, tu frecuencia cardíaca en reposo (FC) puede ser ligeramente más alta (68 bpm promedio) debido a la inflamación natural y el trabajo que realiza tu cuerpo. Los niveles bajos de estrógeno y progesterona también contribuyen a esta elevación temporal.",
        tips: [
          "FC en reposo 2-5 bpm más alta de lo normal es común durante el período",
          "La FC elevada refleja el esfuerzo metabólico del cuerpo durante la menstruación",
          "Evita entrenamientos de alta intensidad si tu FC en reposo es inusualmente alta (>75 bpm)",
          "Una FC nocturna más alta puede indicar peor calidad de sueño - prioriza el descanso"
        ],
        interpretation: "El aumento en la frecuencia cardíaca durante la menstruación es normal y temporal. El cuerpo está trabajando para renovar el revestimiento uterino, lo que genera inflamación sistémica leve y aumenta el gasto energético.",
        comparison: "Tu FC en reposo actual (68 bpm) vs. FC durante el sueño (60 bpm) muestra una diferencia saludable de 8 bpm, indicando buena recuperación nocturna."
      },
      folicular: {
        title: "Frecuencia Cardíaca Óptima - Mejor Momento",
        message: "Tu frecuencia cardíaca en reposo está en su punto más bajo del ciclo (65 bpm promedio). El estrógeno en aumento mejora la función cardiovascular, dilata los vasos sanguíneos y optimiza el volumen sistólico, permitiendo que tu corazón bombee más eficientemente.",
        tips: [
          "FC en reposo baja (60-65 bpm) indica excelente condición cardiovascular",
          "Esta es la fase ideal para entrenamientos intensos y pruebas de rendimiento",
          "Tu cuerpo se recupera más rápido del ejercicio en esta fase",
          "La variabilidad de FC alta durante esta fase es señal de buena salud"
        ],
        interpretation: "La fase folicular es tu ventana óptima de rendimiento cardiovascular. El estrógeno actúa como vasodilatador natural, mejorando el flujo sanguíneo y reduciendo la frecuencia cardíaca en reposo mientras aumenta tu capacidad de ejercicio.",
        comparison: "FC en reposo (65 bpm) vs. FC durante sueño (57 bpm) - una diferencia de 8 bpm es perfecta y refleja excelente recuperación."
      },
      ovulacion: {
        title: "Pico de Frecuencia Cardíaca - Ovulación",
        message: "Tu frecuencia cardíaca ha aumentado a 70 bpm, un patrón típico durante la ovulación. El pico de estrógeno y el inicio de la producción de progesterona causan este aumento temporal. También puede deberse al aumento de la temperatura corporal durante esta fase.",
        tips: [
          "FC 3-5 bpm más alta de lo normal confirma que estás ovulando",
          "Este aumento es temporal y coincide con el pico de fertilidad",
          "A pesar de la FC elevada, tu capacidad de ejercicio está en su máximo",
          "Monitorea tu FC en reposo matutina para detectar este patrón mensual"
        ],
        interpretation: "El aumento de la frecuencia cardíaca durante la ovulación es causado por cambios hormonales rápidos y el aumento de la temperatura basal. Este es un biomarcador confiable que, combinado con la temperatura, confirma la ovulación.",
        comparison: "FC en reposo (70 bpm) vs. FC durante sueño (62 bpm) - la diferencia se mantiene saludable a pesar del aumento general."
      },
      lutea: {
        title: "Frecuencia Cardíaca Moderada - Fase Lútea",
        message: "Tu frecuencia cardíaca se mantiene ligeramente elevada (67 bpm) debido a la progesterona, que aumenta la temperatura corporal y el metabolismo basal. Es normal sentir que tu corazón trabaja un poco más durante esta fase, especialmente durante el ejercicio.",
        tips: [
          "FC 2-4 bpm más alta que en fase folicular es completamente normal",
          "La progesterona reduce ligeramente el volumen sistólico, aumentando la FC",
          "Ajusta la intensidad de tus entrenamientos si tu FC en reposo está muy elevada (>72 bpm)",
          "Una FC nocturna más alta puede señalar menor calidad de sueño pre-menstrual"
        ],
        interpretation: "La frecuencia cardíaca elevada en la fase lútea refleja el efecto metabólico de la progesterona. Esta hormona aumenta la temperatura corporal y el gasto energético en reposo, lo que naturalmente eleva la FC basal.",
        comparison: "FC en reposo (67 bpm) vs. FC durante sueño (59 bpm) - diferencia normal que muestra adaptación al aumento hormonal."
      }
    };

    return insights[currentPhase as keyof typeof insights] || insights.folicular;
  };

  const heartRateInsight = getHeartRateInsights();

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#ffe0c6] to-[#f5ebc3] pb-6">
      {/* Header */}
      <div className="sticky top-0 z-10 bg-gradient-to-b from-[#ffe0c6] to-transparent backdrop-blur-sm pb-4">
        <div className="flex items-center justify-between px-6 pt-6 pb-2">
          <button
            onClick={onBack}
            className="p-2 hover:bg-[rgba(252,239,221,0.5)] rounded-full transition-colors"
          >
            <ArrowLeft className="w-6 h-6 text-[#130b3d]" />
          </button>
          <h1 className="font-['Ninetea:Bold',sans-serif] text-[24px] text-[#130b3d]">Frecuencia Cardíaca</h1>
          <div className="w-10" /> {/* Spacer for centering */}
        </div>
      </div>

      <div className="px-6 space-y-6">
        {/* Current Value Card */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="bg-[rgba(252,239,221,0.5)] backdrop-blur-xl border border-white shadow-lg rounded-3xl p-6"
        >
          <div className="flex items-center justify-center mb-4">
            <Heart className="w-12 h-12 text-[#f58020]" strokeWidth={1.5} />
          </div>
          <div className="text-center">
            <p className="font-['Ninetea:Bold',sans-serif] text-[48px] text-[#130b3d] leading-none mb-1">
              {avgHeartRate}
            </p>
            <p className="font-['Inter:Regular',sans-serif] text-sm text-[#130b3d] opacity-70 mb-3">
              BPM en reposo
            </p>
            <p className="font-['Inter:Regular',sans-serif] text-sm text-[#130b3d]">
              Promedio últimos 7 días
            </p>
          </div>
        </motion.div>

        {/* Heart Rate Chart */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="bg-[rgba(252,239,221,0.5)] backdrop-blur-xl border border-white shadow-lg rounded-3xl p-6"
        >
          <h3 className="font-['Ninetea:Bold',sans-serif] text-[#130b3d] mb-4 text-center">
            Reposo vs. Sueño - Últimos 7 días
          </h3>
          <ResponsiveContainer width="100%" height={280}>
            <AreaChart data={heartRateData} margin={{ top: 10, right: 10, left: -15, bottom: 10 }}>
              <defs>
                <linearGradient id="heartRateGradientDetail" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#f58020" stopOpacity={0.4}/>
                  <stop offset="95%" stopColor="#f58020" stopOpacity={0.05}/>
                </linearGradient>
                <linearGradient id="sleepingGradientDetail" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#2271b8" stopOpacity={0.4}/>
                  <stop offset="95%" stopColor="#2271b8" stopOpacity={0.05}/>
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#e5d4c1" strokeOpacity={0.3} />
              <XAxis 
                dataKey="day" 
                stroke="#130b3d" 
                strokeOpacity={0.5}
                style={{ fontSize: '12px', fontFamily: 'Inter' }}
                axisLine={false}
                tickLine={false}
              />
              <YAxis 
                domain={[50, 80]} 
                stroke="#130b3d" 
                strokeOpacity={0.5}
                style={{ fontSize: '12px', fontFamily: 'Inter' }}
                axisLine={false}
                tickLine={false}
              />
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: 'rgba(252, 239, 221, 0.95)', 
                  border: 'none', 
                  borderRadius: '12px', 
                  fontFamily: 'Inter', 
                  color: '#130b3d',
                  boxShadow: '0 4px 12px rgba(0,0,0,0.1)'
                }} 
              />
              <Legend 
                wrapperStyle={{ fontFamily: 'Inter', fontSize: '12px' }}
                iconType="circle"
              />
              <Area 
                type="monotone" 
                dataKey="rate" 
                stroke="#f58020" 
                strokeWidth={3}
                fill="url(#heartRateGradientDetail)"
                name="Reposo"
                dot={{ fill: '#f58020', r: 6, strokeWidth: 3, stroke: '#fff' }}
                activeDot={{ r: 8, strokeWidth: 3, stroke: '#fff' }}
              />
              <Area 
                type="monotone" 
                dataKey="sleeping" 
                stroke="#2271b8" 
                strokeWidth={3}
                fill="url(#sleepingGradientDetail)"
                name="Sueño"
                dot={{ fill: '#2271b8', r: 6, strokeWidth: 3, stroke: '#fff' }}
                activeDot={{ r: 8, strokeWidth: 3, stroke: '#fff' }}
              />
            </AreaChart>
          </ResponsiveContainer>
        </motion.div>

        {/* AI Insights */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="bg-[rgba(252,239,221,0.5)] backdrop-blur-xl border border-white shadow-lg rounded-3xl p-6"
        >
          <div className="flex items-center justify-center gap-2 mb-4">
            <Sparkles className="w-6 h-6 text-[#f58020]" />
            <h3 className="font-['Ninetea:Bold',sans-serif] text-[#130b3d] text-[20px]">Insight de IA</h3>
          </div>
          
          <h4 className="font-['Inter:Bold',sans-serif] text-[#130b3d] text-center mb-3 text-lg">
            {heartRateInsight.title}
          </h4>
          
          <p className="font-['Inter:Regular',sans-serif] text-sm text-[#130b3d] leading-relaxed mb-4">
            {heartRateInsight.message}
          </p>

          <div className="bg-[rgba(245,235,195,0.5)] rounded-2xl p-4 mb-4">
            <h5 className="font-['Inter:Bold',sans-serif] text-sm text-[#130b3d] mb-2">
              🔍 Interpretación:
            </h5>
            <p className="font-['Inter:Regular',sans-serif] text-sm text-[#130b3d] leading-relaxed mb-3">
              {heartRateInsight.interpretation}
            </p>
            <div className="flex items-center gap-2 mt-3 pt-3 border-t border-[rgba(19,11,61,0.1)]">
              <Activity className="w-4 h-4 text-[#2271b8]" />
              <p className="font-['Inter:Regular',sans-serif] text-xs text-[#130b3d] leading-relaxed">
                {heartRateInsight.comparison}
              </p>
            </div>
          </div>

          <h5 className="font-['Inter:Bold',sans-serif] text-sm text-[#130b3d] mb-3">
            💡 Recomendaciones:
          </h5>
          <div className="space-y-3">
            {heartRateInsight.tips.map((tip, index) => (
              <div key={index} className="flex items-start gap-3">
                <div className="w-2 h-2 rounded-full bg-[#2271b8] mt-1.5 flex-shrink-0"></div>
                <p className="font-['Inter:Regular',sans-serif] text-sm text-[#130b3d] flex-1 leading-relaxed">
                  {tip}
                </p>
              </div>
            ))}
          </div>
        </motion.div>
      </div>
    </div>
  );
}
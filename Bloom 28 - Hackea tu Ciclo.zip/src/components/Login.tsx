import { useState } from 'react';
import svgPaths from "../imports/svg-nb1k2hgc5x";

interface LoginProps {
  onLogin: () => void;
  onBack: () => void;
  onGoToRegister: () => void;
  onShowTerms?: () => void;
}

export function Login({ onLogin, onBack, onGoToRegister, onShowTerms }: LoginProps) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [acceptTerms, setAcceptTerms] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!acceptTerms) {
      alert('Debes aceptar los Términos y Condiciones para continuar');
      return;
    }
    onLogin();
  };

  return (
    <div className="bg-gradient-to-b from-[#ffe0c6] to-[#f5ebc3] min-h-screen overflow-hidden relative w-full max-w-md mx-auto">
      {/* Home Indicator */}
      <div className="absolute bottom-0 h-[34px] left-1/2 translate-x-[-50%] w-[393px]">
        <div className="absolute h-[34px] left-0 right-0 top-0" />
        <div className="absolute bottom-[7.67px] flex h-[5px] items-center justify-center left-1/2 translate-x-[-50%] w-[139.938px]">
          <div className="flex-none rotate-[180deg] scale-y-[-100%]">
            <div className="bg-[#121212] h-[5px] rounded-[100px] w-[139.938px]" />
          </div>
        </div>
      </div>

      {/* Decorative blur circle - Pink */}
      <div className="absolute flex inset-[3.29%_-26.93%_65.95%_67.18%] items-center justify-center">
        <div className="flex-none h-[179.29px] rotate-[226.129deg] skew-x-[6.174deg] w-[172.813px]">
          <div className="relative size-full">
            <div className="absolute inset-[-83.66%_-86.8%]">
              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 473 480">
                <g filter="url(#filter0_f_8_2194)" opacity="0.8">
                  <ellipse cx="236.407" cy="239.645" fill="#FD587A" fillOpacity="0.24" rx="86.4067" ry="89.6449" />
                </g>
                <defs>
                  <filter colorInterpolationFilters="sRGB" filterUnits="userSpaceOnUse" height="479.29" id="filter0_f_8_2194" width="472.813" x="0" y="0">
                    <feFlood floodOpacity="0" result="BackgroundImageFix" />
                    <feBlend in="SourceGraphic" in2="BackgroundImageFix" mode="normal" result="shape" />
                    <feGaussianBlur result="effect1_foregroundBlur_8_2194" stdDeviation="75" />
                  </filter>
                </defs>
              </svg>
            </div>
          </div>
        </div>
      </div>

      {/* Status Bar */}
      <div className="absolute h-[44px] left-0 overflow-clip top-0 w-full max-w-[393px]">
        <div className="absolute h-[30px] left-1/2 top-[-2px] translate-x-[-50%] w-[219px]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 219 30">
            <path d={svgPaths.p7f98200} fill="#121212" />
          </svg>
        </div>
        <p className="absolute font-['SF_Pro_Text:Semibold',sans-serif] leading-[21px] left-[32px] not-italic text-[#121212] text-[15px] text-nowrap top-[13px] tracking-[-0.32px] whitespace-pre">
          9:41
        </p>
        
        {/* Status Bar Icons */}
        <div className="absolute content-stretch flex gap-[2px] items-start right-[15px] top-[15px]">
          {/* Mobile Signal */}
          <div className="h-[16px] relative shrink-0 w-[20px]">
            <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 16">
              <path d={svgPaths.p15d4ae30} fill="#121212" />
            </svg>
          </div>
          
          {/* Wifi */}
          <div className="relative shrink-0 size-[16px]">
            <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
              <path d={svgPaths.p382fcb80} fill="#121212" />
            </svg>
          </div>
          
          {/* Battery */}
          <div className="h-[16px] relative shrink-0 w-[25px]">
            <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 25 16">
              <g clipPath="url(#clip0_8_2169)">
                <path d={svgPaths.p15509f50} opacity="0.35" stroke="#121212" />
                <path d={svgPaths.p307e0200} fill="#121212" opacity="0.4" />
                <path d={svgPaths.p365f7580} fill="#121212" />
              </g>
              <defs>
                <clipPath id="clip0_8_2169">
                  <rect fill="white" height="16" width="25" />
                </clipPath>
              </defs>
            </svg>
          </div>
        </div>
      </div>

      {/* Back button */}
      <div className="absolute left-[24px] top-[68px] w-[345px]">
        <button
          onClick={onBack}
          className="w-[40px] h-[40px]"
        >
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 40 40">
            <path d={svgPaths.p3647d300} stroke="#BDBDBD" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
            <path d={svgPaths.pe03b900} stroke="#292929" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          </svg>
        </button>
      </div>

      {/* Logo "8" */}
      <p className="absolute font-['Gebuk:Regular',sans-serif] leading-[normal] left-1/2 -translate-x-1/2 not-italic text-[#130b3d] text-[63.629px] text-center text-nowrap top-[67px] whitespace-pre">
        8
      </p>

      {/* Main Content */}
      <div className="absolute left-[33px] top-[180px] w-[333.378px]">
        {/* Title */}
        <div className="font-['Ninetea:Bold',sans-serif] leading-[1.3] not-italic text-[30.434px] tracking-[-0.3043px] mb-[70px]">
          <p className="mb-[2.01437px] text-[#f58020]">Bienvenida!</p>
          <p className="text-[#130b3d]">Nos alegra verte otra vez!</p>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-[15px]">
          {/* Email Input */}
          <div className="relative">
            <div className="bg-[rgba(255,255,255,0.42)] border-[1.007px] border-solid border-white h-[56.402px] rounded-[27.698px] w-full" />
            <input
              type="email"
              placeholder="Email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              className="absolute inset-0 bg-transparent px-[18px] font-['Ninetea:Medium',sans-serif] text-[#130b3d] text-[13.093px] outline-none w-full [&:-webkit-autofill]:bg-transparent [&:-webkit-autofill]:[-webkit-text-fill-color:#130b3d] [&:-webkit-autofill]:shadow-[0_0_0px_1000px_rgba(255,255,255,0.42)_inset]"
            />
          </div>

          {/* Password Input */}
          <div className="relative">
            <div className="bg-[rgba(255,255,255,0.42)] border-[1.007px] border-solid border-white h-[56.402px] rounded-[27.698px] w-full" />
            <input
              type={showPassword ? "text" : "password"}
              placeholder="Contraseña"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              className="absolute inset-0 bg-transparent px-[18px] font-['Ninetea:Medium',sans-serif] text-[#130b3d] text-[13.093px] outline-none w-full pr-[50px]"
            />
            <button
              type="button"
              onClick={() => setShowPassword(!showPassword)}
              className="absolute right-[18px] top-1/2 -translate-y-1/2 w-[22.158px] h-[22.158px]"
            >
              <svg className="block size-full" fill="none" viewBox="0 0 18 12">
                <path d={svgPaths.p37ea0d00} fill="#130B3D" />
              </svg>
            </button>
          </div>

          {/* Forgot Password */}
          <div className="text-right">
            <button
              type="button"
              className="font-['Ninetea:Semi_Bold',sans-serif] text-[#130b3d] text-[12.086px]"
            >
              Olvidaste tu contraseña?
            </button>
          </div>

          {/* Terms and Conditions Checkbox */}
          <div className="flex items-start gap-3 pt-[10px]">
            <div className="relative flex-shrink-0">
              <input
                type="checkbox"
                id="terms-login"
                checked={acceptTerms}
                onChange={(e) => setAcceptTerms(e.target.checked)}
                className="peer sr-only"
              />
              <label
                htmlFor="terms-login"
                className="flex items-center justify-center w-[24px] h-[24px] rounded-[8px] border-[2px] border-[#130b3d] bg-[rgba(255,255,255,0.42)] cursor-pointer peer-checked:bg-[#f58020] peer-checked:border-[#f58020] transition-all duration-200"
              >
                {acceptTerms && (
                  <svg className="w-[14px] h-[14px]" viewBox="0 0 14 14" fill="none">
                    <path d="M2 7L5.5 10.5L12 3.5" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                  </svg>
                )}
              </label>
            </div>
            <label htmlFor="terms-login" className="font-['Ninetea:Medium',sans-serif] text-[#130b3d] text-[13.093px] leading-[1.4] flex-1">
              Acepto los{' '}
              <button
                type="button"
                onClick={(e) => {
                  e.preventDefault();
                  onShowTerms?.();
                }}
                className="text-[#f58020] font-['Ninetea:Bold',sans-serif] underline decoration-[#f58020]"
              >
                Términos y Condiciones
              </button>{' '}
              de registro en Bloom
            </label>
          </div>

          {/* Submit Button */}
          <div className="pt-[30px]">
            <button
              type="submit"
              className="bg-[rgba(245,128,32,0.8)] backdrop-blur-xl border border-white shadow-lg rounded-[27.698px] h-[56px] w-full flex items-center justify-center"
            >
              <p className="font-['Ninetea:Semi_Bold',sans-serif] leading-[normal] text-[#fbeedc] text-[15.108px] text-center">
                Ingresar
              </p>
            </button>
          </div>
        </form>

        {/* Sign up link */}
        <div className="mt-[80px] text-center font-['Poppins:SemiBold',sans-serif] leading-[1.4] text-[16.112px] tracking-[0.1611px]">
          <p className="font-['Ninetea:Medium',sans-serif] mb-0 text-[#130b3d]">
            No tienes una cuenta?{" "}
          </p>
          <button
            type="button"
            onClick={onGoToRegister}
            className="font-['Ninetea:Bold',sans-serif] text-[#f58020]"
          >
            Regístrate Ahora
          </button>
        </div>
      </div>
    </div>
  );
}
import { motion } from 'motion/react';
import { ArrowLeft, Check, Activity, Brain, Droplet, Heart, Zap, BatteryLow, AlertCircle, Sparkles, Droplets, Ban, Loader, Flame, TrendingUp, CloudLightning, AlertTriangle, CloudRain, Cookie, EyeOff, HeartOff, UserX, Shield, Stethoscope } from 'lucide-react';
import { useState } from 'react';

interface SymptomsProps {
  onBack: () => void;
}

export function Symptoms({ onBack }: SymptomsProps) {
  const [selectedSymptoms, setSelectedSymptoms] = useState<string[]>([]);

  const physicalSymptoms = [
    { id: 'cramping', label: 'Cólicos', icon: Activity },
    { id: 'headache', label: 'Dolor de cabeza', icon: Brain },
    { id: 'bloating', label: 'Hinchazón', icon: Droplet },
    { id: 'breast-tenderness', label: 'Sensibilidad en senos', icon: Shield },
    { id: 'back-pain', label: 'Dolor de espalda', icon: Zap },
    { id: 'fatigue', label: 'Fatiga', icon: BatteryLow },
    { id: 'nausea', label: 'Náuseas', icon: AlertCircle },
    { id: 'acne', label: 'Acné', icon: Sparkles },
    { id: 'diarrhea', label: 'Diarrea', icon: Droplets },
    { id: 'constipation', label: 'Estreñimiento', icon: Ban },
    { id: 'dizziness', label: 'Mareos', icon: Loader },
    { id: 'hot-flashes', label: 'Sofocos', icon: Flame }
  ];

  const psychologicalSymptoms = [
    { id: 'mood-swings', label: 'Cambios de humor', icon: TrendingUp },
    { id: 'anxiety', label: 'Ansiedad', icon: CloudLightning },
    { id: 'irritability', label: 'Irritabilidad', icon: AlertTriangle },
    { id: 'sadness', label: 'Tristeza', icon: CloudRain },
    { id: 'difficulty-concentrating', label: 'Dificultad para concentrarse', icon: Brain },
    { id: 'food-cravings', label: 'Antojos', icon: Cookie },
    { id: 'insomnia', label: 'Insomnio', icon: EyeOff },
    { id: 'low-libido', label: 'Libido bajo', icon: HeartOff },
    { id: 'social-withdrawal', label: 'Aislamiento social', icon: UserX },
    { id: 'sensitivity', label: 'Sensibilidad emocional', icon: Heart }
  ];

  const toggleSymptom = (symptomId: string) => {
    setSelectedSymptoms(prev => 
      prev.includes(symptomId) 
        ? prev.filter(id => id !== symptomId)
        : [...prev, symptomId]
    );
  };

  const handleSave = () => {
    // Aquí se guardaría la información en el backend/localStorage
    console.log('Síntomas guardados:', selectedSymptoms);
    onBack();
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#ffe0c6] to-[#f5ebc3] pb-24">
      {/* Header */}
      <div className="sticky top-0 bg-gradient-to-r from-[#f58020] to-[#ef932d] px-6 py-5 shadow-lg z-10">
        <div className="flex items-center justify-between">
          <button 
            onClick={onBack}
            className="p-2 hover:bg-white/20 rounded-full transition-colors"
          >
            <ArrowLeft className="w-6 h-6 text-white" />
          </button>
          <h1 className="font-['Ninetea:Bold',sans-serif] text-white text-xl">
            Registrar Síntomas
          </h1>
          <button
            onClick={handleSave}
            className="px-4 py-2 bg-white text-[#f58020] rounded-full font-['Ninetea:Semi_Bold',sans-serif] text-sm hover:bg-[#fbeedc] transition-colors"
          >
            Guardar
          </button>
        </div>
      </div>

      <div className="p-6 space-y-6">
        {/* Date Info */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-[#fcefdd] rounded-2xl p-4 text-center"
        >
          <p className="font-['Inter:Regular',sans-serif] text-sm text-[#130b3d]">
            Registro de hoy: <span className="font-['Inter:Bold',sans-serif]">{new Date().toLocaleDateString('es-ES', { day: 'numeric', month: 'long', year: 'numeric' })}</span>
          </p>
        </motion.div>

        {/* Physical Symptoms */}
        <div>
          <h2 className="font-['Ninetea:Bold',sans-serif] text-[#130b3d] text-lg mb-4 flex items-center gap-2">
            <Stethoscope className="w-6 h-6 text-[#2271b8]" strokeWidth={2} />
            Síntomas Físicos
          </h2>
          <div className="grid grid-cols-2 gap-3">
            {physicalSymptoms.map((symptom, index) => {
              const IconComponent = symptom.icon;
              return (
                <motion.button
                  key={symptom.id}
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: index * 0.05 }}
                  onClick={() => toggleSymptom(symptom.id)}
                  className={`relative p-4 rounded-2xl transition-all ${
                    selectedSymptoms.includes(symptom.id)
                      ? 'bg-gradient-to-r from-[#2271b8] to-[#5250a2] text-white shadow-lg scale-95'
                      : 'bg-[#fcefdd] text-[#130b3d] shadow-md hover:shadow-lg'
                  }`}
                >
                  <div className="flex flex-col items-center gap-2">
                    <IconComponent className="w-8 h-8" strokeWidth={1.5} />
                    <span className="font-['Inter:Semi_Bold',sans-serif] text-xs text-center leading-tight">
                      {symptom.label}
                    </span>
                    {selectedSymptoms.includes(symptom.id) && (
                      <div className="absolute top-2 right-2 w-5 h-5 bg-white rounded-full flex items-center justify-center">
                        <Check className="w-3 h-3 text-[#2271b8]" strokeWidth={3} />
                      </div>
                    )}
                  </div>
                </motion.button>
              );
            })}
          </div>
        </div>

        {/* Psychological Symptoms */}
        <div>
          <h2 className="font-['Ninetea:Bold',sans-serif] text-[#130b3d] text-lg mb-4 flex items-center gap-2">
            <Brain className="w-6 h-6 text-[#f58020]" strokeWidth={2} />
            Síntomas Emocionales
          </h2>
          <div className="grid grid-cols-2 gap-3">
            {psychologicalSymptoms.map((symptom, index) => {
              const IconComponent = symptom.icon;
              return (
                <motion.button
                  key={symptom.id}
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: (physicalSymptoms.length + index) * 0.05 }}
                  onClick={() => toggleSymptom(symptom.id)}
                  className={`relative p-4 rounded-2xl transition-all ${
                    selectedSymptoms.includes(symptom.id)
                      ? 'bg-gradient-to-r from-[#f58020] to-[#ef932d] text-white shadow-lg scale-95'
                      : 'bg-[#fcefdd] text-[#130b3d] shadow-md hover:shadow-lg'
                  }`}
                >
                  <div className="flex flex-col items-center gap-2">
                    <IconComponent className="w-8 h-8" strokeWidth={1.5} />
                    <span className="font-['Inter:Semi_Bold',sans-serif] text-xs text-center leading-tight">
                      {symptom.label}
                    </span>
                    {selectedSymptoms.includes(symptom.id) && (
                      <div className="absolute top-2 right-2 w-5 h-5 bg-white rounded-full flex items-center justify-center">
                        <Check className="w-3 h-3 text-[#f58020]" strokeWidth={3} />
                      </div>
                    )}
                  </div>
                </motion.button>
              );
            })}
          </div>
        </div>

        {/* Summary */}
        {selectedSymptoms.length > 0 && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-gradient-to-r from-[#2271b8] to-[#5250a2] rounded-2xl p-5 shadow-lg"
          >
            <h3 className="font-['Ninetea:Bold',sans-serif] text-white mb-2">
              Resumen
            </h3>
            <p className="font-['Inter:Regular',sans-serif] text-[#fbeedc] text-sm">
              Has seleccionado <span className="font-['Inter:Bold',sans-serif] text-white">{selectedSymptoms.length}</span> síntoma{selectedSymptoms.length !== 1 ? 's' : ''}
            </p>
          </motion.div>
        )}
      </div>
    </div>
  );
}
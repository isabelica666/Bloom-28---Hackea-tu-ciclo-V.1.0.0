import { ArrowLeft, Heart, Zap, Activity } from 'lucide-react';

interface ProfileSetupWearableProps {
  onContinue: () => void;
  onBack: () => void;
}

export function ProfileSetupWearable({ onContinue, onBack }: ProfileSetupWearableProps) {
  return (
    <div className="min-h-screen bg-gradient-to-b from-[#ffe0c6] to-[#f5ebc3] relative">
      {/* Status bar placeholder */}
      <div className="h-8" />

      {/* Back button */}
      <div className="px-6 py-2">
        <button
          onClick={onBack}
          className="flex items-center justify-center w-10 h-10 rounded-xl bg-[rgba(255,255,255,0.5)] backdrop-blur-xl border border-white shadow-lg"
        >
          <ArrowLeft className="w-5 h-5 text-[#130b3d]" />
        </button>
      </div>

      {/* Progress indicators */}
      <div className="flex gap-[7px] justify-center mb-4">
        <div className="h-[5px] w-[47px] bg-[#f58020] rounded-full" />
        <div className="h-[5px] w-[47px] bg-[#f58020] rounded-full" />
        <div className="h-[5px] w-[47px] bg-[#f58020] rounded-full" />
        <div className="h-[5px] w-[47px] bg-[#f58020] rounded-full" />
      </div>

      {/* Decorative blur */}
      <div className="absolute top-8 right-[-40px] w-40 h-40 opacity-30">
        <div className="w-full h-full rounded-full bg-[#FD587A] blur-[75px]" />
      </div>

      {/* Content */}
      <div className="px-6 flex flex-col items-center">
        {/* Title */}
        <h1 className="font-['Ninetea:Semi_Bold',sans-serif] text-[30px] text-[#f58020] mb-1 text-center">
          Conectar Wearable
        </h1>
        <p className="font-['Inter:Regular',sans-serif] text-[#130b3d] text-[14px] text-center mb-5">
          Obtén datos mas precisos conectando tu dispositivo
        </p>

        {/* Share icon circle */}
        <div className="w-[115px] h-[115px] bg-[#fcf1dd] border border-[#fbeedc] rounded-full flex items-center justify-center mb-5">
          <svg width="60" height="65" viewBox="0 0 60 65" fill="none">
            <circle cx="45" cy="12.5" r="6.25" stroke="#2B3F6C" strokeWidth="3.75"/>
            <circle cx="15" cy="32.5" r="6.25" stroke="#2B3F6C" strokeWidth="3.75"/>
            <circle cx="45" cy="52.5" r="6.25" stroke="#2B3F6C" strokeWidth="3.75"/>
            <line x1="20" y1="30" x2="40" y2="15" stroke="#2B3F6C" strokeWidth="3.75" strokeLinecap="round"/>
            <line x1="20" y1="35" x2="40" y2="50" stroke="#2B3F6C" strokeWidth="3.75" strokeLinecap="round"/>
          </svg>
        </div>

        {/* Info card */}
        <div className="w-full max-w-[335px] bg-[#fcf1dd] border border-[#fbeedc] rounded-[31px] px-6 py-5 mb-4">
          <h2 className="font-['Ninetea:Bold',sans-serif] text-[#130b3d] text-[15.63px] text-center mb-4">
            Por qué conectar un wearable?
          </h2>

          {/* Feature 1 */}
          <div className="flex items-start gap-4 mb-4">
            <div className="w-6 h-6 flex-shrink-0 flex items-center justify-center">
              <Heart className="w-5 h-5 text-[#2B3F6C]" strokeWidth={1.5} />
            </div>
            <div>
              <h3 className="font-['Ninetea:Bold',sans-serif] text-[#f58020] text-[15.63px] mb-1">
                Frecuencia Cardíaca
              </h3>
              <p className="font-['Inter:Medium',sans-serif] text-[#130b3d] text-[13.63px]">
                Monitorea cambios relacionados con tu ciclo
              </p>
            </div>
          </div>

          {/* Feature 2 */}
          <div className="flex items-start gap-4 mb-4">
            <div className="w-6 h-6 flex-shrink-0 flex items-center justify-center">
              <Activity className="w-5 h-5 text-[#2B3F6C]" strokeWidth={1.5} />
            </div>
            <div>
              <h3 className="font-['Ninetea:Bold',sans-serif] text-[#f58020] text-[15.63px] mb-1">
                Temperatura Basal
              </h3>
              <p className="font-['Inter:Medium',sans-serif] text-[#130b3d] text-[13.63px]">
                Predicciones más precisas de oculación
              </p>
            </div>
          </div>

          {/* Feature 3 */}
          <div className="flex items-start gap-4">
            <div className="w-6 h-6 flex-shrink-0 flex items-center justify-center">
              <Zap className="w-5 h-5 text-[#2B3F6C]" strokeWidth={1.5} />
            </div>
            <div>
              <h3 className="font-['Ninetea:Bold',sans-serif] text-[#f58020] text-[15.63px] mb-1">
                Actividad y Sueño
              </h3>
              <p className="font-['Inter:Medium',sans-serif] text-[#130b3d] text-[13.63px]">
                Comprende cómo afecta tu ciclo a tu energía
              </p>
            </div>
          </div>
        </div>

        {/* Compatibility info */}
        <div className="w-full max-w-[345px] bg-gradient-to-b from-[#f7be7e] to-[#fff2e3] border border-[#fbeedc] rounded-[31px] px-6 py-4 mb-4">
          <p className="font-['Inter:Regular',sans-serif] text-[#130b3d] text-[12.63px] text-center">
            Compatible con Apple Watch, Fitbit, Garmin, Oura Ring, y más
          </p>
        </div>

        {/* Connect button */}
        <button
          onClick={onContinue}
          className="w-full max-w-[345px] h-[63px] bg-[rgba(245,128,32,0.8)] backdrop-blur-xl border border-white shadow-lg rounded-[31px] flex items-center justify-center gap-2 hover:bg-[rgba(230,116,25,0.8)] transition-colors mb-6"
        >
          <span className="font-['Ninetea:Semi_Bold',sans-serif] text-[#fbeedc] text-[17px]">
            Conectar Dispositivo
          </span>
          <svg width="6" height="12" viewBox="0 0 6 12" fill="none">
            <path d="M1 1L5 6L1 11" stroke="#FBEEDC" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
        </button>
      </div>
    </div>
  );
}
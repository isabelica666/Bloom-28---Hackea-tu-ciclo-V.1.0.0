import { ArrowLeft } from 'lucide-react';

interface TermsAndConditionsProps {
  onBack: () => void;
}

export function TermsAndConditions({ onBack }: TermsAndConditionsProps) {
  return (
    <div className="min-h-screen bg-gradient-to-b from-[#ffe0c6] to-[#f5ebc3] pb-10">
      {/* Header */}
      <div className="sticky top-0 z-10 bg-gradient-to-b from-[#ffe0c6] to-transparent backdrop-blur-sm pb-4">
        <div className="flex items-center justify-between px-6 pt-6 pb-2">
          <button
            onClick={onBack}
            className="p-2 hover:bg-[rgba(252,239,221,0.5)] rounded-full transition-colors"
          >
            <ArrowLeft className="w-6 h-6 text-[#130b3d]" />
          </button>
          <h1 className="font-['Ninetea:Bold',sans-serif] text-[20px] text-[#130b3d] text-center flex-1 mr-10">
            Términos y Condiciones
          </h1>
        </div>
      </div>

      {/* Content */}
      <div className="px-6 space-y-6">
        {/* Important Notice */}
        <div className="bg-[rgba(245,128,32,0.15)] backdrop-blur-xl border-2 border-[#f58020] shadow-lg rounded-3xl p-6">
          <h2 className="font-['Ninetea:Bold',sans-serif] text-[#f58020] text-[18px] mb-3">
            ⚠️ Aviso Importante
          </h2>
          <div className="space-y-3">
            <p className="font-['Inter:Bold',sans-serif] text-[15px] text-[#130b3d] leading-relaxed">
              Bloom 28 es una herramienta informativa y educativa diseñada para el seguimiento del ciclo menstrual y bienestar femenino.
            </p>
            <p className="font-['Inter:Bold',sans-serif] text-[15px] text-[#130b3d] leading-relaxed">
              La aplicación NO diagnostica, trata, cura ni previene ninguna enfermedad.
            </p>
            <p className="font-['Inter:Bold',sans-serif] text-[15px] text-[#130b3d] leading-relaxed">
              La información proporcionada por Bloom 28 NO sustituye el consejo médico profesional, el diagnóstico o el tratamiento.
            </p>
            <p className="font-['Inter:Regular',sans-serif] text-[14px] text-[#5250a2] leading-relaxed mt-4">
              Siempre consulte con su médico o profesional de la salud antes de tomar decisiones relacionadas con su salud.
            </p>
          </div>
        </div>

        {/* Last Update */}
        <div className="text-center">
          <p className="font-['Inter:Regular',sans-serif] text-[12px] text-[#5250a2]">
            Última actualización: 17 de enero de 2026
          </p>
        </div>

        {/* 1. Aceptación de los Términos */}
        <div className="bg-[rgba(252,239,221,0.5)] backdrop-blur-xl border border-white shadow-lg rounded-3xl p-6">
          <h3 className="font-['Ninetea:Bold',sans-serif] text-[#130b3d] text-[17px] mb-3">
            1. Aceptación de los Términos
          </h3>
          <p className="font-['Inter:Regular',sans-serif] text-[15px] text-[#130b3d] leading-relaxed">
            Al acceder y utilizar Bloom 28, usted acepta estar legalmente vinculada por estos Términos y Condiciones. Si no está de acuerdo con alguna parte de estos términos, no debe utilizar nuestra aplicación.
          </p>
        </div>

        {/* 2. Descripción del Servicio */}
        <div className="bg-[rgba(252,239,221,0.5)] backdrop-blur-xl border border-white shadow-lg rounded-3xl p-6">
          <h3 className="font-['Ninetea:Bold',sans-serif] text-[#130b3d] text-[17px] mb-3">
            2. Descripción del Servicio
          </h3>
          <p className="font-['Inter:Regular',sans-serif] text-[15px] text-[#130b3d] leading-relaxed mb-3">
            Bloom 28 es una aplicación móvil que proporciona:
          </p>
          <ul className="space-y-2 ml-4">
            <li className="font-['Inter:Regular',sans-serif] text-[15px] text-[#130b3d] leading-relaxed">
              • Seguimiento del ciclo menstrual
            </li>
            <li className="font-['Inter:Regular',sans-serif] text-[15px] text-[#130b3d] leading-relaxed">
              • Registro de síntomas y estados de ánimo
            </li>
            <li className="font-['Inter:Regular',sans-serif] text-[15px] text-[#130b3d] leading-relaxed">
              • Conexión con dispositivos wearables para datos biométricos
            </li>
            <li className="font-['Inter:Regular',sans-serif] text-[15px] text-[#130b3d] leading-relaxed">
              • Recomendaciones generales de nutrición y ejercicio
            </li>
            <li className="font-['Inter:Regular',sans-serif] text-[15px] text-[#130b3d] leading-relaxed">
              • Información educativa sobre salud femenina
            </li>
          </ul>
        </div>

        {/* 3. Limitaciones de Responsabilidad Médica */}
        <div className="bg-[rgba(234,76,137,0.15)] backdrop-blur-xl border-2 border-[#ea4c89] shadow-lg rounded-3xl p-6">
          <h3 className="font-['Ninetea:Bold',sans-serif] text-[#ea4c89] text-[17px] mb-3">
            3. Limitaciones de Responsabilidad Médica
          </h3>
          <div className="space-y-3">
            <p className="font-['Inter:Bold',sans-serif] text-[15px] text-[#130b3d] leading-relaxed">
              3.1. No es un Dispositivo Médico
            </p>
            <p className="font-['Inter:Regular',sans-serif] text-[14px] text-[#130b3d] leading-relaxed">
              Bloom 28 NO es un dispositivo médico y no ha sido evaluada ni aprobada por ninguna autoridad regulatoria de salud. No debe utilizarse para diagnóstico, prevención o tratamiento de ninguna condición médica.
            </p>
            
            <p className="font-['Inter:Bold',sans-serif] text-[15px] text-[#130b3d] leading-relaxed mt-4">
              3.2. No Sustituye Atención Médica
            </p>
            <p className="font-['Inter:Regular',sans-serif] text-[14px] text-[#130b3d] leading-relaxed">
              La información y recomendaciones proporcionadas son únicamente con fines educativos e informativos. Siempre consulte a un profesional de la salud calificado antes de:
            </p>
            <ul className="space-y-2 ml-4 mt-2">
              <li className="font-['Inter:Regular',sans-serif] text-[14px] text-[#130b3d] leading-relaxed">
                • Realizar cambios en su dieta o rutina de ejercicios
              </li>
              <li className="font-['Inter:Regular',sans-serif] text-[14px] text-[#130b3d] leading-relaxed">
                • Iniciar o suspender cualquier medicamento
              </li>
              <li className="font-['Inter:Regular',sans-serif] text-[14px] text-[#130b3d] leading-relaxed">
                • Ignorar o retrasar la búsqueda de asesoramiento médico profesional
              </li>
            </ul>

            <p className="font-['Inter:Bold',sans-serif] text-[15px] text-[#130b3d] leading-relaxed mt-4">
              3.3. No para Anticoncepción
            </p>
            <p className="font-['Inter:Regular',sans-serif] text-[14px] text-[#130b3d] leading-relaxed">
              Bloom 28 NO debe utilizarse como método anticonceptivo. Las predicciones de fertilidad son estimaciones basadas en datos históricos y no son 100% precisas.
            </p>

            <p className="font-['Inter:Bold',sans-serif] text-[15px] text-[#130b3d] leading-relaxed mt-4">
              3.4. Situaciones de Emergencia
            </p>
            <p className="font-['Inter:Regular',sans-serif] text-[14px] text-[#130b3d] leading-relaxed">
              En caso de emergencia médica, llame inmediatamente a servicios de emergencia locales. No confíe en Bloom 28 para situaciones médicas urgentes.
            </p>
          </div>
        </div>

        {/* 4. Uso de Datos Biométricos */}
        <div className="bg-[rgba(252,239,221,0.5)] backdrop-blur-xl border border-white shadow-lg rounded-3xl p-6">
          <h3 className="font-['Ninetea:Bold',sans-serif] text-[#130b3d] text-[17px] mb-3">
            4. Uso de Datos Biométricos
          </h3>
          <p className="font-['Inter:Regular',sans-serif] text-[15px] text-[#130b3d] leading-relaxed mb-3">
            Al conectar dispositivos wearables, usted acepta que:
          </p>
          <ul className="space-y-2 ml-4">
            <li className="font-['Inter:Regular',sans-serif] text-[15px] text-[#130b3d] leading-relaxed">
              • Los datos biométricos se utilizan únicamente para proporcionar información sobre su ciclo menstrual
            </li>
            <li className="font-['Inter:Regular',sans-serif] text-[15px] text-[#130b3d] leading-relaxed">
              • Las mediciones pueden no ser 100% precisas
            </li>
            <li className="font-['Inter:Regular',sans-serif] text-[15px] text-[#130b3d] leading-relaxed">
              • Los datos se almacenan de forma segura y encriptada
            </li>
            <li className="font-['Inter:Regular',sans-serif] text-[15px] text-[#130b3d] leading-relaxed">
              • Usted puede revocar el acceso a estos datos en cualquier momento
            </li>
          </ul>
        </div>

        {/* 5. Privacidad y Protección de Datos */}
        <div className="bg-[rgba(252,239,221,0.5)] backdrop-blur-xl border border-white shadow-lg rounded-3xl p-6">
          <h3 className="font-['Ninetea:Bold',sans-serif] text-[#130b3d] text-[17px] mb-3">
            5. Privacidad y Protección de Datos
          </h3>
          <p className="font-['Inter:Regular',sans-serif] text-[15px] text-[#130b3d] leading-relaxed mb-3">
            Su privacidad es importante para nosotros:
          </p>
          <ul className="space-y-2 ml-4">
            <li className="font-['Inter:Regular',sans-serif] text-[15px] text-[#130b3d] leading-relaxed">
              • No vendemos ni compartimos sus datos personales con terceros sin su consentimiento
            </li>
            <li className="font-['Inter:Regular',sans-serif] text-[15px] text-[#130b3d] leading-relaxed">
              • Todos los datos se encriptan durante la transmisión y el almacenamiento
            </li>
            <li className="font-['Inter:Regular',sans-serif] text-[15px] text-[#130b3d] leading-relaxed">
              • Usted puede exportar o eliminar sus datos en cualquier momento
            </li>
            <li className="font-['Inter:Regular',sans-serif] text-[15px] text-[#130b3d] leading-relaxed">
              • Cumplimos con las leyes de protección de datos aplicables
            </li>
          </ul>
        </div>

        {/* 6. Precisión de la Información */}
        <div className="bg-[rgba(252,239,221,0.5)] backdrop-blur-xl border border-white shadow-lg rounded-3xl p-6">
          <h3 className="font-['Ninetea:Bold',sans-serif] text-[#130b3d] text-[17px] mb-3">
            6. Precisión de la Información
          </h3>
          <p className="font-['Inter:Regular',sans-serif] text-[15px] text-[#130b3d] leading-relaxed">
            Aunque nos esforzamos por proporcionar información precisa y actualizada, Bloom 28 no garantiza la exactitud, integridad o actualidad de la información proporcionada. Las predicciones del ciclo menstrual son estimaciones basadas en datos históricos y pueden variar.
          </p>
        </div>

        {/* 7. Responsabilidad del Usuario */}
        <div className="bg-[rgba(252,239,221,0.5)] backdrop-blur-xl border border-white shadow-lg rounded-3xl p-6">
          <h3 className="font-['Ninetea:Bold',sans-serif] text-[#130b3d] text-[17px] mb-3">
            7. Responsabilidad del Usuario
          </h3>
          <p className="font-['Inter:Regular',sans-serif] text-[15px] text-[#130b3d] leading-relaxed mb-3">
            Al utilizar Bloom 28, usted acepta:
          </p>
          <ul className="space-y-2 ml-4">
            <li className="font-['Inter:Regular',sans-serif] text-[15px] text-[#130b3d] leading-relaxed">
              • Proporcionar información precisa y actualizada
            </li>
            <li className="font-['Inter:Regular',sans-serif] text-[15px] text-[#130b3d] leading-relaxed">
              • Mantener la confidencialidad de su cuenta
            </li>
            <li className="font-['Inter:Regular',sans-serif] text-[15px] text-[#130b3d] leading-relaxed">
              • No utilizar la aplicación para fines ilegales
            </li>
            <li className="font-['Inter:Regular',sans-serif] text-[15px] text-[#130b3d] leading-relaxed">
              • Ser mayor de 18 años o tener el consentimiento de un tutor legal
            </li>
          </ul>
        </div>

        {/* 8. Limitación de Responsabilidad */}
        <div className="bg-[rgba(252,239,221,0.5)] backdrop-blur-xl border border-white shadow-lg rounded-3xl p-6">
          <h3 className="font-['Ninetea:Bold',sans-serif] text-[#130b3d] text-[17px] mb-3">
            8. Limitación de Responsabilidad
          </h3>
          <p className="font-['Inter:Regular',sans-serif] text-[15px] text-[#130b3d] leading-relaxed">
            En la medida permitida por la ley, Bloom 28 y sus desarrolladores no serán responsables de ningún daño directo, indirecto, incidental, especial, consecuente o punitivo que resulte del uso o la imposibilidad de usar la aplicación, incluyendo pero no limitado a decisiones de salud basadas en la información proporcionada.
          </p>
        </div>

        {/* 9. Cambios en los Términos */}
        <div className="bg-[rgba(252,239,221,0.5)] backdrop-blur-xl border border-white shadow-lg rounded-3xl p-6">
          <h3 className="font-['Ninetea:Bold',sans-serif] text-[#130b3d] text-[17px] mb-3">
            9. Modificaciones a los Términos
          </h3>
          <p className="font-['Inter:Regular',sans-serif] text-[15px] text-[#130b3d] leading-relaxed">
            Nos reservamos el derecho de modificar estos Términos y Condiciones en cualquier momento. Los cambios entrarán en vigor inmediatamente después de su publicación en la aplicación. Su uso continuado de Bloom 28 después de dichos cambios constituye su aceptación de los nuevos términos.
          </p>
        </div>

        {/* 10. Cancelación de Cuenta */}
        <div className="bg-[rgba(252,239,221,0.5)] backdrop-blur-xl border border-white shadow-lg rounded-3xl p-6">
          <h3 className="font-['Ninetea:Bold',sans-serif] text-[#130b3d] text-[17px] mb-3">
            10. Cancelación de Cuenta
          </h3>
          <p className="font-['Inter:Regular',sans-serif] text-[15px] text-[#130b3d] leading-relaxed">
            Usted puede cancelar su cuenta en cualquier momento desde la configuración de la aplicación. Nos reservamos el derecho de suspender o cancelar cuentas que violen estos términos.
          </p>
        </div>

        {/* 11. Ley Aplicable */}
        <div className="bg-[rgba(252,239,221,0.5)] backdrop-blur-xl border border-white shadow-lg rounded-3xl p-6">
          <h3 className="font-['Ninetea:Bold',sans-serif] text-[#130b3d] text-[17px] mb-3">
            11. Ley Aplicable
          </h3>
          <p className="font-['Inter:Regular',sans-serif] text-[15px] text-[#130b3d] leading-relaxed">
            Estos Términos y Condiciones se rigen e interpretan de acuerdo con las leyes aplicables de su jurisdicción, sin tener en cuenta sus disposiciones sobre conflictos de leyes.
          </p>
        </div>

        {/* 12. Contacto */}
        <div className="bg-[rgba(34,113,184,0.15)] backdrop-blur-xl border border-[#2271b8] shadow-lg rounded-3xl p-6">
          <h3 className="font-['Ninetea:Bold',sans-serif] text-[#2271b8] text-[17px] mb-3">
            12. Contacto
          </h3>
          <p className="font-['Inter:Regular',sans-serif] text-[15px] text-[#130b3d] leading-relaxed mb-3">
            Si tiene preguntas sobre estos Términos y Condiciones, puede contactarnos en:
          </p>
          <p className="font-['Inter:Bold',sans-serif] text-[15px] text-[#2271b8]">
            support@bloom28.com
          </p>
        </div>

        {/* Final Notice */}
        <div className="bg-[rgba(245,128,32,0.1)] backdrop-blur-xl border border-[#f58020] shadow-lg rounded-3xl p-6">
          <p className="font-['Inter:Bold',sans-serif] text-[14px] text-[#130b3d] leading-relaxed text-center">
            Al utilizar Bloom 28, usted reconoce que ha leído, comprendido y aceptado estos Términos y Condiciones en su totalidad.
          </p>
        </div>
      </div>
    </div>
  );
}

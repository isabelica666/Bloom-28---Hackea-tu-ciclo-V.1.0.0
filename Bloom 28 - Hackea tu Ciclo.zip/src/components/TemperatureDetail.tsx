import { motion } from 'motion/react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { ArrowLeft, Thermometer, TrendingUp, TrendingDown, Sparkles } from 'lucide-react';
import { calculateCycleInfo, type CycleData } from '../utils/cycleCalculations';
import { generateLast7DaysData, calculateAverages } from '../utils/biometricData';

interface TemperatureDetailProps {
  cycleData: CycleData;
  onBack: () => void;
}

export function TemperatureDetail({ cycleData, onBack }: TemperatureDetailProps) {
  const cycleInfo = calculateCycleInfo(cycleData);
  const currentPhase = cycleInfo.currentPhase;

  // Generar datos de los últimos 7 días basados en la fase actual
  const last7DaysData = generateLast7DaysData(currentPhase);
  const tempData = last7DaysData.map(d => ({ day: d.day, temp: d.temp }));
  const { avgTemp } = calculateAverages(last7DaysData);

  // Calcular tendencias basadas en la fase
  const tempTrend = currentPhase === 'ovulation' || currentPhase === 'luteal' ? '+0.4°C' : currentPhase === 'follicular' ? '+0.2°C' : '-0.1°C';
  const tempTrendUp = currentPhase === 'ovulation' || currentPhase === 'luteal' || currentPhase === 'follicular';

  // Insights específicos de temperatura según la fase
  const getTemperatureInsights = () => {
    const insights = {
      menstrual: {
        title: "Temperatura Basal Baja - Es Normal",
        message: "Durante la menstruación, tu temperatura basal cae naturalmente a su punto más bajo del ciclo (36.2°C). Esta disminución ocurre porque los niveles de progesterona son mínimos. Esta temperatura baja se mantendrá hasta que comience la fase folicular.",
        tips: [
          "La temperatura basal baja (36.0-36.3°C) indica que estás en fase menstrual",
          "Esta caída de temperatura confirma que no hubo embarazo en el ciclo anterior",
          "Mantén mediciones consistentes para detectar patrones de ovulación futuros",
          "Si notas temperaturas inusualmente altas durante el período, consulta a tu médico"
        ],
        interpretation: "Una temperatura basal baja durante la menstruación es señal de un ciclo hormonal saludable. La progesterona, que mantiene la temperatura elevada después de la ovulación, ha disminuido permitiendo que comience un nuevo ciclo."
      },
      folicular: {
        title: "Temperatura en Ascenso Gradual",
        message: "Tu temperatura basal está aumentando lentamente (36.3°C promedio) conforme tus ovarios preparan un óvulo para la ovulación. El estrógeno está en aumento pero la progesterona sigue baja, por eso la temperatura permanece relativamente estable y ligeramente baja.",
        tips: [
          "Temperatura estable de 36.2-36.4°C indica fase folicular saludable",
          "Un aumento sostenido de 0.3°C o más señalará que la ovulación está cerca",
          "Este es el mejor momento para identificar tu patrón basal pre-ovulatorio",
          "La variabilidad diaria de ±0.1°C es completamente normal"
        ],
        interpretation: "La fase folicular se caracteriza por una temperatura basal baja y estable. Este patrón es ideal porque facilita identificar el salto térmico que ocurrirá en la ovulación, un indicador clave de fertilidad."
      },
      ovulation: {
        title: "Pico Térmico - Ovulación Confirmada",
        message: "Tu temperatura ha aumentado significativamente a 36.6°C, una señal clara de que has ovulado. Este aumento de aproximadamente 0.3-0.5°C ocurre porque el cuerpo lúteo (el folículo que liberó el óvulo) está produciendo progesterona, una hormona que eleva la temperatura corporal.",
        tips: [
          "El salto térmico de 0.3°C o más confirma que la ovulación ocurrió",
          "Esta temperatura elevada se mantendrá durante toda la fase lútea (10-16 días)",
          "La ovulación generalmente ocurre 1-2 días ANTES del aumento de temperatura",
          "Tres días consecutivos de temperatura alta confirman la ovulación"
        ],
        interpretation: "El aumento brusco en tu temperatura basal es el indicador más confiable de que has ovulado. La progesterona ahora domina tu ciclo hormonal, preparando el útero para un posible embarazo y manteniendo tu temperatura elevada."
      },
      luteal: {
        title: "Temperatura Alta Sostenida - Fase Lútea",
        message: "Tu temperatura se mantiene elevada (36.7°C) gracias a la progesterona producida por el cuerpo lúteo. Esta temperatura alta permanecerá hasta justo antes de tu próximo período (si no hay embarazo) o continuará elevada si hay un embarazo.",
        tips: [
          "Temperatura sostenida de 36.6-37.0°C es normal en la fase lútea",
          "Si la temperatura se mantiene alta más de 18 días, podría indicar embarazo",
          "Una caída repentina señala que tu período comenzará en 1-2 días",
          "La temperatura ligeramente irregular en esta fase es común debido a la progesterona"
        ],
        interpretation: "La temperatura basal elevada durante la fase lútea es causada por la progesterona. Si no ocurre un embarazo, la temperatura caerá 1-2 días antes de tu período cuando los niveles de progesterona disminuyan. Si hay embarazo, la temperatura se mantendrá alta."
      }
    };

    return insights[currentPhase as keyof typeof insights] || insights.folicular;
  };

  const temperatureInsight = getTemperatureInsights();

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#ffe0c6] to-[#f5ebc3] pb-6">
      {/* Header */}
      <div className="sticky top-0 z-10 bg-gradient-to-b from-[#ffe0c6] to-transparent backdrop-blur-sm pb-4">
        <div className="flex items-center justify-between px-6 pt-6 pb-2">
          <button
            onClick={onBack}
            className="p-2 hover:bg-[rgba(252,239,221,0.5)] rounded-full transition-colors"
          >
            <ArrowLeft className="w-6 h-6 text-[#130b3d]" />
          </button>
          <h1 className="font-['Ninetea:Bold',sans-serif] text-[24px] text-[#130b3d]">Temperatura Basal</h1>
          <div className="w-10" /> {/* Spacer for centering */}
        </div>
      </div>

      <div className="px-6 space-y-6">
        {/* Current Value Card */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="bg-[rgba(252,239,221,0.5)] backdrop-blur-xl border border-white shadow-lg rounded-3xl p-6"
        >
          <div className="flex items-center justify-center mb-4">
            <Thermometer className="w-12 h-12 text-[#f58020]" strokeWidth={1.5} />
          </div>
          <div className="text-center">
            <p className="font-['Ninetea:Bold',sans-serif] text-[48px] text-[#130b3d] leading-none mb-2">
              {avgTemp}°C
            </p>
            <p className="font-['Inter:Regular',sans-serif] text-sm text-[#130b3d] mb-3">
              Promedio últimos 7 días
            </p>
            <div className="inline-flex items-center gap-2 bg-[rgba(245,128,32,0.15)] px-4 py-2 rounded-full">
              {tempTrendUp ? <TrendingUp className="w-4 h-4 text-[#f58020]" /> : <TrendingDown className="w-4 h-4 text-[#f58020]" />}
              <span className="font-['Inter:Bold',sans-serif] text-sm text-[#f58020]">{tempTrend}</span>
            </div>
          </div>
        </motion.div>

        {/* Temperature Chart */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="bg-[rgba(252,239,221,0.5)] backdrop-blur-xl border border-white shadow-lg rounded-3xl p-6"
        >
          <h3 className="font-['Ninetea:Bold',sans-serif] text-[#130b3d] mb-4 text-center">
            Evolución de los últimos 7 días
          </h3>
          <ResponsiveContainer width="100%" height={280}>
            <AreaChart data={tempData} margin={{ top: 10, right: 10, left: -15, bottom: 10 }}>
              <defs>
                <linearGradient id="tempGradientDetail" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#f58020" stopOpacity={0.5}/>
                  <stop offset="95%" stopColor="#f58020" stopOpacity={0.05}/>
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#e5d4c1" strokeOpacity={0.3} />
              <XAxis 
                dataKey="day" 
                stroke="#130b3d" 
                strokeOpacity={0.5}
                style={{ fontSize: '12px', fontFamily: 'Inter' }}
                axisLine={false}
                tickLine={false}
              />
              <YAxis 
                domain={[36, 37]} 
                stroke="#130b3d" 
                strokeOpacity={0.5}
                style={{ fontSize: '12px', fontFamily: 'Inter' }}
                axisLine={false}
                tickLine={false}
              />
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: 'rgba(252, 239, 221, 0.95)', 
                  border: 'none', 
                  borderRadius: '12px', 
                  fontFamily: 'Inter', 
                  color: '#130b3d',
                  boxShadow: '0 4px 12px rgba(0,0,0,0.1)'
                }} 
              />
              <Area 
                type="monotone" 
                dataKey="temp" 
                stroke="#f58020" 
                strokeWidth={4}
                fill="url(#tempGradientDetail)"
                dot={{ fill: '#f58020', r: 7, strokeWidth: 3, stroke: '#fff' }}
                activeDot={{ r: 9, strokeWidth: 3, stroke: '#fff' }}
              />
            </AreaChart>
          </ResponsiveContainer>
        </motion.div>

        {/* AI Insights */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="bg-[rgba(252,239,221,0.5)] backdrop-blur-xl border border-white shadow-lg rounded-3xl p-6"
        >
          <div className="flex items-center justify-center gap-2 mb-4">
            <Sparkles className="w-6 h-6 text-[#f58020]" />
            <h3 className="font-['Ninetea:Bold',sans-serif] text-[#130b3d] text-[20px]">Insight de IA</h3>
          </div>
          
          <h4 className="font-['Inter:Bold',sans-serif] text-[#130b3d] text-center mb-3 text-lg">
            {temperatureInsight.title}
          </h4>
          
          <p className="font-['Inter:Regular',sans-serif] text-sm text-[#130b3d] leading-relaxed mb-4">
            {temperatureInsight.message}
          </p>

          <div className="bg-[rgba(245,235,195,0.5)] rounded-2xl p-4 mb-4">
            <h5 className="font-['Inter:Bold',sans-serif] text-sm text-[#130b3d] mb-2">
              🔍 Interpretación:
            </h5>
            <p className="font-['Inter:Regular',sans-serif] text-sm text-[#130b3d] leading-relaxed">
              {temperatureInsight.interpretation}
            </p>
          </div>

          <h5 className="font-['Inter:Bold',sans-serif] text-sm text-[#130b3d] mb-3">
            💡 Recomendaciones:
          </h5>
          <div className="space-y-3">
            {temperatureInsight.tips.map((tip, index) => (
              <div key={index} className="flex items-start gap-3">
                <div className="w-2 h-2 rounded-full bg-[#f58020] mt-1.5 flex-shrink-0"></div>
                <p className="font-['Inter:Regular',sans-serif] text-sm text-[#130b3d] flex-1 leading-relaxed">
                  {tip}
                </p>
              </div>
            ))}
          </div>
        </motion.div>
      </div>
    </div>
  );
}
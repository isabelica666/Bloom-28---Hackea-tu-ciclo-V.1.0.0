import { motion } from 'motion/react';
import { Sparkles, Apple, Dumbbell, Lightbulb, ChevronRight, Leaf, Fish, Candy, Citrus, Drumstick, Wheat, Salad, Milk, Grape, Cherry, Pizza, Waves, Carrot, Cookie } from 'lucide-react';
import { calculateCycleInfo, getPhaseName, type CycleData } from '../utils/cycleCalculations';

interface RecommendationsProps {
  cycleData: CycleData;
  onNutritionClick?: (item: any, phase: string) => void;
  onExerciseClick?: (exerciseType: string) => void;
}

export function Recommendations({ cycleData, onNutritionClick, onExerciseClick }: RecommendationsProps) {
  const cycleInfo = calculateCycleInfo(cycleData);
  const currentPhase = cycleInfo.currentPhase;
  const phaseNameEs = getPhaseName(currentPhase);

  const nutritionRecommendations = {
    menstrual: [
      { food: 'Alimentos ricos en hierro', reason: 'Espinacas, lentejas, carne roja', icon: Leaf, color: 'from-[#2271b8] to-[#5250a2]' },
      { food: 'Omega-3', reason: 'Salmón, nueces, semillas de chía', icon: Fish, color: 'from-[#5250a2] to-[#8b4fb8]' },
      { food: 'Magnesio', reason: 'Chocolate oscuro, plátanos', icon: Candy, color: 'from-[#f58020] to-[#ef932d]' },
      { food: 'Vitamina C', reason: 'Naranjas, fresas, kiwi', icon: Citrus, color: 'from-[#ef932d] to-[#e8a55c]' }
    ],
    follicular: [
      { food: 'Proteínas magras', reason: 'Pollo, pavo, tofu', icon: Drumstick, color: 'from-[#2271b8] to-[#5250a2]' },
      { food: 'Carbohidratos complejos', reason: 'Quinoa, avena, arroz integral', icon: Wheat, color: 'from-[#5250a2] to-[#8b4fb8]' },
      { food: 'Verduras crucíferas', reason: 'Brócoli, coliflor, col', icon: Salad, color: 'from-[#f58020] to-[#ef932d]' },
      { food: 'Probióticos', reason: 'Yogur, kéfir, kombucha', icon: Milk, color: 'from-[#ef932d] to-[#e8a55c]' }
    ],
    ovulation: [
      { food: 'Antioxidantes', reason: 'Bayas, uvas, granada', icon: Grape, color: 'from-[#2271b8] to-[#5250a2]' },
      { food: 'Fibra', reason: 'Semillas de lino, chía', icon: Cherry, color: 'from-[#5250a2] to-[#8b4fb8]' },
      { food: 'Calcio', reason: 'Lácteos, almendras', icon: Pizza, color: 'from-[#f58020] to-[#ef932d]' },
      { food: 'Zinc', reason: 'Ostras, garbanzos, semillas', icon: Waves, color: 'from-[#ef932d] to-[#e8a55c]' }
    ],
    luteal: [
      { food: 'Vitamina B6', reason: 'Garbanzos, atún, plátanos', icon: Carrot, color: 'from-[#2271b8] to-[#5250a2]' },
      { food: 'Calcio y Magnesio', reason: 'Reduce hinchazón y calambres', icon: Milk, color: 'from-[#5250a2] to-[#8b4fb8]' },
      { food: 'Carbohidratos saludables', reason: 'Batatas, calabaza', icon: Cookie, color: 'from-[#f58020] to-[#ef932d]' },
      { food: 'Evitar sal excesiva', reason: 'Reduce retención de líquidos', icon: Apple, color: 'from-[#ef932d] to-[#e8a55c]' }
    ]
  };

  const exerciseRecommendations = {
    menstrual: [
      { type: 'Yoga suave', intensity: 'Baja', duration: '20-30 min', benefit: 'Reduce calambres y estrés' },
      { type: 'Caminata ligera', intensity: 'Baja', duration: '30 min', benefit: 'Mejora circulación' },
      { type: 'Estiramientos', intensity: 'Baja', duration: '15-20 min', benefit: 'Alivia tensión muscular' }
    ],
    follicular: [
      { type: 'Entrenamiento HIIT', intensity: 'Alta', duration: '30-40 min', benefit: 'Máxima quema de calorías' },
      { type: 'Levantamiento de pesas', intensity: 'Alta', duration: '45 min', benefit: 'Construcción muscular óptima' },
      { type: 'Running', intensity: 'Media-Alta', duration: '30-45 min', benefit: 'Resistencia cardiovascular' }
    ],
    ovulation: [
      { type: 'CrossFit', intensity: 'Muy Alta', duration: '45 min', benefit: 'Aprovecha pico de energía' },
      { type: 'Spinning', intensity: 'Alta', duration: '45 min', benefit: 'Resistencia y fuerza' },
      { type: 'Pilates intenso', intensity: 'Media-Alta', duration: '60 min', benefit: 'Fuerza core' }
    ],
    luteal: [
      { type: 'Yoga restaurativo', intensity: 'Baja-Media', duration: '45 min', benefit: 'Reduce estrés y ansiedad' },
      { type: 'Natación', intensity: 'Media', duration: '30-40 min', benefit: 'Bajo impacto, reduce hinchazón' },
      { type: 'Caminata moderada', intensity: 'Media', duration: '40 min', benefit: 'Mantiene actividad sin fatiga' }
    ]
  };

  const currentNutrition = nutritionRecommendations[currentPhase as keyof typeof nutritionRecommendations] || nutritionRecommendations.follicular;
  const currentExercise = exerciseRecommendations[currentPhase as keyof typeof exerciseRecommendations] || exerciseRecommendations.follicular;

  // Insights personalizados según la fase
  const phaseInsights = {
    menstrual: [
      'Tu temperatura basal está en su punto más bajo - es normal durante la menstruación',
      'Descansa lo suficiente y mantén ejercicio de baja intensidad para reducir calambres',
      'Hidrátate bien y consume alimentos ricos en hierro para compensar la pérdida'
    ],
    follicular: [
      'Tu energía está aumentando - momento ideal para desafíos físicos',
      'Tu metabolismo está acelerado, aprovecha para entrenamientos de alta intensidad',
      'Excelente momento para probar nuevas actividades y establecer récords personales'
    ],
    ovulation: [
      'Temperatura basal indica proximidad a ovulación - momento ideal para ejercicio intenso',
      'Tu nivel de energía está en su pico máximo, aprovecha para entrenamientos exigentes',
      'Tu resistencia y fuerza están optimizadas en esta fase del ciclo'
    ],
    luteal: [
      'Tu cuerpo se está preparando para el próximo ciclo - prioriza el descanso',
      'Considera ejercicios de intensidad moderada para mantener energía sin fatiga',
      'Reduce el consumo de sal para evitar retención de líquidos e hinchazón'
    ]
  };

  const currentInsights = phaseInsights[currentPhase as keyof typeof phaseInsights] || phaseInsights.follicular;

  return (
    <div className="p-6 space-y-6 pb-24 bg-[#fbeedc] min-h-screen">
      {/* Medical Disclaimer */}
      <motion.div
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-[rgba(245,128,32,0.15)] backdrop-blur-xl border-2 border-[#f58020] shadow-lg rounded-2xl p-4"
      >
        <p className="font-['Inter:Bold',sans-serif] text-[13px] text-[#130b3d] text-center leading-[1.4]">
          ⚠️ La información proporcionada por Bloom 28 no sustituye el consejo médico profesional, el diagnóstico o el tratamiento.
        </p>
      </motion.div>

      {/* AI Header */}
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="bg-gradient-to-r from-[#2271b8] to-[#5250a2] backdrop-blur-xl border border-white shadow-lg rounded-3xl p-6 text-white"
      >
        <div className="flex items-center gap-3 mb-2">
          <Sparkles className="w-6 h-6" />
          <h2 className="font-['Ninetea:Bold',sans-serif]">Recomendaciones IA</h2>
        </div>
        <p className="font-['Inter:Regular',sans-serif] text-[#fbeedc] text-sm">
          Basado en tu fase {phaseNameEs} y tus datos biométricos
        </p>
      </motion.div>

      {/* Nutrition Section */}
      <div>
        <div className="flex items-center gap-2 mb-4">
          <Apple className="w-5 h-5 text-[#2271b8]" />
          <h3 className="font-['Ninetea:Bold',sans-serif] text-[#130b3d]">Nutrición Recomendada</h3>
        </div>
        <div className="space-y-3">
          {currentNutrition.map((item, index) => {
            const IconComponent = item.icon;
            return (
              <motion.div
                key={index}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.1 }}
                className="bg-[rgba(252,239,221,0.5)] backdrop-blur-xl border border-white shadow-lg rounded-2xl p-4 hover:shadow-xl transition-shadow cursor-pointer"
                onClick={() => onNutritionClick?.(item, currentPhase)}
              >
                <div className="flex items-start gap-3">
                  <div className={`p-2 rounded-xl bg-gradient-to-r ${item.color}`}>
                    <IconComponent className="w-5 h-5 text-white" strokeWidth={2} />
                  </div>
                  <div className="flex-1">
                    <h4 className="font-['Ninetea:Bold',sans-serif] text-[#130b3d] mb-1">{item.food}</h4>
                    <p className="font-['Inter:Regular',sans-serif] text-sm text-[#5250a2]">{item.reason}</p>
                  </div>
                  <ChevronRight className="w-5 h-5 text-[#2271b8]" />
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>

      {/* Exercise Section */}
      <div>
        <div className="flex items-center gap-2 mb-4">
          <Dumbbell className="w-5 h-5 text-[#f58020]" />
          <h3 className="font-['Ninetea:Bold',sans-serif] text-[#130b3d]">Ejercicio Recomendado</h3>
        </div>
        <div className="space-y-3">
          {currentExercise.map((item, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: index * 0.1 + 0.4 }}
              className="bg-gradient-to-r from-[rgba(245,128,32,0.5)] to-[rgba(245,235,195,0.5)] backdrop-blur-xl border border-white shadow-lg rounded-2xl p-4 cursor-pointer hover:shadow-xl transition-shadow"
              onClick={() => onExerciseClick?.(item.type)}
            >
              <div className="flex items-center justify-between mb-2">
                <h4 className="font-['Ninetea:Bold',sans-serif] text-[#130b3d]">{item.type}</h4>
                <span className={`font-['Inter:Bold',sans-serif] text-xs px-3 py-1 rounded-full ${
                  item.intensity.includes('Alta') || item.intensity.includes('Muy')
                    ? 'bg-[#130b3d] text-white'
                    : item.intensity.includes('Media')
                    ? 'bg-[#5250a2] text-white'
                    : 'bg-[#2271b8] text-white'
                }`}>
                  {item.intensity}
                </span>
              </div>
              <div className="flex items-center gap-4 text-sm text-[#130b3d] mb-2">
                <span className="font-['Inter:Regular',sans-serif]">⏱️ {item.duration}</span>
              </div>
              <p className="font-['Inter:Regular',sans-serif] text-sm text-[#130b3d]">{item.benefit}</p>
            </motion.div>
          ))}
        </div>
      </div>

      {/* AI Insights */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.8 }}
        className="bg-gradient-to-br from-[rgba(34,113,184,0.9)] to-[rgba(82,80,162,0.9)] backdrop-blur-xl border border-white shadow-lg rounded-2xl p-5"
      >
        <div className="flex items-start gap-3">
          <Lightbulb className="w-5 h-5 text-[#f5ebc3] mt-1" />
          <div>
            <h4 className="font-['Ninetea:Bold',sans-serif] text-white mb-2">Insights Personalizados</h4>
            <ul className="space-y-2 text-sm text-[#fbeedc]">
              {currentInsights.map((insight, index) => (
                <li key={index} className="flex items-start gap-2">
                  <span className="text-[#f58020]">•</span>
                  <span className="font-['Inter:Regular',sans-serif]">{insight}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </motion.div>
    </div>
  );
}

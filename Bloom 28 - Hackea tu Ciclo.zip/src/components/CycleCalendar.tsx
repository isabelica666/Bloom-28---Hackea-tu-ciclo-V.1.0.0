import { motion } from 'motion/react';
import { ChevronLeft, ChevronRight, Circle } from 'lucide-react';
import { useState } from 'react';
import { calculateCycleInfo, type CycleData } from '../utils/cycleCalculations';

interface CycleCalendarProps {
  cycleData: CycleData;
}

export function CycleCalendar({ cycleData }: CycleCalendarProps) {
  const [currentMonth] = useState(new Date());
  const today = new Date();
  const cycleInfo = calculateCycleInfo(cycleData);
  
  const monthNames = ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 
                      'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'];
  
  const daysInMonth = new Date(currentMonth.getFullYear(), currentMonth.getMonth() + 1, 0).getDate();
  const firstDayOfMonth = new Date(currentMonth.getFullYear(), currentMonth.getMonth(), 1).getDay();
  
  // Función para obtener el día del ciclo para una fecha específica
  const getCycleDayForDate = (date: Date): number => {
    const lastPeriod = new Date(cycleData.lastPeriodDate);
    const diffTime = date.getTime() - lastPeriod.getTime();
    const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));
    const cycleDay = (diffDays % cycleData.cycleDuration) + 1;
    return cycleDay > 0 ? cycleDay : cycleData.cycleDuration + cycleDay;
  };
  
  // Función para obtener la fase según el día del ciclo
  const getPhaseForCycleDay = (cycleDay: number): string => {
    if (cycleDay <= cycleData.periodDuration) return 'menstrual';
    if (cycleDay <= 12) return 'folicular';
    if (cycleDay <= 15) return 'ovulacion';
    return 'lutea';
  };

  const getPhaseColor = (cycleDay: number) => {
    const phase = getPhaseForCycleDay(cycleDay);
    if (phase === 'menstrual') return 'bg-[#130b3d]';
    if (phase === 'folicular') return 'bg-[#2271b8]';
    if (phase === 'ovulacion') return 'bg-[#f58020]';
    if (phase === 'lutea') return 'bg-[#5250a2]';
    return 'bg-gray-200';
  };

  const days = ['Dom', 'Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb'];
  const calendarDays = Array.from({ length: 42 }, (_, i) => {
    const day = i - firstDayOfMonth + 1;
    return day > 0 && day <= daysInMonth ? day : null;
  });

  // Calcular próximas fechas importantes
  const nextOvulationDay = 13; // Día 13 del ciclo
  const daysUntilOvulation = nextOvulationDay - cycleInfo.currentDay;
  const adjustedDaysUntilOvulation = daysUntilOvulation < 0 
    ? cycleData.cycleDuration - cycleInfo.currentDay + nextOvulationDay 
    : daysUntilOvulation;
  
  const nextOvulationDate = new Date(today);
  nextOvulationDate.setDate(today.getDate() + adjustedDaysUntilOvulation);
  
  const nextPeriodDate = new Date(today);
  nextPeriodDate.setDate(today.getDate() + cycleInfo.daysUntilNextPeriod);
  
  const fertileWindowStart = new Date(nextOvulationDate);
  fertileWindowStart.setDate(nextOvulationDate.getDate() - 2);
  const fertileWindowEnd = new Date(nextOvulationDate);
  fertileWindowEnd.setDate(nextOvulationDate.getDate() + 2);

  return (
    <div className="p-6 space-y-6 bg-gradient-to-b from-[#ffe0c6] to-[#f5ebc3] min-h-screen pb-24">
      {/* Current Cycle Info */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-gradient-to-r from-[rgba(245,128,32,0.9)] to-[rgba(239,147,45,0.9)] backdrop-blur-xl border border-white shadow-lg rounded-3xl p-5 text-white"
      >
        <div className="text-center">
          <p className="font-['Inter:Regular',sans-serif] text-sm text-[#fbeedc] mb-1">Estás en el</p>
          <h2 className="font-['Ninetea:Bold',sans-serif] text-3xl mb-1">Día {cycleInfo.currentDay}</h2>
          <p className="font-['Inter:Regular',sans-serif] text-sm text-[#fbeedc]">
            de tu ciclo - Fase {cycleInfo.currentPhase === 'menstrual' ? 'Menstrual' : 
                                cycleInfo.currentPhase === 'folicular' ? 'Folicular' : 
                                cycleInfo.currentPhase === 'ovulacion' ? 'de Ovulación' : 'Lútea'}
          </p>
        </div>
      </motion.div>

      {/* Month Navigation */}
      <div className="flex items-center justify-between">
        <button className="p-2 hover:bg-white/50 rounded-full transition-colors">
          <ChevronLeft className="w-5 h-5 text-[#130b3d]" />
        </button>
        <h3 className="font-['Ninetea:Bold',sans-serif] text-[#130b3d]">{monthNames[currentMonth.getMonth()]} {currentMonth.getFullYear()}</h3>
        <button className="p-2 hover:bg-white/50 rounded-full transition-colors">
          <ChevronRight className="w-5 h-5 text-[#130b3d]" />
        </button>
      </div>

      {/* Calendar Grid */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="bg-[rgba(252,239,221,0.5)] backdrop-blur-xl border border-white shadow-lg rounded-3xl p-5"
      >
        {/* Day Headers */}
        <div className="grid grid-cols-7 gap-2 mb-3">
          {days.map(day => (
            <div key={day} className="font-['Inter:Bold',sans-serif] text-center text-[#130b3d] text-xs">
              {day}
            </div>
          ))}
        </div>

        {/* Calendar Days */}
        <div className="grid grid-cols-7 gap-2">
          {calendarDays.map((day, index) => (
            <div key={index} className="aspect-square">
              {day && (
                <button
                  className={`w-full h-full rounded-xl flex items-center justify-center text-sm relative font-['Inter:Bold',sans-serif]
                    ${getPhaseColor(getCycleDayForDate(new Date(currentMonth.getFullYear(), currentMonth.getMonth(), day)))} ${day === today.getDate() ? 'ring-2 ring-[#f58020] ring-offset-2' : ''}
                    hover:opacity-80 transition-opacity text-white
                  `}
                >
                  {day}
                  {day === today.getDate() && (
                    <Circle className="w-2 h-2 fill-white absolute bottom-1" />
                  )}
                </button>
              )}
            </div>
          ))}
        </div>
      </motion.div>

      {/* Legend */}
      <div className="bg-[rgba(252,239,221,0.5)] backdrop-blur-xl border border-white shadow-lg rounded-2xl p-5">
        <h4 className="font-['Ninetea:Bold',sans-serif] mb-3 text-[#130b3d]">Leyenda</h4>
        <div className="space-y-2">
          <div className="flex items-center gap-3">
            <div className="w-6 h-6 rounded-lg bg-[#130b3d]"></div>
            <span className="font-['Inter:Regular',sans-serif] text-sm text-[#130b3d]">Menstruación (Días 1-5)</span>
          </div>
          <div className="flex items-center gap-3">
            <div className="w-6 h-6 rounded-lg bg-[#2271b8]"></div>
            <span className="font-['Inter:Regular',sans-serif] text-sm text-[#130b3d]">Fase Folicular (Días 6-12)</span>
          </div>
          <div className="flex items-center gap-3">
            <div className="w-6 h-6 rounded-lg bg-[#f58020]"></div>
            <span className="font-['Inter:Regular',sans-serif] text-sm text-[#130b3d]">Ovulación (Días 13-15)</span>
          </div>
          <div className="flex items-center gap-3">
            <div className="w-6 h-6 rounded-lg bg-[#5250a2]"></div>
            <span className="font-['Inter:Regular',sans-serif] text-sm text-[#130b3d]">Fase Lútea (Días 16-28)</span>
          </div>
        </div>
      </div>

      {/* Predictions */}
      <div className="bg-gradient-to-r from-[rgba(34,113,184,0.9)] to-[rgba(82,80,162,0.9)] backdrop-blur-xl border border-white shadow-lg rounded-2xl p-5">
        <h4 className="font-['Ninetea:Bold',sans-serif] text-white mb-3">Predicciones</h4>
        <div className="space-y-2 text-sm">
          <p className="font-['Inter:Regular',sans-serif] text-[#fbeedc]">
            <span className="font-['Inter:Bold',sans-serif]">Próxima ovulación:</span> En {adjustedDaysUntilOvulation} días ({nextOvulationDate.getDate()} {monthNames[nextOvulationDate.getMonth()]})
          </p>
          <p className="font-['Inter:Regular',sans-serif] text-[#fbeedc]">
            <span className="font-['Inter:Bold',sans-serif]">Próximo período:</span> En {cycleInfo.daysUntilNextPeriod} días ({nextPeriodDate.getDate()} {monthNames[nextPeriodDate.getMonth()]})
          </p>
          <p className="font-['Inter:Regular',sans-serif] text-[#fbeedc]">
            <span className="font-['Inter:Bold',sans-serif]">Ventana fértil:</span> {fertileWindowStart.getDate()} - {fertileWindowEnd.getDate()} {monthNames[fertileWindowStart.getMonth()]}
          </p>
        </div>
      </div>
    </div>
  );
}
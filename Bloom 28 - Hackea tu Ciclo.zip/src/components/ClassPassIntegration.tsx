import { motion } from 'motion/react';
import { ArrowLeft, Search, MapPin, Star, ChevronRight, Link2, CheckCircle2, ExternalLink } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { useEffect } from 'react';

interface ClassPassIntegrationProps {
  activityType: string;
  onBack: () => void;
}

export function ClassPassIntegration({ activityType, onBack }: ClassPassIntegrationProps) {
  // Scroll to top cuando se monta el componente
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  // URLs de imágenes de Unsplash
  const studioImages = {
    yoga: 'https://images.unsplash.com/photo-1599447421376-611783057464?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx5b2dhJTIwc3R1ZGlvJTIwaW50ZXJpb3J8ZW58MXx8fHwxNzY4NTQ3ODcxfDA&ixlib=rb-4.1.0&q=80&w=1080',
    crossfit: 'https://images.unsplash.com/photo-1632758205645-732ee46c17fe?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjcm9zc2ZpdCUyMGd5bSUyMGVxdWlwbWVudHxlbnwxfHx8fDE3Njg2NjQyODd8MA&ixlib=rb-4.1.0&q=80&w=1080',
    spinning: 'https://images.unsplash.com/photo-1760031670160-4da44e9596d0?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzcGlubmluZyUyMGN5Y2xpbmclMjBzdHVkaW98ZW58MXx8fHwxNzY4NjY0Mjg3fDA&ixlib=rb-4.1.0&q=80&w=1080',
    pilates: 'https://images.unsplash.com/photo-1754258166816-0075fe0132ce?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwaWxhdGVzJTIwcmVmb3JtZXIlMjBzdHVkaW98ZW58MXx8fHwxNzY4NjY0Mjg4fDA&ixlib=rb-4.1.0&q=80&w=1080',
    bootcamp: 'https://images.unsplash.com/photo-1758875570256-6510adffb1de?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmaXRuZXNzJTIwYm9vdGNhbXAlMjB0cmFpbmluZ3xlbnwxfHx8fDE3Njg2NjQyODh8MA&ixlib=rb-4.1.0&q=80&w=1080',
    weights: 'https://images.unsplash.com/photo-1653927956711-f2222a45e040?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxneW0lMjB3ZWlnaHRzJTIwZXF1aXBtZW50fGVufDF8fHx8MTc2ODY2NDI4OHww&ixlib=rb-4.1.0&q=80&w=1080'
  };

  // Simulación de estudios cercanos según el tipo de actividad
  const getRecommendedStudios = () => {
    const studios: Record<string, any[]> = {
      'Yoga suave': [
        { name: 'Sangha Studio', distance: '1.9 km', types: 'Estiramientos, Pilates, Yoga', rating: 5.0, reviews: 500, imageUrl: studioImages.yoga },
        { name: 'Hara Yoga Studio', distance: '1.9 km', types: 'Pilates, Yoga, Meditación', rating: 4.8, reviews: 1000, imageUrl: studioImages.yoga },
        { name: 'Casa Noor el teu centre', distance: '2.3 km', types: 'Yoga, Meditación, Mindfulness', rating: 4.9, reviews: 850, imageUrl: studioImages.yoga }
      ],
      'Yoga restaurativo': [
        { name: 'Sangha Studio', distance: '1.9 km', types: 'Estiramientos, Pilates, Yoga', rating: 5.0, reviews: 500, imageUrl: studioImages.yoga },
        { name: 'Hara Yoga Studio', distance: '1.9 km', types: 'Pilates, Yoga, Meditación', rating: 4.8, reviews: 1000, imageUrl: studioImages.yoga },
        { name: 'Calm Space Yoga', distance: '2.1 km', types: 'Yoga Restaurativo, Yin Yoga', rating: 4.9, reviews: 650, imageUrl: studioImages.yoga }
      ],
      'Entrenamiento HIIT': [
        { name: 'CrossFit Barcelona', distance: '1.5 km', types: 'HIIT, CrossFit, Fuerza', rating: 4.9, reviews: 1200, imageUrl: studioImages.crossfit },
        { name: 'Barry\'s Bootcamp', distance: '2.2 km', types: 'HIIT, Cardio, Running', rating: 4.8, reviews: 950, imageUrl: studioImages.bootcamp },
        { name: 'F45 Training', distance: '1.8 km', types: 'HIIT, Funcional, Cardio', rating: 4.7, reviews: 800, imageUrl: studioImages.bootcamp }
      ],
      'Levantamiento de pesas': [
        { name: 'Iron Gym Barcelona', distance: '1.3 km', types: 'Pesas, Fuerza, Culturismo', rating: 4.8, reviews: 1500, imageUrl: studioImages.weights },
        { name: 'Powerhouse Gym', distance: '2.0 km', types: 'Pesas Libres, Máquinas, Fuerza', rating: 4.9, reviews: 1100, imageUrl: studioImages.weights },
        { name: 'Olympic Fitness', distance: '1.7 km', types: 'CrossFit, Pesas, Halterofilia', rating: 4.7, reviews: 750, imageUrl: studioImages.crossfit }
      ],
      'CrossFit': [
        { name: 'CrossFit Barcelona', distance: '1.5 km', types: 'CrossFit, HIIT, Olimpicos', rating: 4.9, reviews: 1200, imageUrl: studioImages.crossfit },
        { name: 'Reebok CrossFit', distance: '2.3 km', types: 'CrossFit, Gimnasia, Fuerza', rating: 4.8, reviews: 1050, imageUrl: studioImages.crossfit },
        { name: 'Box Elements', distance: '1.9 km', types: 'CrossFit, Funcional, HIIT', rating: 4.9, reviews: 900, imageUrl: studioImages.crossfit }
      ],
      'Spinning': [
        { name: 'CycleBar', distance: '1.6 km', types: 'Spinning, Cycling, Cardio', rating: 4.9, reviews: 1300, imageUrl: studioImages.spinning },
        { name: 'SoulCycle', distance: '2.0 km', types: 'Indoor Cycling, Cardio', rating: 4.8, reviews: 1100, imageUrl: studioImages.spinning },
        { name: 'Ride Studio', distance: '1.4 km', types: 'Spinning, HIIT Bike, Cardio', rating: 4.7, reviews: 850, imageUrl: studioImages.spinning }
      ],
      'Pilates intenso': [
        { name: 'Studio Adp Pilates', distance: '2.1 km', types: 'Pilates Reformer, Mat', rating: 4.9, reviews: 750, imageUrl: studioImages.pilates },
        { name: 'Core Pilates Barcelona', distance: '1.8 km', types: 'Pilates, Reformer, Barre', rating: 4.8, reviews: 900, imageUrl: studioImages.pilates },
        { name: 'Club Pilates', distance: '2.3 km', types: 'Pilates Reformer, TRX', rating: 4.7, reviews: 650, imageUrl: studioImages.pilates }
      ],
      'Estiramientos': [
        { name: 'Stretch Lab', distance: '1.7 km', types: 'Estiramientos, Movilidad', rating: 5.0, reviews: 450, imageUrl: studioImages.yoga },
        { name: 'Sangha Studio', distance: '1.9 km', types: 'Estiramientos, Pilates, Yoga', rating: 5.0, reviews: 500, imageUrl: studioImages.yoga },
        { name: 'Recovery Lab', distance: '2.0 km', types: 'Estiramientos, Recuperación', rating: 4.8, reviews: 380, imageUrl: studioImages.yoga }
      ]
    };
    return studios[activityType] || studios['Yoga suave'];
  };

  const recommendedStudios = getRecommendedStudios();

  return (
    <div className="min-h-screen bg-[#fbeedc]">
      {/* Header */}
      <div className="bg-gradient-to-br from-[#2271b8] to-[#5250a2] px-6 pt-12 pb-6 rounded-b-[30px] shadow-xl">
        <button onClick={onBack} className="mb-6 flex items-center gap-2 text-white">
          <ArrowLeft className="w-6 h-6" strokeWidth={2} />
          <span className="font-['Inter:Medium',sans-serif] text-sm">Volver</span>
        </button>
        
        <div className="flex items-center gap-3 mb-4">
          <div className="w-12 h-12 bg-white rounded-2xl flex items-center justify-center">
            <Link2 className="w-7 h-7 text-[#2271b8]" strokeWidth={2.5} />
          </div>
          <div>
            <h1 className="font-['Ninetea:Bold',sans-serif] text-white text-[28px] leading-tight">ClassPass</h1>
            <p className="font-['Inter:Regular',sans-serif] text-white/80 text-sm">Encuentra tu clase ideal</p>
          </div>
        </div>
      </div>

      {/* Connection Status */}
      <div className="px-6 py-6">
        <motion.div 
          className="bg-gradient-to-br from-green-50 to-emerald-50 border-2 border-green-400 rounded-2xl p-4 flex items-center gap-3"
          initial={{ scale: 0.95, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
        >
          <CheckCircle2 className="w-6 h-6 text-green-600 flex-shrink-0" strokeWidth={2.5} />
          <div>
            <p className="font-['Ninetea:Bold',sans-serif] text-green-900 text-sm">Conectado con ClassPass</p>
            <p className="font-['Inter:Regular',sans-serif] text-green-700 text-xs">Tu cuenta está sincronizada</p>
          </div>
        </motion.div>
      </div>

      {/* Activity Type */}
      <div className="px-6 mb-6">
        <div className="bg-[rgba(252,239,221,0.5)] backdrop-blur-xl border border-white shadow-lg rounded-2xl p-4">
          <p className="font-['Inter:Regular',sans-serif] text-[#130b3d] text-sm mb-1">Actividad recomendada para ti:</p>
          <h2 className="font-['Ninetea:Bold',sans-serif] text-[#f58020] text-xl">{activityType}</h2>
        </div>
      </div>

      {/* Search Bar */}
      <div className="px-6 mb-6">
        <div className="bg-white border border-gray-200 rounded-full px-5 py-3 flex items-center gap-3 shadow-sm">
          <Search className="w-5 h-5 text-gray-400" strokeWidth={2} />
          <input 
            type="text" 
            placeholder="Yoga, pilates, masajes, etc." 
            className="flex-1 bg-transparent font-['Inter:Regular',sans-serif] text-sm text-[#130b3d] outline-none placeholder-gray-400"
          />
        </div>
      </div>

      {/* Lugares guardados */}
      <div className="px-6 mb-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-['Ninetea:Bold',sans-serif] text-[#130b3d] text-lg">Lugares guardados</h3>
          <button className="font-['Inter:Medium',sans-serif] text-[#2271b8] text-sm flex items-center gap-1">
            Ver todo
            <ChevronRight className="w-4 h-4" strokeWidth={2} />
          </button>
        </div>
        <div className="flex gap-3 overflow-x-auto pb-2">
          {recommendedStudios.slice(0, 3).map((studio, index) => (
            <div key={index} className="flex-shrink-0 w-20">
              <div className="w-20 h-20 rounded-full mb-2 overflow-hidden shadow-md">
                <ImageWithFallback
                  src={studio.imageUrl}
                  alt={studio.name}
                  className="w-full h-full object-cover"
                />
              </div>
              <p className="font-['Inter:Medium',sans-serif] text-[#130b3d] text-xs text-center line-clamp-2">
                {studio.name.split(' ')[0]}...
              </p>
            </div>
          ))}
        </div>
      </div>

      {/* Recomendado para ti */}
      <div className="px-6 mb-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-['Ninetea:Bold',sans-serif] text-[#130b3d] text-lg">Recomendado para ti</h3>
          <button className="font-['Inter:Medium',sans-serif] text-[#2271b8] text-sm flex items-center gap-1">
            <ChevronRight className="w-4 h-4" strokeWidth={2} />
          </button>
        </div>
        <div className="space-y-4">
          {recommendedStudios.map((studio, index) => (
            <motion.div
              key={index}
              className="bg-white rounded-2xl overflow-hidden shadow-md"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
            >
              <div className="h-40 relative overflow-hidden">
                <ImageWithFallback
                  src={studio.imageUrl}
                  alt={studio.name}
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="p-4">
                <div className="flex items-start justify-between mb-2">
                  <div className="flex-1">
                    <h4 className="font-['Ninetea:Bold',sans-serif] text-[#130b3d] text-base mb-1">{studio.name}</h4>
                    <div className="flex items-center gap-1 mb-2">
                      <MapPin className="w-3 h-3 text-gray-500" strokeWidth={2} />
                      <span className="font-['Inter:Regular',sans-serif] text-gray-600 text-xs">{studio.distance}</span>
                    </div>
                  </div>
                  <button className="flex-shrink-0 ml-2">
                    <ExternalLink className="w-5 h-5 text-[#2271b8]" strokeWidth={2} />
                  </button>
                </div>
                <p className="font-['Inter:Regular',sans-serif] text-gray-600 text-sm mb-3">{studio.types}</p>
                <div className="flex items-center gap-2">
                  <div className="flex items-center gap-1">
                    <Star className="w-4 h-4 text-[#f58020] fill-[#f58020]" strokeWidth={2} />
                    <span className="font-['Ninetea:Bold',sans-serif] text-[#130b3d] text-sm">{studio.rating}</span>
                  </div>
                  <span className="font-['Inter:Regular',sans-serif] text-gray-500 text-xs">
                    ({studio.reviews}+) Excelente
                  </span>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>

      {/* CTA para ver más */}
      <div className="px-6 pb-28">
        <button className="w-full bg-gradient-to-r from-[#2271b8] to-[#5250a2] text-white font-['Ninetea:Bold',sans-serif] py-4 rounded-full shadow-lg flex items-center justify-center gap-2">
          Explorar todas las clases en ClassPass
          <ExternalLink className="w-5 h-5" strokeWidth={2} />
        </button>
      </div>
    </div>
  );
}
import { User, Calendar, Heart, Flame, Thermometer, Moon } from 'lucide-react';
import { calculateCycleInfo, getPhaseName, type CycleData } from '../utils/cycleCalculations';
import { getCurrentBiometrics } from '../utils/biometricData';

interface DashboardProps {
  cycleData: CycleData;
  userName: string;
  onSymptomsClick: () => void;
  onPeriodClick: () => void;
  onTemperatureClick: () => void;
  onHeartRateClick: () => void;
  onSleepClick: () => void;
  onProfileClick: () => void;
  onStartPeriodClick: () => void;
}

export function Dashboard({ cycleData, userName, onSymptomsClick, onPeriodClick, onTemperatureClick, onHeartRateClick, onSleepClick, onProfileClick, onStartPeriodClick }: DashboardProps) {
  const cycleInfo = calculateCycleInfo(cycleData);
  const currentDay = cycleInfo.currentDay;
  const nextPeriodDays = cycleInfo.daysUntilNextPeriod;
  const currentPhase = getPhaseName(cycleInfo.currentPhase);
  
  // Obtener valores biométricos según la fase actual
  const biometrics = getCurrentBiometrics(cycleInfo.currentPhase);
  
  // Generate current week days
  const today = new Date();
  const weekDays = Array.from({ length: 7 }, (_, i) => {
    const date = new Date(today);
    date.setDate(today.getDate() - 3 + i);
    return {
      day: date.getDate(),
      label: ['Do', 'Lu', 'Ma', 'Mie', 'Ju', 'Vi', 'Sa'][date.getDay()],
      active: i === 3
    };
  });

  // Generate dots around circle
  const totalDays = cycleData.cycleDuration;
  const dots = Array.from({ length: totalDays }, (_, i) => {
    const angle = (i / totalDays) * 360 - 90;
    const radius = 100;
    const x = 107 + radius * Math.cos((angle * Math.PI) / 180);
    const y = 107 + radius * Math.sin((angle * Math.PI) / 180);
    return { x, y, active: i < currentDay };
  });

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#ffe0c6] to-[#f5ebc3] relative overflow-hidden pb-[100px]">
      {/* Pink blur decoration */}
      <div className="absolute top-8 right-[-40px] w-[190px] h-[200px] opacity-80">
        <div className="w-full h-full rounded-full bg-[#FD587A] opacity-24 blur-[75px]" />
      </div>

      {/* Status Bar */}
      <div className="h-[44px] flex items-center justify-between px-[15px] relative z-10">
        <span className="font-['SF_Pro_Text:Semibold',sans-serif] text-[15px] text-[#121212] tracking-[-0.32px]">
          9:41
        </span>
        <div className="flex gap-[2px] items-center">
          <div className="w-[20px] h-[16px]">
            <svg viewBox="0 0 20 16" fill="none">
              <path d="M17.3334 0H2.66675C1.93341 0 1.33341 0.6 1.33341 1.33333V14.6667C1.33341 15.4 1.93341 16 2.66675 16H17.3334C18.0667 16 18.6667 15.4 18.6667 14.6667V1.33333C18.6667 0.6 18.0667 0 17.3334 0ZM4.00008 2.66667H6.66675V6.66667H4.00008V2.66667ZM9.33341 2.66667H12.0001V6.66667H9.33341V2.66667ZM14.6667 13.3333H5.33341V9.33333H14.6667V13.3333ZM14.6667 6.66667V2.66667H16.0001V6.66667H14.6667Z" fill="#121212"/>
            </svg>
          </div>
          <div className="w-[16px] h-[16px]">
            <svg viewBox="0 0 16 16" fill="none">
              <path d="M0.666748 7.99992C0.666748 7.99992 3.33341 2.66659 8.00008 2.66659C12.6667 2.66659 15.3334 7.99992 15.3334 7.99992C15.3334 7.99992 12.6667 13.3333 8.00008 13.3333C3.33341 13.3333 0.666748 7.99992 0.666748 7.99992Z" fill="#121212"/>
            </svg>
          </div>
          <div className="w-[25px] h-[16px]">
            <svg viewBox="0 0 25 16" fill="none">
              <rect x="1" y="1" width="18" height="14" rx="2.5" stroke="#121212" opacity="0.35"/>
              <path d="M23 6V10C23.8 9.6 24.3 8.8 24.3 8C24.3 7.2 23.8 6.4 23 6Z" fill="#121212" opacity="0.4"/>
              <rect x="2" y="2" width="16" height="12" rx="1.5" fill="#121212"/>
            </svg>
          </div>
        </div>
      </div>

      {/* Header */}
      <div className="px-[24px] py-[16px] flex items-center justify-between relative z-10">
        <button onClick={onProfileClick} className="flex flex-col text-left hover:opacity-80 transition-opacity active:scale-95">
          <span className="font-['Ninetea:Semi_Bold',sans-serif] text-[32px] text-[#130b3d] mb-[2px]">
            {userName ? `Hola, ${userName}!` : 'Hola!'}
          </span>
        </button>
        <div className="flex items-baseline gap-[3.5px]">
          <span className="font-['Cal_Sans:Regular',sans-serif] text-[19.373px] text-[#130b3d]">
            Bloom
          </span>
          <span className="font-['Gebuk:Regular',sans-serif] text-[21.708px] text-[#130b3d]">
            28
          </span>
        </div>
      </div>

      {/* Next Period Info */}
      <div className="px-[24px] pt-[10px] pb-[14px] text-center">
        <p className="font-['Ninetea:Medium',sans-serif] text-[12.473px] text-[#130b3d] leading-[17.818px]">
          Próximo período en {nextPeriodDays} días
        </p>
      </div>

      {/* Cycle Circle */}
      <div className="px-[24px] flex justify-center mb-[43px]">
        <div className="relative w-[213.818px] h-[213.818px]">
          {/* Border ring with glassmorphism */}
          <div className="absolute inset-0 rounded-full bg-[rgba(250,209,163,0.4)] backdrop-blur-xl border border-white shadow-lg" style={{ padding: '14.255px' }}>
            <div className="w-full h-full rounded-full bg-gradient-to-b from-[#ffe0c6] to-[#f5ebc3]" />
          </div>
          
          {/* Dots layer */}
          <div className="absolute left-[7.13px] top-[7.13px] w-[199.564px] h-[199.564px]">
            {dots.map((dot, i) => (
              <div
                key={i}
                className="absolute w-[3.564px] h-[3.564px]"
                style={{ left: `${dot.x - 7.13 - 1.782}px`, top: `${dot.y - 7.13 - 1.782}px` }}
              >
                <svg viewBox="0 0 4 4" fill="none" className="w-full h-full">
                  <circle
                    cx="1.78182"
                    cy="1.78182"
                    r="1.78182"
                    fill={dot.active ? "url(#gradient)" : "#e5d4c1"}
                  />
                  <defs>
                    <linearGradient id="gradient" x1="4.13778" x2="-1.08889" y1="3.30626" y2="0">
                      <stop stopColor="#EF932D" />
                      <stop offset="1" stopColor="#F58020" />
                    </linearGradient>
                  </defs>
                </svg>
              </div>
            ))}
            
            {/* Current day indicator on perimeter */}
            <div
              className="absolute w-[21.382px] h-[21.382px]"
              style={{
                left: `${dots[currentDay - 1]?.x - 7.13 - 10.691}px`,
                top: `${dots[currentDay - 1]?.y - 7.13 - 10.691}px`
              }}
            >
              <div className="relative w-full h-full">
                <svg viewBox="0 0 31 31" fill="none" className="w-full h-full">
                  <circle cx="15.5" cy="14.43" r="10.69" fill="white" />
                  <circle cx="15.5" cy="14.43" r="10.02" stroke="url(#gradientBorder)" strokeWidth="1.34" />
                  <defs>
                    <linearGradient id="gradientBorder" x1="29.64" x2="-1.72" y1="23.58" y2="3.74">
                      <stop stopColor="#EF932D" />
                      <stop offset="1" stopColor="#C294EC" />
                    </linearGradient>
                  </defs>
                </svg>
                <p className="absolute inset-0 flex items-center justify-center font-['Poppins:Medium',sans-serif] text-[10.691px] text-[#f58020] leading-[14.255px]">
                  {currentDay}
                </p>
              </div>
            </div>
          </div>

          {/* Center wave circle with glassmorphism */}
          <div 
            onClick={onStartPeriodClick}
            className="absolute left-[35.64px] top-[35.64px] w-[142.545px] h-[142.545px] rounded-full bg-[rgba(234,219,249,0.3)] backdrop-blur-xl border border-white shadow-lg overflow-hidden cursor-pointer hover:bg-[rgba(234,219,249,0.5)] transition-all duration-200 active:scale-95"
          >
            {/* Wave background */}
            <div className="absolute inset-0 flex items-center justify-center overflow-hidden">
              <div className="absolute inset-0 mix-blend-multiply">
                <svg viewBox="0 0 1534 138" className="absolute w-[1533.254px] h-[137.2px] top-[50%] left-[50%] -translate-x-[50%] -translate-y-[20%]">
                  <path d="M0 88.6909C64.92 41.3455 156.04 7.38182 266.509 7.38182C376.978 7.38182 468.098 41.3455 533.018 88.6909C597.938 136.036 689.058 170 799.527 170C910.996 170 1001.12 136.036 1066.04 88.6909C1130.96 41.3455 1222.08 7.38182 1332.55 7.38182C1443.02 7.38182 1534.14 41.3455 1599.06 88.6909V176.382H0V88.6909Z" fill="#FFE0C6" />
                </svg>
              </div>
            </div>
            
            {/* Text content */}
            <div className="absolute inset-0 flex flex-col items-center justify-center">
              <p className="font-['Ninetea:Medium',sans-serif] text-[15px] text-[#130b3d] leading-[17.818px] mb-[16px]">
                {currentPhase}
              </p>
              <p className="font-['Poppins:Bold',sans-serif] text-[32px] text-[rgb(255,150,18)] leading-[24.945px]">
                Día {currentDay}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Week Days */}
      <div className="px-[24px] mb-[50px] flex justify-center">
        <div className="w-[307.364px] flex items-center justify-between relative">
          {/* Indicator background for active day */}
          <div className="absolute bg-[rgba(239,147,45,0.8)] backdrop-blur-xl border border-white shadow-lg w-[52.564px] h-[52.564px] rounded-full left-[50%] top-[50%] -translate-x-[50%] -translate-y-[50%]" 
               style={{ left: `${3 * (307.364 / 6)}px` }} />
          
          {weekDays.map((item, index) => (
            <div
              key={index}
              className="flex flex-col gap-[1.782px] items-center justify-center text-center leading-[0] relative z-10 w-[43.909px]"
            >
              <div className={`font-['Poppins:Medium',sans-serif] h-[21.382px] flex items-center justify-center ${
                item.active ? 'text-[#f5ebc3] text-[17.818px]' : 'text-[#130b3d] text-[16.036px]'
              }`}>
                <p className="leading-[21.382px]">{item.day}</p>
              </div>
              <div className={`font-['Poppins:Regular',sans-serif] h-[12.473px] flex items-center justify-center ${
                item.active ? 'text-[#f5ebc3] text-[12.473px]' : 'text-[#7c7c7c] text-[10.691px]'
              }`}>
                <p className={item.active ? 'leading-[17.818px]' : 'leading-normal'}>{item.label}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Action Buttons */}
      <div className="px-[24px] mb-[31px] flex justify-center">
        <div className="w-[307.364px] flex gap-[10.691px]">
          <button className="flex-1 h-[42.764px] bg-[rgba(255,255,255,0.3)] backdrop-blur-xl border border-[#f58020] rounded-[21.382px] font-['Ninetea:Medium',sans-serif] text-[#f58020] text-[12.473px] leading-[21.382px] shadow-lg" onClick={onSymptomsClick}>
            Sintomas
          </button>
          <button className="flex-1 h-[42.764px] bg-[rgba(245,128,32,0.8)] backdrop-blur-xl border border-white rounded-[21.382px] font-['Ninetea:Medium',sans-serif] text-white text-[12.473px] leading-[21.382px] shadow-lg" onClick={onPeriodClick}>
            Periodo
          </button>
        </div>
      </div>

      {/* Métricas de Hoy */}
      <div className="px-[24px] mb-[13px]">
        <h3 className="font-['Ninetea:Semi_Bold',sans-serif] text-[15.368px] text-[#130b3d] leading-[21.955px] text-center mb-[16px]">
          Métricas de Hoy
        </h3>
        <div className="flex gap-[16px] mb-[17px]">
          {/* Temperature */}
          <div className="flex-1 bg-[rgba(249,249,249,0.3)] backdrop-blur-xl border border-white shadow-lg rounded-[17px] h-[124.455px] flex flex-col items-center justify-center relative cursor-pointer hover:bg-[rgba(249,249,249,0.5)] transition-all duration-200 active:scale-95" onClick={onTemperatureClick}>
            <Thermometer className="w-[18px] h-[18px] text-[#f58020] mb-[8px] absolute top-[14px]" strokeWidth={1.11395} />
            <p className="font-['Ninetea:Bold',sans-serif] text-[#130b3d] leading-[12.8px] mb-[8px] mt-[28px]">
              <span className="text-[35.47px]">{biometrics.temperature}°</span>
              <span className="font-['Ninetea:Semi_Bold',sans-serif] text-[27.47px]">c</span>
            </p>
            <p className="font-['Ninetea:Medium',sans-serif] text-[8.47px] text-[#130b3d] leading-[12.8px] mb-[4px]">
            </p>
            <p className="font-['Ninetea:Semi_Bold',sans-serif] text-[12.473px] text-[#ef932d] leading-[12.8px] text-center">
              Temperatura<br />Basal
            </p>
          </div>

          {/* Heart Rate */}
          <div className="flex-1 bg-[rgba(249,249,249,0.3)] backdrop-blur-xl border border-white shadow-lg rounded-[17px] h-[124.455px] flex flex-col items-center justify-center relative cursor-pointer hover:bg-[rgba(249,249,249,0.5)] transition-all duration-200 active:scale-95" onClick={onHeartRateClick}>
            <Heart className="w-[18px] h-[18px] text-[#f58020] mb-[8px] absolute top-[14px]" strokeWidth={1.11395} />
            <p className="font-['Ninetea:Bold',sans-serif] text-[35.47px] text-[#130b3d] leading-[12.8px] mb-[8px] mt-[28px]">
              {biometrics.heartRate}
            </p>
            <p className="font-['Ninetea:Medium',sans-serif] text-[8.47px] text-[#130b3d] leading-[12.8px] mb-[4px]">
              BPM
            </p>
            <p className="font-['Ninetea:Semi_Bold',sans-serif] text-[12.473px] text-[#ef932d] leading-[12.8px] text-center">
              Frecuencia<br />Cardíaca
            </p>
          </div>

          {/* Sleep Quality */}
          <div className="flex-1 bg-[rgba(249,249,249,0.3)] backdrop-blur-xl border border-white shadow-lg rounded-[17px] h-[124.455px] flex flex-col items-center justify-center relative cursor-pointer hover:bg-[rgba(249,249,249,0.5)] transition-all duration-200 active:scale-95" onClick={onSleepClick}>
            <Moon className="w-[18px] h-[18px] text-[#f58020] mb-[8px] absolute top-[14px]" strokeWidth={1.11395} />
            <p className="font-['Ninetea:Bold',sans-serif] text-[35.47px] text-[#130b3d] leading-[12.8px] mb-[8px] mt-[28px]">
              {biometrics.sleepQuality}%
            </p>
            <p className="font-['Ninetea:Medium',sans-serif] text-[8.47px] text-[#130b3d] leading-[12.8px] mb-[4px]">
              {biometrics.sleepDuration} horas
            </p>
            <p className="font-['Ninetea:Semi_Bold',sans-serif] text-[12.473px] text-[#ef932d] leading-[12.8px] text-center">
              Calidad<br />del Sueño
            </p>
          </div>
        </div>
      </div>

      {/* Energy Level Bar */}
      <div className="px-[24px] mb-[15px]">
        <div className="relative h-[43px] rounded-[67px]">
          {/* Background */}
          <div className="absolute inset-0 bg-[rgba(249,249,249,0.3)] backdrop-blur-xl border border-white shadow-lg rounded-[67px]" />
          {/* Gradient fill - 85% width */}
          <div className="absolute left-0 top-0 bottom-0 w-[83%] bg-gradient-to-r from-[#2271b8] to-[#ef932d] rounded-[67px]" />
          {/* Content */}
          <div className="absolute inset-0 flex items-center justify-between px-[24px]">
            <span className="font-['Ninetea:Semi_Bold',sans-serif] text-[12.473px] text-[#fbeedc] leading-[17.818px]">
              Nivel De Energía
            </span>
            <span className="font-['Ninetea:Semi_Bold',sans-serif] text-[12.473px] text-[#fbeedc] leading-[17.818px]">
              85%
            </span>
          </div>
        </div>
      </div>

      {/* Insight del Día */}
      <div className="px-[24px] mb-[34px]">
        <div className="bg-[rgba(249,249,249,0.3)] backdrop-blur-xl border border-white shadow-lg rounded-[17px] p-[20px] relative">
          <div className="flex items-start justify-between mb-[12px]">
            <h3 className="font-['Ninetea:Semi_Bold',sans-serif] text-[22.47px] text-[#130b3d] leading-[12.8px]">
              Insight del Día
            </h3>
            <Flame className="w-[24px] h-[24px] text-[#130b3d]" strokeWidth={1.5} />
          </div>
          <p className="font-['Inter:Regular',sans-serif] text-[12.473px] text-[#130b3d] leading-[16.8px]">
            {cycleInfo.currentPhase === 'menstrual' && 
              'Durante tu período, es importante descansar y mantener una hidratación adecuada. Considera ejercicios de bajo impacto como yoga o caminatas suaves.'}
            {cycleInfo.currentPhase === 'follicular' && 
              'Tu energía está aumentando! Este es un gran momento para ejercicios de alta intensidad y para probar nuevas actividades físicas.'}
            {cycleInfo.currentPhase === 'ovulation' && 
              'Tu temperatura basal esta aumentando, lo que sugiere que te acercas a la ovulación. Excelente momento para ejercicios de alta intensidad y consumo de proteína magra.'}
            {cycleInfo.currentPhase === 'luteal' && 
              'Tu cuerpo se está preparando para el próximo ciclo. Considera actividades de intensidad moderada y asegúrate de mantener una dieta equilibrada.'}
          </p>
        </div>
      </div>

      {/* Home Indicator */}
      <div className="h-[34px] flex items-end justify-center pb-[7.67px]">
      </div>
    </div>
  );
}
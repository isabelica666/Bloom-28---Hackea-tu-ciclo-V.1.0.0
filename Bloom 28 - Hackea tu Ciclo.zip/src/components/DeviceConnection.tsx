import { motion } from 'motion/react';
import { Watch, Smartphone, Activity, Bluetooth, CheckCircle, AlertCircle, Dumbbell } from 'lucide-react';
import { useState } from 'react';

interface Device {
  id: string;
  name: string;
  type: string;
  connected: boolean;
  battery: number;
  lastSync: string;
  icon: any;
  brand: string;
}

interface FitnessApp {
  id: string;
  name: string;
  description: string;
  connected: boolean;
  lastSync?: string;
  icon: string;
  category: string;
}

export function DeviceConnection() {
  const [devices] = useState<Device[]>([
    {
      id: '1',
      name: 'Apple Watch Series 9',
      type: 'Smartwatch',
      connected: true,
      battery: 85,
      lastSync: 'Hace 5 min',
      icon: Watch,
      brand: 'Apple'
    },
    {
      id: '2',
      name: 'Oura Ring Gen 3',
      type: 'Smart Ring',
      connected: true,
      battery: 92,
      lastSync: 'Hace 10 min',
      icon: Activity,
      brand: 'Oura'
    },
    {
      id: '3',
      name: 'Fitbit Sense 2',
      type: 'Smartwatch',
      connected: false,
      battery: 45,
      lastSync: 'Hace 2 horas',
      icon: Watch,
      brand: 'Fitbit'
    }
  ]);

  const [fitnessApps] = useState<FitnessApp[]>([
    {
      id: '1',
      name: 'ClassPass',
      description: 'Clases de fitness y wellness',
      connected: true,
      lastSync: 'Hace 15 min',
      icon: '🧘‍♀️',
      category: 'Fitness'
    },
    {
      id: '2',
      name: 'Strava',
      description: 'Running y ciclismo',
      connected: true,
      lastSync: 'Hace 30 min',
      icon: '🏃‍♀️',
      category: 'Running'
    },
    {
      id: '3',
      name: 'Nike Training Club',
      description: 'Entrenamientos guiados',
      connected: false,
      icon: '👟',
      category: 'Fitness'
    },
    {
      id: '4',
      name: 'MyFitnessPal',
      description: 'Nutrición y calorías',
      connected: false,
      icon: '🍎',
      category: 'Nutrition'
    },
    {
      id: '5',
      name: 'Peloton',
      description: 'Ciclismo y entrenamientos',
      connected: false,
      icon: '🚴‍♀️',
      category: 'Fitness'
    },
    {
      id: '6',
      name: 'Google Fit',
      description: 'Actividad y salud',
      connected: false,
      icon: '💪',
      category: 'Health'
    },
    {
      id: '7',
      name: 'MapMyRun',
      description: 'Tracking de running',
      connected: false,
      icon: '🗺️',
      category: 'Running'
    }
  ]);

  const metrics = [
    { name: 'Temperatura Basal', source: 'Oura Ring', status: 'active' },
    { name: 'Frecuencia Cardíaca', source: 'Apple Watch', status: 'active' },
    { name: 'Calidad de Sueño', source: 'Oura Ring', status: 'active' },
    { name: 'Pasos', source: 'Apple Watch', status: 'active' },
    { name: 'Variabilidad FC', source: 'Apple Watch', status: 'active' }
  ];

  return (
    <div className="p-6 space-y-6 pb-24 bg-[#fbeedc] min-h-screen">
      <div>
        <h2 className="font-['Ninetea:Bold',sans-serif] mb-2 text-[#130b3d]">Dispositivos y Apps</h2>
        <p className="font-['Inter:Regular',sans-serif] text-[#5250a2] text-sm">Gestiona tus wearables y aplicaciones conectadas</p>
      </div>

      {/* Connected Devices */}
      <div>
        <h3 className="font-['Ninetea:Semi_Bold',sans-serif] mb-3 text-[#130b3d] text-sm">Dispositivos Wearables</h3>
        <div className="space-y-3">
          {devices.map((device, index) => (
            <motion.div
              key={device.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className={`bg-[rgba(255,255,255,0.5)] backdrop-blur-xl shadow-lg rounded-2xl p-5 border-2 ${
                device.connected ? 'border-[#2271b8]' : 'border-gray-200'
              }`}
            >
              <div className="flex items-start justify-between mb-3">
                <div className="flex items-start gap-3">
                  <div className={`p-3 rounded-xl ${
                    device.connected ? 'bg-gradient-to-br from-[#2271b8] to-[#5250a2]' : 'bg-gray-100'
                  }`}>
                    <device.icon className={`w-6 h-6 ${
                      device.connected ? 'text-white' : 'text-gray-400'
                    }`} />
                  </div>
                  <div>
                    <h4 className="font-['Inter:Bold',sans-serif] text-[#130b3d]">{device.name}</h4>
                    <p className="font-['Inter:Regular',sans-serif] text-sm text-[#5250a2]">{device.type}</p>
                  </div>
                </div>
                {device.connected ? (
                  <CheckCircle className="w-5 h-5 text-[#2271b8]" />
                ) : (
                  <AlertCircle className="w-5 h-5 text-gray-400" />
                )}
              </div>

              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4 text-sm">
                  <span className={`font-['Inter:Bold',sans-serif] ${
                    device.connected ? 'text-[#2271b8]' : 'text-gray-400'
                  } flex items-center gap-1`}>
                    <Bluetooth className="w-4 h-4" />
                    {device.connected ? 'Conectado' : 'Desconectado'}
                  </span>
                  <span className="font-['Inter:Regular',sans-serif] text-[#130b3d]">
                    🔋 {device.battery}%
                  </span>
                </div>
                <span className="font-['Inter:Regular',sans-serif] text-xs text-[#5250a2]">{device.lastSync}</span>
              </div>

              {!device.connected && (
                <button className="w-full mt-3 bg-gradient-to-r from-[#f58020] to-[#f5ebc3] text-[#130b3d] font-['Inter:Bold',sans-serif] py-2 rounded-xl hover:opacity-90 transition-opacity">
                  Conectar
                </button>
              )}
            </motion.div>
          ))}
        </div>
      </div>

      {/* Add Device Button */}
      <motion.button
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3 }}
        className="w-full bg-[rgba(255,255,255,0.5)] backdrop-blur-xl border border-white shadow-lg text-[#5250a2] font-['Inter:Bold',sans-serif] py-4 rounded-2xl border-2 border-dashed border-[#5250a2] hover:border-[#2271b8] transition-colors flex items-center justify-center gap-2"
      >
        <Smartphone className="w-5 h-5" />
        <span>Agregar Nuevo Dispositivo</span>
      </motion.button>

      {/* Fitness Apps */}
      <div>
        <h3 className="font-['Ninetea:Semi_Bold',sans-serif] mb-3 text-[#130b3d] text-sm">Apps de Ejercicio</h3>
        <div className="space-y-3">
          {fitnessApps.map((app, index) => (
            <motion.div
              key={app.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: (devices.length + index) * 0.1 }}
              className={`bg-[rgba(255,255,255,0.5)] backdrop-blur-xl shadow-lg rounded-2xl p-4 border-2 ${
                app.connected ? 'border-[#f58020]' : 'border-gray-200'
              }`}
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3 flex-1">
                  <div className={`text-3xl w-12 h-12 flex items-center justify-center rounded-xl ${
                    app.connected ? 'bg-gradient-to-br from-[#f58020] to-[#ef932d]' : 'bg-gray-100'
                  }`}>
                    {app.icon}
                  </div>
                  <div className="flex-1">
                    <h4 className="font-['Inter:Bold',sans-serif] text-[#130b3d]">{app.name}</h4>
                    <p className="font-['Inter:Regular',sans-serif] text-xs text-[#5250a2]">{app.description}</p>
                    {app.connected && app.lastSync && (
                      <p className="font-['Inter:Regular',sans-serif] text-xs text-[#2271b8] mt-1">
                        Sincronizado {app.lastSync}
                      </p>
                    )}
                  </div>
                </div>
                {app.connected ? (
                  <CheckCircle className="w-5 h-5 text-[#f58020] flex-shrink-0" />
                ) : (
                  <button className="bg-gradient-to-r from-[#f58020] to-[#ef932d] text-white font-['Inter:Bold',sans-serif] px-4 py-2 rounded-xl hover:opacity-90 transition-opacity text-sm flex-shrink-0">
                    Conectar
                  </button>
                )}
              </div>
            </motion.div>
          ))}
        </div>
      </div>

      {/* Metrics Being Tracked */}
      <div>
        <h3 className="font-['Ninetea:Bold',sans-serif] mb-3 text-[#130b3d]">Métricas Sincronizadas</h3>
        <div className="bg-[rgba(255,255,255,0.5)] backdrop-blur-xl border border-white shadow-lg rounded-2xl p-5">
          <div className="space-y-3">
            {metrics.map((metric, index) => (
              <div
                key={index}
                className="flex items-center justify-between py-2 border-b border-gray-100 last:border-0"
              >
                <div>
                  <p className="font-['Inter:Bold',sans-serif] text-[#130b3d]">{metric.name}</p>
                  <p className="font-['Inter:Regular',sans-serif] text-xs text-[#5250a2]">{metric.source}</p>
                </div>
                <div className="w-2 h-2 rounded-full bg-[#2271b8] animate-pulse"></div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Sync Status */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
        className="bg-gradient-to-r from-[rgba(34,113,184,0.9)] to-[rgba(82,80,162,0.9)] backdrop-blur-xl border border-white shadow-lg rounded-2xl p-5"
      >
        <div className="flex items-center justify-between mb-3">
          <h4 className="font-['Ninetea:Bold',sans-serif] text-white">Estado de Sincronización</h4>
          <span className="font-['Inter:Bold',sans-serif] text-xs bg-[#f58020] text-white px-3 py-1 rounded-full">
            Activo
          </span>
        </div>
        <div className="space-y-2 text-sm text-[#fbeedc]">
          <p className="font-['Inter:Regular',sans-serif]">• Última sincronización: Hace 5 minutos</p>
          <p className="font-['Inter:Regular',sans-serif]">• Próxima sincronización automática: En 25 minutos</p>
          <p className="font-['Inter:Regular',sans-serif]">• Datos sincronizados hoy: 1,247 puntos</p>
        </div>
        <button className="w-full mt-4 bg-[#f58020] text-white font-['Inter:Bold',sans-serif] py-2 rounded-xl hover:opacity-90 transition-opacity">
          Sincronizar Ahora
        </button>
      </motion.div>
    </div>
  );
}
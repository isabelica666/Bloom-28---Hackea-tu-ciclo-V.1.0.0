import { useState } from 'react';
import { Splash } from './Splash';
import { Welcome } from './Welcome';
import { Login } from './Login';
import { Register } from './Register';
import { TermsAndConditions } from './TermsAndConditions';
import { ProfileSetupName } from './ProfileSetupName';
import { ProfileSetupPeriod } from './ProfileSetupPeriod';
import { ProfileSetupWeight } from './ProfileSetupWeight';
import { ProfileSetupHeight } from './ProfileSetupHeight';
import { ProfileSetupWearable } from './ProfileSetupWearable';
import { ProfileSetupWearableLoading } from './ProfileSetupWearableLoading';
import { ProfileSetupWearableSuccess } from './ProfileSetupWearableSuccess';
import type { CycleData } from '../utils/cycleCalculations';

type OnboardingScreen =
  | 'splash'
  | 'welcome'
  | 'login'
  | 'register'
  | 'terms'
  | 'profileName'
  | 'profilePeriod'
  | 'profileWeight'
  | 'profileHeight'
  | 'profileWearable'
  | 'profileWearableLoading'
  | 'profileWearableSuccess';

interface OnboardingProps {
  onContinue: (name: string, cycleData: CycleData) => void;
}

export function Onboarding({ onContinue }: OnboardingProps) {
  const [currentScreen, setCurrentScreen] = useState<OnboardingScreen>('splash');
  const [previousScreen, setPreviousScreen] = useState<OnboardingScreen>('welcome');
  const [userName, setUserName] = useState('');
  const [cycleData, setCycleData] = useState<{
    lastPeriodDate: string;
    cycleDuration: number;
    periodDuration: number;
  }>({
    lastPeriodDate: '',
    cycleDuration: 28,
    periodDuration: 5,
  });

  const handleSplashComplete = () => {
    setCurrentScreen('welcome');
  };

  const handleLogin = () => {
    setCurrentScreen('login');
  };

  const handleRegister = () => {
    setCurrentScreen('register');
  };

  const handleLoginSubmit = () => {
    // For now, skip to profile setup
    setCurrentScreen('profileName');
  };

  const handleRegisterSubmit = () => {
    setCurrentScreen('profileName');
  };

  const handleNameContinue = (name: string) => {
    setUserName(name);
    setCurrentScreen('profilePeriod');
  };

  const handlePeriodContinue = (data: { lastPeriodDate: string; cycleDuration: number; periodDuration: number }) => {
    setCycleData(data);
    setCurrentScreen('profileWeight');
  };

  const handleWeightContinue = () => {
    setCurrentScreen('profileHeight');
  };

  const handleHeightContinue = () => {
    setCurrentScreen('profileWearable');
  };

  const handleWearableContinue = () => {
    setCurrentScreen('profileWearableLoading');
  };

  const handleWearableLoadingComplete = () => {
    setCurrentScreen('profileWearableSuccess');
  };

  const handleWearableSuccessContinue = () => {
    // Complete onboarding with cycle data
    const completeCycleData: CycleData = {
      lastPeriodDate: cycleData.lastPeriodDate,
      cycleDuration: cycleData.cycleDuration,
      periodDuration: cycleData.periodDuration,
    };
    onContinue(userName, completeCycleData);
  };

  const handleShowTerms = () => {
    setPreviousScreen(currentScreen);
    setCurrentScreen('terms');
  };

  const handleBackFromTerms = () => {
    setCurrentScreen(previousScreen);
  };

  const handleBackToWelcome = () => {
    setCurrentScreen('welcome');
  };

  const handleBackToPeriod = () => {
    setCurrentScreen('profilePeriod');
  };

  const handleBackToWeight = () => {
    setCurrentScreen('profileWeight');
  };

  const handleBackToHeight = () => {
    setCurrentScreen('profileHeight');
  };

  switch (currentScreen) {
    case 'splash':
      return <Splash onComplete={handleSplashComplete} />;
    case 'welcome':
      return <Welcome onLogin={handleLogin} onRegister={handleRegister} />;
    case 'login':
      return <Login onLogin={handleLoginSubmit} onBack={handleBackToWelcome} onGoToRegister={handleRegister} onShowTerms={handleShowTerms} />;
    case 'register':
      return <Register onContinue={handleRegisterSubmit} onBack={handleBackToWelcome} onGoToLogin={handleLogin} onShowTerms={handleShowTerms} />;
    case 'terms':
      return <TermsAndConditions onBack={handleBackFromTerms} />;
    case 'profileName':
      return <ProfileSetupName onContinue={handleNameContinue} onBack={handleBackToWelcome} />;
    case 'profilePeriod':
      return (
        <ProfileSetupPeriod
          onContinue={handlePeriodContinue}
          onBack={handleBackToWelcome}
        />
      );
    case 'profileWeight':
      return <ProfileSetupWeight onContinue={handleWeightContinue} onBack={handleBackToPeriod} />;
    case 'profileHeight':
      return <ProfileSetupHeight onContinue={handleHeightContinue} onBack={handleBackToWeight} />;
    case 'profileWearable':
      return <ProfileSetupWearable onContinue={handleWearableContinue} onBack={handleBackToHeight} />;
    case 'profileWearableLoading':
      return <ProfileSetupWearableLoading onComplete={handleWearableLoadingComplete} />;
    case 'profileWearableSuccess':
      return <ProfileSetupWearableSuccess onContinue={handleWearableSuccessContinue} />;
    default:
      return <Splash onComplete={handleSplashComplete} />;
  }
}
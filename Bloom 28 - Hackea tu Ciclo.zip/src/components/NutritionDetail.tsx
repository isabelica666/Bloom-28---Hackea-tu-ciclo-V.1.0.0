import { motion } from 'motion/react';
import { ArrowLeft, Sparkles, Heart, CheckCircle2, Lightbulb, LucideIcon } from 'lucide-react';

interface NutritionItem {
  food: string;
  reason: string;
  icon: LucideIcon;
  color: string;
}

interface NutritionDetailProps {
  item: NutritionItem;
  phase: string;
  onBack: () => void;
}

// Información detallada por alimento
const nutritionDetails: Record<string, {
  why: string;
  benefits: string[];
  howToEnjoy: string[];
  scientificNote: string;
}> = {
  'Alimentos ricos en hierro': {
    why: 'Durante la menstruación, pierdes sangre y con ella hierro, un mineral esencial para transportar oxígeno en tu cuerpo. La pérdida promedio es de 30-40mg de hierro por período. Reponer estas reservas previene la anemia ferropénica, que causa fatiga extrema, mareos y dificultad para concentrarte.',
    benefits: [
      'Previene la anemia y la fatiga extrema post-menstrual',
      'Mejora la concentración y claridad mental durante el período',
      'Aumenta los niveles de energía y reduce la sensación de debilidad',
      'Fortalece el sistema inmunológico comprometido durante la menstruación',
      'Mejora la calidad del sueño y reduce el cansancio crónico'
    ],
    howToEnjoy: [
      '🥩 Combina carne roja magra con brócoli para aumentar 3x la absorción de hierro',
      '🍋 Añade jugo de limón o naranja a tus espinacas - la vitamina C potencia la absorción',
      '🍲 Prepara lentejas en curry con tomate y pimientos para una comida rica en hierro',
      '☕ Evita tomar café o té junto con comidas ricas en hierro - reducen absorción hasta 60%',
      '🥗 Combina espinacas con fresas en una ensalada para hierro + vitamina C'
    ],
    scientificNote: 'El hierro hemo (de origen animal) se absorbe 2-3 veces mejor que el hierro no-hemo (vegetales). Si eres vegetariana, consume el doble de alimentos ricos en hierro junto con vitamina C para compensar.'
  },
  'Omega-3': {
    why: 'Los ácidos grasos Omega-3 (EPA y DHA) son antiinflamatorios naturales que reducen la producción de prostaglandinas, las sustancias químicas responsables de los cólicos menstruales. También estabilizan el estado de ánimo al apoyar la función de serotonina en el cerebro.',
    benefits: [
      'Reduce significativamente los cólicos y dolor menstrual (hasta 40%)',
      'Disminuye la inflamación sistémica y el sangrado abundante',
      'Mejora el estado de ánimo y reduce síntomas depresivos del SPM',
      'Protege la salud cardiovascular durante cambios hormonales',
      'Reduce la sensibilidad en los senos y la hinchazón',
      'Mejora la calidad de la piel propensa a brotes durante el período'
    ],
    howToEnjoy: [
      '🐟 Salmón al horno con hierbas y limón - 2-3 veces por semana',
      '🥜 Añade 2 cucharadas de nueces picadas a tu yogurt o avena matutina',
      '🥤 Smoothie con semillas de chía remojadas, frutos rojos y leche de almendras',
      '🥗 Ensalada de atún con aguacate, perfecta para el almuerzo',
      '🍪 Barritas energéticas caseras con semillas de chía, nueces y dátiles',
      '💊 Si no consumes pescado, considera suplementos de Omega-3 (1000-2000mg/día)'
    ],
    scientificNote: 'Estudios muestran que mujeres que consumen 2g de Omega-3 diariamente reducen su dolor menstrual en un 50% después de 3 ciclos. Los efectos son acumulativos, así que mantén el consumo constante.'
  },
  'Magnesio': {
    why: 'El magnesio es un mineral calmante que relaja los músculos uterinos, reduciendo los calambres. También regula los neurotransmisores que afectan el estado de ánimo. Los niveles de magnesio naturalmente bajan durante la menstruación, agravando los síntomas de SPM.',
    benefits: [
      'Reduce calambres uterinos y dolor muscular hasta en 45%',
      'Alivia dolores de cabeza y migrañas menstruales',
      'Mejora la calidad del sueño y reduce el insomnio pre-menstrual',
      'Reduce la ansiedad, irritabilidad y cambios de humor',
      'Disminuye los antojos de azúcar y chocolate (aunque el chocolate oscuro es bueno)',
      'Combate la fatiga y aumenta los niveles de energía'
    ],
    howToEnjoy: [
      '🍫 30-40g de chocolate oscuro (70%+ cacao) diariamente - ¡disfrutalo sin culpa!',
      '🍌 Plátano con mantequilla de almendras como snack energético',
      '🥑 Aguacate en tostadas o ensaladas - también aporta grasas saludables',
      '🌰 Mix de frutos secos: almendras, anacardos y semillas de calabaza',
      '🍵 Té caliente con plátano antes de dormir para mejor descanso',
      '🧂 Baño con sales de Epsom (magnesio) - se absorbe por la piel y relaja'
    ],
    scientificNote: 'La dosis recomendada es 310-320mg/día para mujeres adultas. Durante la menstruación, las necesidades pueden aumentar hasta 400mg. El magnesio funciona mejor cuando se combina con vitamina B6.'
  },
  'Vitamina C': {
    why: 'La vitamina C es esencial durante la menstruación porque fortalece los capilares sanguíneos, reduciendo el sangrado abundante. También potencia la absorción de hierro hasta 3 veces y fortalece tu sistema inmunológico que se debilita durante el período.',
    benefits: [
      'Reduce el sangrado menstrual abundante y prolongado',
      'Triplica la absorción de hierro de alimentos vegetales',
      'Fortalece el sistema inmunológico debilitado durante la menstruación',
      'Potente antioxidante que combate la inflamación',
      'Mejora la síntesis de colágeno para piel, cabello y uñas',
      'Reduce el estrés oxidativo causado por cambios hormonales'
    ],
    howToEnjoy: [
      '🍊 Jugo de naranja fresco en el desayuno (recién exprimido es mejor)',
      '🍓 Bowl de fresas con yogurt griego y granola',
      '🥝 Smoothie verde: kiwi, espinacas, piña y jengibre',
      '🫑 Pimientos rojos crudos con hummus - más vitamina C que las naranjas',
      '🥗 Ensalada de espinacas con fresas, nueces y vinagreta de limón',
      '🍋 Agua tibia con limón al despertar para activar el metabolismo'
    ],
    scientificNote: 'La vitamina C se degrada con el calor. Consume frutas crudas o cocina las verduras al vapor brevemente. Una naranja mediana aporta 70mg de vitamina C, suficiente para potenciar la absorción de hierro en esa comida.'
  },
  'Proteínas magras': {
    why: 'En la fase folicular, tu metabolismo se acelera y tu cuerpo está construyendo masa muscular más eficientemente gracias al estrógeno creciente. Las proteínas magras proporcionan aminoácidos esenciales para reparación muscular sin exceso de grasas saturadas que podrían causar inflamación.',
    benefits: [
      'Construcción muscular óptima - aprovecha el efecto anabólico del estrógeno',
      'Mantiene la saciedad por más tiempo, controlando el apetito',
      'Estabiliza los niveles de azúcar en sangre y reduce antojos',
      'Mejora la recuperación post-entrenamiento en tu fase de máximo rendimiento',
      'Apoya la síntesis de neurotransmisores para mejor estado de ánimo',
      'Fortalece el sistema inmunológico y acelera la curación'
    ],
    howToEnjoy: [
      '🍗 Pechuga de pollo a la plancha con especias y limón',
      '🦃 Pavo molido en tacos saludables con aguacate y vegetales',
      '🧊 Tofu firme marinado en salsa de soja y jengibre, salteado con vegetales',
      '🥚 Claras de huevo revueltas con espinacas y tomate',
      '🐟 Pescado blanco (tilapia, bacalao) al horno con hierbas',
      '🥤 Batido proteico post-entrenamiento con proteína whey o vegetal'
    ],
    scientificNote: 'Durante la fase folicular, tu sensibilidad a la insulina mejora, permitiendo mejor utilización de proteínas para construcción muscular. Consume 1.6-2g de proteína por kg de peso corporal si entrenas regularmente.'
  },
  'Carbohidratos complejos': {
    why: 'Los carbohidratos complejos se digieren lentamente, proporcionando energía sostenida para tus entrenamientos intensos en la fase folicular. También aumentan la serotonina cerebral, mejorando tu estado de ánimo. El estrógeno alto mejora tu capacidad de usar carbohidratos como energía.',
    benefits: [
      'Energía sostenida para entrenamientos de alta intensidad',
      'Previene picos y caídas de azúcar en sangre',
      'Aumenta la serotonina, mejorando el humor y reduciendo ansiedad',
      'Fibra que mejora la digestión y salud intestinal',
      'Apoya la función tiroidea y metabolismo acelerado',
      'Mejor recuperación muscular post-ejercicio'
    ],
    howToEnjoy: [
      '🥣 Bowl de avena con frutos rojos, nueces y canela',
      '🍚 Arroz integral con vegetales salteados y proteína magra',
      '🥗 Ensalada de quinoa con aguacate, garbanzos y vegetales asados',
      '🍠 Batata horneada como acompañamiento pre-entrenamiento',
      '🍝 Pasta de trigo integral con salsa de tomate casera y albahaca',
      '🥖 Pan integral con mantequilla de almendras y plátano'
    ],
    scientificNote: 'Durante la fase folicular, tu sensibilidad a la insulina es óptima, permitiendo mejor utilización de carbohidratos. Este es el momento de consumir 45-55% de tus calorías de carbohidratos para maximizar energía.'
  },
  'Verduras crucíferas': {
    why: 'Las verduras crucíferas contienen indol-3-carbinol (I3C) y DIM, compuestos que ayudan a metabolizar y eliminar el exceso de estrógeno del cuerpo. Esto es crucial en la fase folicular cuando el estrógeno está aumentando, para mantener un balance hormonal saludable.',
    benefits: [
      'Ayuda al hígado a metabolizar y eliminar exceso de estrógeno',
      'Reduce el riesgo de dominancia estrogénica y síntomas de SPM',
      'Potentes antioxidantes que combaten el estrés oxidativo',
      'Fibra que mejora la eliminación de hormonas vía intestino',
      'Apoya la desintoxicación hepática natural',
      'Puede reducir el riesgo de cánceres hormonales'
    ],
    howToEnjoy: [
      '🥦 Brócoli al vapor con ajo y aceite de oliva - no sobrecocinar',
      '🥗 Ensalada de col kale con aguacate, limón y semillas',
      '🥬 Coles de Bruselas asadas con balsámico y nueces',
      '🥘 Coliflor gratinada o en "arroz" de coliflor',
      '🌮 Col lombarda fermentada (chucrut) - probióticos adicionales',
      '🥤 Smoothie verde con kale, piña, jengibre y manzana verde'
    ],
    scientificNote: 'No comas crucíferas crudas en exceso si tienes problemas tiroideos - los goitrógenos pueden interferir. Cocinarlas ligeramente desactiva estos compuestos mientras mantiene los beneficios de I3C.'
  },
  'Probióticos': {
    why: 'Un microbioma intestinal saludable es crucial para metabolizar y eliminar el exceso de estrógeno. Los probióticos también producen neurotransmisores como serotonina (90% se produce en el intestino), mejorando tu estado de ánimo durante la fase folicular de alta energía.',
    benefits: [
      'Mejora la digestión y reduce hinchazón abdominal',
      'Apoya la eliminación de exceso de estrógeno metabolizado',
      'Fortalece el sistema inmunológico (70% está en el intestino)',
      'Produce neurotransmisores que mejoran el estado de ánimo',
      'Reduce la inflamación sistémica',
      'Mejora la absorción de nutrientes esenciales'
    ],
    howToEnjoy: [
      '🥛 Yogurt griego natural con miel y frutos rojos',
      '🥤 Kéfir en smoothies o solo, como bebida refrescante',
      '🥬 Kimchi o chucrut como acompañamiento (fermentados)',
      '🍵 Kombucha como bebida energizante saludable',
      '🧀 Quesos fermentados como gouda, cheddar envejecido',
      '💊 Suplemento probiótico con 10-50 billones de CFUs si es necesario'
    ],
    scientificNote: 'Busca yogurt con "cultivos vivos activos" en la etiqueta. Los mejores probióticos contienen múltiples cepas: Lactobacillus y Bifidobacterium son esenciales para la salud hormonal femenina.'
  },
  'Antioxidantes': {
    why: 'Durante la ovulación, tu cuerpo experimenta un aumento de estrés oxidativo debido al pico hormonal. Los antioxidantes protegen el óvulo liberado y mejoran la calidad de tus células. También reducen la inflamación que puede causar dolor durante la ovulación (mittelschmerz).',
    benefits: [
      'Protege las células del óvulo de daño oxidativo',
      'Reduce la inflamación y el dolor de ovulación',
      'Apoya la salud cardiovascular en momentos de picos hormonales',
      'Mejora la salud de la piel y reduce el acné hormonal',
      'Fortalece el sistema inmunológico',
      'Protege contra el envejecimiento celular prematuro'
    ],
    howToEnjoy: [
      '🫐 Bowl de açaí con granola, plátano y bayas mixtas',
      '🍇 Uvas rojas o moradas como snack - alta en resveratrol',
      '🥤 Smoothie de bayas mixtas con semillas de chía y espinacas',
      '🥗 Ensalada con granada, nueces y rúcula',
      '🍵 Té verde matcha o té de hibisco - super antioxidantes',
      '🍫 Chocolate oscuro (85%+) con frutos secos'
    ],
    scientificNote: 'Las bayas oscuras (arándanos, moras, açaí) tienen el mayor contenido de antioxidantes. El valor ORAC (capacidad de absorción de radicales de oxígeno) de los arándanos es 9,621 por porción.'
  },
  'Fibra': {
    why: 'La fibra soluble se une al exceso de estrógeno en el intestino y lo elimina del cuerpo. Durante la ovulación, cuando el estrógeno está en su pico máximo, la fibra ayuda a prevenir la recirculación de estas hormonas, manteniendo un balance hormonal óptimo.',
    benefits: [
      'Elimina el exceso de estrógeno del cuerpo vía intestino',
      'Estabiliza los niveles de azúcar en sangre y reduce antojos',
      'Mantiene saciedad prolongada, controlando el apetito',
      'Mejora la salud digestiva y movimientos intestinales regulares',
      'Alimenta las bacterias intestinales beneficiosas',
      'Reduce el colesterol y protege la salud cardiovascular'
    ],
    howToEnjoy: [
      '🥄 2 cucharadas de semillas de lino molidas en smoothies o yogurt',
      '🥤 Pudín de chía: remoja semillas en leche con cacao overnight',
      '🥣 Avena con semillas de lino y frutos rojos',
      '🍞 Pan integral con semillas de lino, chía y calabaza',
      '🥗 Ensalada con semillas de lino tostadas como topping crujiente',
      '💧 Aumenta agua cuando consumas fibra - necesaria para que funcione'
    ],
    scientificNote: 'Consume 25-35g de fibra diariamente. Las semillas de lino deben molerse para absorber sus beneficios - las semillas enteras pasan sin digerir. Refrigera las semillas molidas para preservar los omega-3.'
  },
  'Calcio': {
    why: 'El calcio no solo es crucial para la salud ósea, sino que también regula las contracciones musculares y la transmisión nerviosa. Durante la ovulación, el calcio ayuda a reducir los síntomas de SPM que pueden comenzar a aparecer, especialmente cambios de humor y antojos.',
    benefits: [
      'Reduce significativamente los síntomas de SPM (hasta 48%)',
      'Mejora el estado de ánimo y reduce irritabilidad',
      'Disminuye los antojos de alimentos, especialmente dulces',
      'Apoya la salud ósea crucial en edad reproductiva',
      'Regula la contracción muscular y reduce calambres',
      'Mejora la calidad del sueño'
    ],
    howToEnjoy: [
      '🥛 Leche o bebida vegetal fortificada (almendras, soja)',
      '🧀 Queso bajo en grasa con frutas como snack',
      '🥗 Yogurt griego con almendras y miel',
      '🥦 Brócoli y col kale - fuentes vegetales de calcio',
      '🐟 Sardinas enlatadas (con huesos) en ensaladas',
      '🥤 Smoothie con leche, semillas de sésamo y espinacas'
    ],
    scientificNote: 'Necesitas 1000mg de calcio diariamente. La vitamina D es esencial para absorber calcio - toma sol 15 min diarios o suplementa con vitamina D3. El calcio funciona mejor con magnesio (ratio 2:1).'
  },
  'Zinc': {
    why: 'El zinc es esencial para la ovulación saludable y el equilibrio hormonal. Ayuda a regular la producción de progesterona después de la ovulación. También fortalece el sistema inmunológico que puede debilitarse ligeramente durante los cambios hormonales de la ovulación.',
    benefits: [
      'Apoya la ovulación saludable y fertilidad',
      'Regula la producción de progesterona post-ovulación',
      'Reduce el acné hormonal y mejora la salud de la piel',
      'Fortalece el sistema inmunológico',
      'Mejora la cicatrización y reparación celular',
      'Apoya la función tiroidea y metabolismo'
    ],
    howToEnjoy: [
      '🦪 Ostras - la fuente más rica de zinc (si te gustan)',
      '🥩 Carne roja magra 2-3 veces por semana',
      '🫘 Garbanzos tostados como snack crujiente',
      '🌰 Semillas de calabaza tostadas con especias',
      '🦐 Camarones o langostinos en ensaladas o tacos',
      '💊 Suplemento de zinc (15-30mg) si eres vegetariana'
    ],
    scientificNote: 'Las necesidades de zinc son 8mg/día para mujeres. El zinc de fuentes animales se absorbe mejor (40%) que de fuentes vegetales (15%). Si eres vegetariana, consume 50% más zinc para compensar.'
  },
  'Vitamina B6': {
    why: 'La vitamina B6 es esencial en la fase lútea porque ayuda a producir serotonina y dopamina, neurotransmisores que previenen la depresión y cambios de humor del SPM. También ayuda al hígado a metabolizar el exceso de estrógeno y reduce la retención de líquidos.',
    benefits: [
      'Reduce dramáticamente los síntomas emocionales del SPM',
      'Disminuye la retención de líquidos y la hinchazón',
      'Mejora el estado de ánimo y reduce la irritabilidad',
      'Alivia las náuseas y malestar estomacal pre-menstrual',
      'Reduce los dolores de cabeza hormonales',
      'Apoya la producción de progesterona'
    ],
    howToEnjoy: [
      '🐟 Atún a la plancha o en conserva (en agua) con ensalada',
      '🥔 Garbanzos en hummus, curry o asados',
      '🍌 Plátano con mantequilla de maní como snack energético',
      '🍗 Pechuga de pollo al horno con hierbas',
      '🥔 Papas horneadas (con piel) como acompañamiento',
      '🥜 Mix de pistachos, nueces y semillas de girasol'
    ],
    scientificNote: 'La dosis efectiva para SPM es 50-100mg de B6 diariamente. Dosis superiores a 200mg/día pueden causar toxicidad. Funciona mejor cuando se combina con magnesio para alivio de síntomas de SPM.'
  },
  'Calcio y Magnesio': {
    why: 'Esta combinación es especialmente poderosa en la fase lútea. El calcio reduce los cambios de humor y antojos, mientras que el magnesio relaja los músculos y previene calambres. Juntos, pueden reducir hasta 50% de los síntomas de SPM.',
    benefits: [
      'Reducción dramática de todos los síntomas de SPM (50%+)',
      'Alivia calambres, hinchazón y sensibilidad en senos',
      'Mejora significativamente el estado de ánimo',
      'Reduce los antojos de azúcar y chocolate',
      'Mejora la calidad del sueño pre-menstrual',
      'Disminuye dolores de cabeza y migrañas'
    ],
    howToEnjoy: [
      '🥛 Leche tibia con miel antes de dormir',
      '🧀 Yogurt griego con almendras y semillas de calabaza',
      '🥦 Brócoli al vapor con queso - combo perfecto',
      '🐟 Salmón (omega-3) con espinacas (magnesio) al limón',
      '🥗 Ensalada de col kale con queso feta y semillas',
      '💊 Suplemento de Ca/Mg (ratio 2:1) si es necesario'
    ],
    scientificNote: 'El ratio ideal es 2:1 (calcio:magnesio). Consume 1000mg de calcio y 400-500mg de magnesio diariamente durante la fase lútea. Evita tomar con café - reduce la absorción de ambos minerales.'
  },
  'Carbohidratos saludables': {
    why: 'En la fase lútea, la progesterona aumenta tu metabolismo basal en ~300 calorías/día, aumentando el hambre. Los carbohidratos complejos proporcionan energía sostenida y aumentan la serotonina, contrarrestando los síntomas depresivos del SPM sin causar picos de azúcar.',
    benefits: [
      'Satisface el aumento del apetito de forma saludable',
      'Aumenta la serotonina cerebral, mejorando el humor',
      'Proporciona energía sostenida sin crashes de azúcar',
      'Reduce los antojos intensos de dulces',
      'Apoya el metabolismo acelerado por progesterona',
      'Mejora la calidad del sueño pre-menstrual'
    ],
    howToEnjoy: [
      '🍠 Batata horneada con canela y un toque de miel',
      '🎃 Sopa cremosa de calabaza con jengibre y coco',
      '🥔 Puré de batata con un toque de mantequilla y nuez moscada',
      '🍱 Bowl con batata asada, quinoa, aguacate y proteína',
      '🥧 Batata horneada rellena de frijoles negros y vegetales',
      '🍰 Brownies saludables de batata y chocolate oscuro'
    ],
    scientificNote: 'Las batatas y calabazas tienen bajo índice glucémico (IG 44-54) a pesar de ser dulces, liberando azúcar lentamente. También son ricas en vitamina A (14000 IU por batata), apoyando la salud hormonal.'
  },
  'Evitar sal excesiva': {
    why: 'La progesterona alta en la fase lútea causa retención de líquidos natural. El exceso de sodio empeora significativamente esta retención, causando hinchazón severa, aumento de peso temporal, presión arterial elevada y mayor sensibilidad en los senos.',
    benefits: [
      'Reduce dramáticamente la hinchazón y retención de líquidos',
      'Disminuye la sensibilidad e hinchazón de los senos',
      'Previene el aumento de peso temporal por agua',
      'Reduce la presión arterial que puede elevarse pre-menstrualmente',
      'Mejora la sensación de ligereza y comodidad',
      'Disminuye los dolores de cabeza por retención de líquidos'
    ],
    howToEnjoy: [
      '🌿 Usa hierbas frescas y especias en lugar de sal para dar sabor',
      '🍋 Limón, vinagre balsámico y ajo para realzar sabores naturalmente',
      '🥗 Come alimentos frescos en lugar de procesados (bajos en sodio)',
      '🥤 Aumenta el consumo de agua - ayuda a eliminar el exceso de sodio',
      '🍌 Come alimentos ricos en potasio (plátanos, aguacate) - contrarresta el sodio',
      '🚫 Evita: comida rápida, snacks salados, alimentos enlatados, embutidos'
    ],
    scientificNote: 'Limita el sodio a <1500mg/día en la fase lútea (vs. 2300mg normal). Solo 1 cucharadita de sal tiene 2300mg de sodio. Los alimentos procesados contienen 75% del sodio en nuestra dieta.'
  }
};

export function NutritionDetail({ item, phase, onBack }: NutritionDetailProps) {
  const IconComponent = item.icon;
  const details = nutritionDetails[item.food] || {
    why: 'Información no disponible',
    benefits: [],
    howToEnjoy: [],
    scientificNote: ''
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#ffe0c6] to-[#f5ebc3] pb-6">
      {/* Header */}
      <div className="sticky top-0 z-10 bg-gradient-to-b from-[#ffe0c6] to-transparent backdrop-blur-sm pb-4">
        <div className="flex items-center justify-between px-6 pt-6 pb-2">
          <button
            onClick={onBack}
            className="p-2 hover:bg-[rgba(252,239,221,0.5)] rounded-full transition-colors"
          >
            <ArrowLeft className="w-6 h-6 text-[#130b3d]" />
          </button>
          <h1 className="font-['Ninetea:Bold',sans-serif] text-[20px] text-[#130b3d] text-center flex-1 mr-10">
            {item.food}
          </h1>
        </div>
      </div>

      <div className="px-6 space-y-6">
        {/* Food Icon Card */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="bg-[rgba(252,239,221,0.5)] backdrop-blur-xl border border-white shadow-lg rounded-3xl p-8"
        >
          <div className="flex flex-col items-center">
            <div className={`p-6 rounded-3xl bg-gradient-to-r ${item.color} mb-4`}>
              <IconComponent className="w-16 h-16 text-white" strokeWidth={1.5} />
            </div>
            <p className="font-['Inter:Regular',sans-serif] text-sm text-[#5250a2] text-center">
              {item.reason}
            </p>
          </div>
        </motion.div>

        {/* Why Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="bg-[rgba(252,239,221,0.5)] backdrop-blur-xl border border-white shadow-lg rounded-3xl p-6"
        >
          <div className="flex items-center gap-2 mb-4">
            <Sparkles className="w-6 h-6 text-[#2271b8]" />
            <h3 className="font-['Ninetea:Bold',sans-serif] text-[#130b3d] text-[18px]">
              ¿Por qué es importante?
            </h3>
          </div>
          <p className="font-['Inter:Regular',sans-serif] text-[15px] text-[#130b3d] leading-relaxed">
            {details.why}
          </p>
        </motion.div>

        {/* Health Benefits */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="bg-[rgba(252,239,221,0.5)] backdrop-blur-xl border border-white shadow-lg rounded-3xl p-6"
        >
          <div className="flex items-center gap-2 mb-4">
            <Heart className="w-6 h-6 text-[#ea4c89]" />
            <h3 className="font-['Ninetea:Bold',sans-serif] text-[#130b3d] text-[18px]">
              Beneficios para tu salud
            </h3>
          </div>
          <div className="space-y-3">
            {details.benefits.map((benefit, index) => (
              <div key={index} className="flex items-start gap-3">
                <CheckCircle2 className="w-5 h-5 text-[#2271b8] mt-0.5 flex-shrink-0" />
                <p className="font-['Inter:Regular',sans-serif] text-[15px] text-[#130b3d] leading-relaxed flex-1">
                  {benefit}
                </p>
              </div>
            ))}
          </div>
        </motion.div>

        {/* How to Enjoy */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="bg-gradient-to-br from-[rgba(245,128,32,0.5)] to-[rgba(245,235,195,0.5)] backdrop-blur-xl border border-white shadow-lg rounded-3xl p-6"
        >
          <div className="flex items-center gap-2 mb-4">
            <Lightbulb className="w-6 h-6 text-[#f58020]" />
            <h3 className="font-['Ninetea:Bold',sans-serif] text-[#130b3d] text-[18px]">
              Cómo disfrutarlo
            </h3>
          </div>
          <div className="space-y-3">
            {details.howToEnjoy.map((tip, index) => (
              <div key={index} className="flex items-start gap-3">
                <div className="w-2 h-2 rounded-full bg-[#f58020] mt-2 flex-shrink-0"></div>
                <p className="font-['Inter:Regular',sans-serif] text-[15px] text-[#130b3d] leading-relaxed flex-1">
                  {tip}
                </p>
              </div>
            ))}
          </div>
        </motion.div>

        {/* Scientific Note */}
        {details.scientificNote && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            className="bg-[rgba(34,113,184,0.15)] backdrop-blur-xl border border-[#2271b8] shadow-lg rounded-3xl p-6"
          >
            <div className="flex items-start gap-3">
              <div className="p-2 bg-[#2271b8] rounded-xl">
                <Sparkles className="w-5 h-5 text-white" />
              </div>
              <div className="flex-1">
                <h4 className="font-['Inter:Bold',sans-serif] text-[#2271b8] mb-2 text-[15px]">
                  💡 Nota científica
                </h4>
                <p className="font-['Inter:Regular',sans-serif] text-[14px] text-[#130b3d] leading-relaxed">
                  {details.scientificNote}
                </p>
              </div>
            </div>
          </motion.div>
        )}
      </div>
    </div>
  );
}

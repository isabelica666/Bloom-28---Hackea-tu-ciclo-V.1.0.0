import { Calendar, ArrowLeft } from 'lucide-react';
import { useState } from 'react';

interface ProfileSetupNameProps {
  onContinue: (name: string) => void;
  onBack: () => void;
}

export function ProfileSetupName({ onContinue, onBack }: ProfileSetupNameProps) {
  const [name, setName] = useState('');

  const handleContinue = () => {
    if (name.trim()) {
      onContinue(name.trim());
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#ffe0c6] to-[#f5ebc3] relative">
      {/* Status bar placeholder */}
      <div className="h-12" />

      {/* Back button */}
      <div className="px-6 py-4">
        <button
          onClick={onBack}
          className="flex items-center justify-center w-10 h-10 rounded-xl bg-[rgba(255,255,255,0.5)] backdrop-blur-xl border border-white shadow-lg"
        >
          <ArrowLeft className="w-5 h-5 text-[#130b3d]" />
        </button>
      </div>

      {/* Progress indicators */}
      <div className="flex gap-[7px] justify-center mb-20">
        <div className="h-[5px] w-[47px] bg-[#f58020] rounded-full" />
        <div className="h-[5px] w-[47px] bg-[#fbeedc] rounded-full" />
        <div className="h-[5px] w-[47px] bg-[#fbeedc] rounded-full" />
        <div className="h-[5px] w-[47px] bg-[#fbeedc] rounded-full" />
      </div>

      {/* Decorative blur */}
      <div className="absolute top-8 right-[-40px] w-40 h-40 opacity-30">
        <div className="w-full h-full rounded-full bg-[#FD587A] blur-[75px]" />
      </div>

      {/* Content */}
      <div className="px-6">
        {/* Title */}
        <div className="text-center mb-12">
          <h1 className="font-['Ninetea:Bold',sans-serif] text-[28px] text-[#f58020] mb-2">
            Configuración de Perfil
          </h1>
          <p className="font-['Inter:Regular',sans-serif] text-[#130b3d] text-[18px]">
            Cuéntanos un poco sobre ti
          </p>
        </div>

        {/* Form inputs */}
        <div className="space-y-5 mb-8">
          {/* Name input */}
          <div className="relative">
            <input
              type="text"
              placeholder="Nombre de Usuario"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full h-[63px] px-5 bg-white/42 border border-white rounded-[31px] font-['Ninetea:Medium',sans-serif] text-[#130b3d] placeholder:text-[#130b3d]/60 focus:outline-none focus:ring-2 focus:ring-[#f58020]/30"
            />
          </div>

          {/* Date of birth input */}
          <div className="relative">
            <input
              type="date"
              placeholder="Fecha de Nacimiento"
              className="w-full h-[63px] px-5 bg-white/42 border border-white rounded-[31px] font-['Ninetea:Medium',sans-serif] text-[#130b3d] placeholder:text-[#130b3d]/60 focus:outline-none focus:ring-2 focus:ring-[#f58020]/30"
            />
            <Calendar className="absolute right-5 top-1/2 -translate-y-1/2 w-5 h-5 text-[#130b3d] pointer-events-none" />
          </div>
        </div>

        {/* Helper text */}
        <p className="font-['Inter:Light',sans-serif] text-[#130b3d] text-[10px] text-center mb-8 px-4">
          Esta información nos ayuda a personalizar tu experiencia
        </p>

        {/* Continue button */}
        <button
          onClick={handleContinue}
          className="w-full h-[63px] bg-[rgba(245,128,32,0.8)] backdrop-blur-xl border border-white shadow-lg rounded-[31px] flex items-center justify-center gap-2 hover:bg-[rgba(230,116,25,0.9)] transition-colors px-6"
        >
          <span className="font-['Ninetea:Semi_Bold',sans-serif] text-[#fbeedc] text-[17px]">
            Continuar
          </span>
          <svg width="6" height="12" viewBox="0 0 6 12" fill="none">
            <path d="M1 1L5 6L1 11" stroke="#FBEEDC" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
        </button>
      </div>
    </div>
  );
}
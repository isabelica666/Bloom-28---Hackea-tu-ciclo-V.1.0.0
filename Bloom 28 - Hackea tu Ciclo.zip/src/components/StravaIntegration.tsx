import { motion } from 'motion/react';
import { ArrowLeft, TrendingUp, Calendar, Activity, Award, MapPin, Clock, Zap, Target, Trophy, ExternalLink, CheckCircle2 } from 'lucide-react';
import { useEffect } from 'react';

interface StravaIntegrationProps {
  activityType: string;
  onBack: () => void;
}

export function StravaIntegration({ activityType, onBack }: StravaIntegrationProps) {
  // Scroll to top cuando se monta el componente
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  // Datos simulados de Strava
  const recentActivities = [
    { type: 'Run', distance: '5.2 km', time: '28:45', pace: '5:32 /km', date: 'Hace 2 días', elevation: '+45m' },
    { type: 'Walk', distance: '3.8 km', time: '45:20', pace: '11:55 /km', date: 'Hace 4 días', elevation: '+12m' },
    { type: 'Run', distance: '8.5 km', time: '48:15', pace: '5:41 /km', date: 'Hace 6 días', elevation: '+78m' }
  ];

  const weekStats = {
    activities: 5,
    distance: 24.3,
    time: '2h 45m',
    elevation: 156
  };

  const monthlyGoal = {
    target: 100,
    current: 68.5,
    percentage: 68.5
  };

  // Rutas populares cerca
  const popularRoutes = [
    { name: 'Parque del Retiro Loop', distance: '5.5 km', difficulty: 'Fácil', users: '2.3k' },
    { name: 'Casa de Campo Trail', distance: '8.2 km', difficulty: 'Moderada', users: '1.8k' },
    { name: 'Madrid Río Path', distance: '6.8 km', difficulty: 'Fácil', users: '3.1k' }
  ];

  const getActivityIcon = () => {
    if (activityType.toLowerCase().includes('running')) return '🏃‍♀️';
    if (activityType.toLowerCase().includes('caminata')) return '🚶‍♀️';
    if (activityType.toLowerCase().includes('natación')) return '🏊‍♀️';
    return '🏃‍♀️';
  };

  const getActivityTypeInStrava = () => {
    if (activityType.toLowerCase().includes('running')) return 'Run';
    if (activityType.toLowerCase().includes('caminata')) return 'Walk';
    if (activityType.toLowerCase().includes('natación')) return 'Swim';
    return 'Run';
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#fc5200] via-[#fb8c00] to-[#fbeedc]">
      {/* Header */}
      <div className="px-6 pt-12 pb-6">
        <button onClick={onBack} className="mb-6 flex items-center gap-2 text-white">
          <ArrowLeft className="w-6 h-6" strokeWidth={2} />
          <span className="font-['Inter:Medium',sans-serif] text-sm">Volver</span>
        </button>
        
        <div className="flex items-center gap-3 mb-6">
          <div className="w-12 h-12 bg-white rounded-2xl flex items-center justify-center">
            <span className="text-2xl">{getActivityIcon()}</span>
          </div>
          <div>
            <h1 className="font-['Ninetea:Bold',sans-serif] text-white text-[28px] leading-tight">Strava</h1>
            <p className="font-['Inter:Regular',sans-serif] text-white/90 text-sm">Sigue tu progreso</p>
          </div>
        </div>

        {/* Connection Status */}
        <motion.div 
          className="bg-white/20 backdrop-blur-xl border-2 border-white/40 rounded-2xl p-4 flex items-center gap-3"
          initial={{ scale: 0.95, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
        >
          <CheckCircle2 className="w-6 h-6 text-white flex-shrink-0" strokeWidth={2.5} />
          <div>
            <p className="font-['Ninetea:Bold',sans-serif] text-white text-sm">Conectado con Strava</p>
            <p className="font-['Inter:Regular',sans-serif] text-white/80 text-xs">Tus actividades se sincronizarán automáticamente</p>
          </div>
        </motion.div>
      </div>

      {/* Actividad recomendada */}
      <div className="px-6 mb-6">
        <div className="bg-white rounded-3xl p-5 shadow-xl">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-10 h-10 bg-gradient-to-br from-[#fc5200] to-[#fb8c00] rounded-full flex items-center justify-center">
              <Target className="w-5 h-5 text-white" strokeWidth={2} />
            </div>
            <div>
              <p className="font-['Inter:Regular',sans-serif] text-gray-600 text-xs">Recomendado para hoy</p>
              <h2 className="font-['Ninetea:Bold',sans-serif] text-[#130b3d] text-lg">{activityType}</h2>
            </div>
          </div>
          <button className="w-full bg-gradient-to-r from-[#fc5200] to-[#fb8c00] text-white font-['Ninetea:Bold',sans-serif] py-3 rounded-full shadow-lg flex items-center justify-center gap-2">
            Registrar {getActivityTypeInStrava()}
            <ExternalLink className="w-5 h-5" strokeWidth={2} />
          </button>
        </div>
      </div>

      {/* Stats de la semana */}
      <div className="px-6 mb-6">
        <h3 className="font-['Ninetea:Bold',sans-serif] text-white text-lg mb-4 flex items-center gap-2">
          <TrendingUp className="w-5 h-5" strokeWidth={2} />
          Esta Semana
        </h3>
        <div className="grid grid-cols-2 gap-3">
          <div className="bg-white/20 backdrop-blur-xl border border-white/40 rounded-2xl p-4">
            <div className="flex items-center gap-2 mb-2">
              <Activity className="w-5 h-5 text-white" strokeWidth={2} />
              <span className="font-['Inter:Regular',sans-serif] text-white/80 text-xs">Actividades</span>
            </div>
            <p className="font-['Ninetea:Bold',sans-serif] text-white text-3xl">{weekStats.activities}</p>
          </div>
          <div className="bg-white/20 backdrop-blur-xl border border-white/40 rounded-2xl p-4">
            <div className="flex items-center gap-2 mb-2">
              <MapPin className="w-5 h-5 text-white" strokeWidth={2} />
              <span className="font-['Inter:Regular',sans-serif] text-white/80 text-xs">Distancia</span>
            </div>
            <p className="font-['Ninetea:Bold',sans-serif] text-white text-3xl">{weekStats.distance} km</p>
          </div>
          <div className="bg-white/20 backdrop-blur-xl border border-white/40 rounded-2xl p-4">
            <div className="flex items-center gap-2 mb-2">
              <Clock className="w-5 h-5 text-white" strokeWidth={2} />
              <span className="font-['Inter:Regular',sans-serif] text-white/80 text-xs">Tiempo</span>
            </div>
            <p className="font-['Nineteea:Bold',sans-serif] text-white text-2xl">{weekStats.time}</p>
          </div>
          <div className="bg-white/20 backdrop-blur-xl border border-white/40 rounded-2xl p-4">
            <div className="flex items-center gap-2 mb-2">
              <TrendingUp className="w-5 h-5 text-white" strokeWidth={2} />
              <span className="font-['Inter:Regular',sans-serif] text-white/80 text-xs">Elevación</span>
            </div>
            <p className="font-['Ninetea:Bold',sans-serif] text-white text-2xl">{weekStats.elevation}m</p>
          </div>
        </div>
      </div>

      {/* Meta mensual */}
      <div className="px-6 mb-6">
        <div className="bg-white rounded-3xl p-5 shadow-xl">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <Trophy className="w-6 h-6 text-[#fc5200]" strokeWidth={2} />
              <h3 className="font-['Ninetea:Bold',sans-serif] text-[#130b3d] text-base">Meta de Enero</h3>
            </div>
            <span className="font-['Ninetea:Bold',sans-serif] text-[#fc5200] text-lg">{monthlyGoal.percentage}%</span>
          </div>
          <div className="mb-3">
            <div className="flex justify-between items-baseline mb-2">
              <span className="font-['Inter:Regular',sans-serif] text-gray-600 text-sm">{monthlyGoal.current} km</span>
              <span className="font-['Inter:Regular',sans-serif] text-gray-600 text-sm">de {monthlyGoal.target} km</span>
            </div>
            <div className="h-3 bg-gray-200 rounded-full overflow-hidden">
              <motion.div 
                className="h-full bg-gradient-to-r from-[#fc5200] to-[#fb8c00] rounded-full"
                initial={{ width: 0 }}
                animate={{ width: `${monthlyGoal.percentage}%` }}
                transition={{ duration: 1, delay: 0.3 }}
              />
            </div>
          </div>
          <p className="font-['Inter:Regular',sans-serif] text-gray-600 text-xs">
            ¡Vas genial! Solo faltan {(monthlyGoal.target - monthlyGoal.current).toFixed(1)} km para alcanzar tu meta
          </p>
        </div>
      </div>

      {/* Actividades recientes */}
      <div className="px-6 mb-6">
        <h3 className="font-['Ninetea:Bold',sans-serif] text-white text-lg mb-4 flex items-center gap-2">
          <Calendar className="w-5 h-5" strokeWidth={2} />
          Actividades Recientes
        </h3>
        <div className="space-y-3">
          {recentActivities.map((activity, index) => (
            <motion.div
              key={index}
              className="bg-white rounded-2xl p-4"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: index * 0.1 }}
            >
              <div className="flex items-start justify-between mb-3">
                <div>
                  <h4 className="font-['Ninetea:Bold',sans-serif] text-[#130b3d] text-base mb-1">
                    {activity.type === 'Run' ? '🏃‍♀️ Run' : '🚶‍♀️ Walk'}
                  </h4>
                  <p className="font-['Inter:Regular',sans-serif] text-gray-500 text-xs">{activity.date}</p>
                </div>
                <button>
                  <ExternalLink className="w-5 h-5 text-[#fc5200]" strokeWidth={2} />
                </button>
              </div>
              <div className="grid grid-cols-3 gap-3">
                <div>
                  <p className="font-['Inter:Regular',sans-serif] text-gray-500 text-xs mb-1">Distancia</p>
                  <p className="font-['Ninetea:Bold',sans-serif] text-[#130b3d] text-sm">{activity.distance}</p>
                </div>
                <div>
                  <p className="font-['Inter:Regular',sans-serif] text-gray-500 text-xs mb-1">Tiempo</p>
                  <p className="font-['Ninetea:Bold',sans-serif] text-[#130b3d] text-sm">{activity.time}</p>
                </div>
                <div>
                  <p className="font-['Inter:Regular',sans-serif] text-gray-500 text-xs mb-1">Ritmo</p>
                  <p className="font-['Ninetea:Bold',sans-serif] text-[#130b3d] text-sm">{activity.pace}</p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>

      {/* Rutas populares */}
      <div className="px-6 pb-28">
        <h3 className="font-['Ninetea:Bold',sans-serif] text-white text-lg mb-4 flex items-center gap-2">
          <MapPin className="w-5 h-5" strokeWidth={2} />
          Rutas Populares Cerca de Ti
        </h3>
        <div className="space-y-3">
          {popularRoutes.map((route, index) => (
            <motion.div
              key={index}
              className="bg-white rounded-2xl p-4 flex items-center justify-between"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 + 0.3 }}
            >
              <div className="flex-1">
                <h4 className="font-['Ninetea:Bold',sans-serif] text-[#130b3d] text-sm mb-1">{route.name}</h4>
                <div className="flex items-center gap-3">
                  <span className="font-['Inter:Regular',sans-serif] text-gray-600 text-xs">{route.distance}</span>
                  <span className={`font-['Inter:Bold',sans-serif] text-xs px-2 py-1 rounded-full ${
                    route.difficulty === 'Fácil' 
                      ? 'bg-green-100 text-green-700' 
                      : 'bg-orange-100 text-orange-700'
                  }`}>
                    {route.difficulty}
                  </span>
                  <span className="font-['Inter:Regular',sans-serif] text-gray-500 text-xs">{route.users} usuarios</span>
                </div>
              </div>
              <button>
                <ExternalLink className="w-5 h-5 text-[#fc5200]" strokeWidth={2} />
              </button>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}
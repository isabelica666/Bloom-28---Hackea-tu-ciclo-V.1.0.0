import { useState } from 'react';
import { ArrowLeft, Calendar, Droplet } from 'lucide-react';

interface StartPeriodProps {
  onBack: () => void;
  onSave: (date: Date) => void;
}

export function StartPeriod({ onBack, onSave }: StartPeriodProps) {
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [flow, setFlow] = useState<'ligero' | 'moderado' | 'abundante'>('moderado');

  const handleSave = () => {
    onSave(selectedDate);
    onBack();
  };

  // Generar días del mes actual
  const today = new Date();
  const currentMonth = today.getMonth();
  const currentYear = today.getFullYear();
  const firstDay = new Date(currentYear, currentMonth, 1);
  const lastDay = new Date(currentYear, currentMonth + 1, 0);
  const daysInMonth = lastDay.getDate();
  const startDayOfWeek = firstDay.getDay();

  const days = Array.from({ length: daysInMonth }, (_, i) => i + 1);
  const emptyDays = Array.from({ length: startDayOfWeek }, (_, i) => i);

  const monthNames = ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'];

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#ffe0c6] to-[#f5ebc3] relative overflow-hidden">
      {/* Header */}
      <div className="sticky top-0 bg-gradient-to-r from-[#ea4c89] to-[#f58020] px-6 py-5 shadow-lg z-10">
        <div className="flex items-center justify-between">
          <button 
            onClick={onBack}
            className="p-2 hover:bg-white/20 rounded-full transition-colors"
          >
            <ArrowLeft className="w-6 h-6 text-white" />
          </button>
          <h1 className="font-['Ninetea:Bold',sans-serif] text-white text-xl">
            Registrar Inicio de Período
          </h1>
          <button
            onClick={handleSave}
            className="px-4 py-2 bg-white text-[#ea4c89] rounded-full font-['Ninetea:Semi_Bold',sans-serif] text-sm hover:bg-[#fbeedc] transition-colors"
          >
            Guardar
          </button>
        </div>
      </div>

      <div className="px-6 pt-6 pb-24">
        {/* Medical Disclaimer */}
        <div className="mb-6 bg-[rgba(255,255,255,0.5)] backdrop-blur-xl border border-white shadow-lg rounded-2xl p-4">
          <p className="font-['Inter:Regular',sans-serif] text-[11px] text-[#5250a2] leading-relaxed text-center">
            ⚕️ Esta aplicación es solo para fines de seguimiento personal y no sustituye el consejo médico profesional.
          </p>
        </div>

        {/* Droplet Icon */}
        <div className="flex justify-center mb-8">
          <div className="w-20 h-20 rounded-full bg-gradient-to-br from-[#ea4c89] to-[#f58020] flex items-center justify-center shadow-xl">
            <Droplet className="w-10 h-10 text-white fill-white" />
          </div>
        </div>

        {/* Fecha de Inicio */}
        <div className="mb-8">
          <h2 className="font-['Ninetea:Semi_Bold',sans-serif] text-lg text-[#130b3d] mb-4 text-center">
            ¿Cuándo comenzó tu período?
          </h2>
          
          {/* Month Header */}
          <div className="bg-[rgba(255,255,255,0.5)] backdrop-blur-xl border border-white shadow-lg rounded-2xl p-4 mb-4">
            <h3 className="font-['Ninetea:Semi_Bold',sans-serif] text-center text-[#130b3d] text-lg mb-4">
              {monthNames[currentMonth]} {currentYear}
            </h3>
            
            {/* Calendar Grid */}
            <div className="grid grid-cols-7 gap-2">
              {/* Day headers */}
              {['D', 'L', 'M', 'M', 'J', 'V', 'S'].map((day, i) => (
                <div key={i} className="text-center font-['Inter:Bold',sans-serif] text-sm text-[#7c7c7c] mb-2">
                  {day}
                </div>
              ))}
              
              {/* Empty days */}
              {emptyDays.map((_, i) => (
                <div key={`empty-${i}`} />
              ))}
              
              {/* Calendar days */}
              {days.map((day) => {
                const date = new Date(currentYear, currentMonth, day);
                const isSelected = selectedDate.getDate() === day && 
                                  selectedDate.getMonth() === currentMonth && 
                                  selectedDate.getFullYear() === currentYear;
                const isToday = today.getDate() === day && 
                               today.getMonth() === currentMonth && 
                               today.getFullYear() === currentYear;
                
                return (
                  <button
                    key={day}
                    onClick={() => setSelectedDate(date)}
                    className={`
                      aspect-square rounded-full flex items-center justify-center
                      font-['Inter:Medium',sans-serif] text-sm
                      transition-all duration-200
                      ${isSelected 
                        ? 'bg-gradient-to-br from-[#ea4c89] to-[#f58020] text-white shadow-lg scale-110' 
                        : isToday
                        ? 'bg-[rgba(245,128,32,0.2)] text-[#130b3d]'
                        : 'bg-[rgba(255,255,255,0.3)] text-[#130b3d] hover:bg-[rgba(255,255,255,0.6)]'
                      }
                    `}
                  >
                    {day}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Selected Date Display */}
          <div className="bg-[rgba(255,255,255,0.5)] backdrop-blur-xl border border-white shadow-lg rounded-2xl p-4 flex items-center justify-center gap-3">
            <Calendar className="w-5 h-5 text-[#f58020]" />
            <span className="font-['Inter:Medium',sans-serif] text-[#130b3d]">
              {selectedDate.toLocaleDateString('es-ES', { 
                weekday: 'long', 
                year: 'numeric', 
                month: 'long', 
                day: 'numeric' 
              })}
            </span>
          </div>
        </div>

        {/* Intensidad del Flujo */}
        <div className="mb-6">
          <h2 className="font-['Ninetea:Semi_Bold',sans-serif] text-lg text-[#130b3d] mb-4 text-center">
            Intensidad del Flujo
          </h2>
          
          <div className="space-y-3">
            {[
              { value: 'ligero' as const, label: 'Ligero', color: 'from-[#ffd6e8] to-[#ffc4dd]' },
              { value: 'moderado' as const, label: 'Moderado', color: 'from-[#ff9ec4] to-[#ff7bb3]' },
              { value: 'abundante' as const, label: 'Abundante', color: 'from-[#ea4c89] to-[#d63a75]' }
            ].map((option) => (
              <button
                key={option.value}
                onClick={() => setFlow(option.value)}
                className={`
                  w-full p-4 rounded-2xl transition-all duration-200
                  ${flow === option.value 
                    ? `bg-gradient-to-r ${option.color} shadow-lg scale-105 border-2 border-white` 
                    : 'bg-[rgba(255,255,255,0.5)] backdrop-blur-xl border border-white hover:bg-[rgba(255,255,255,0.7)]'
                  }
                `}
              >
                <div className="flex items-center justify-between">
                  <span className={`font-['Inter:Semi_Bold',sans-serif] ${
                    flow === option.value ? 'text-white' : 'text-[#130b3d]'
                  }`}>
                    {option.label}
                  </span>
                  {flow === option.value && (
                    <div className="w-6 h-6 rounded-full bg-white flex items-center justify-center">
                      <div className="w-3 h-3 rounded-full bg-gradient-to-r from-[#ea4c89] to-[#f58020]" />
                    </div>
                  )}
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* Info Card */}
        <div className="bg-[rgba(234,76,137,0.1)] backdrop-blur-xl border border-[rgba(234,76,137,0.3)] rounded-2xl p-4">
          <p className="font-['Inter:Regular',sans-serif] text-sm text-[#130b3d] leading-relaxed text-center">
            💡 Registra el primer día de tu período para que podamos calcular tu ciclo y darte recomendaciones personalizadas.
          </p>
        </div>
      </div>
    </div>
  );
}

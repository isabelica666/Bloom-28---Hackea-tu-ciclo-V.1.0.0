import { useState, useRef, useEffect } from 'react';
import { ArrowLeft } from 'lucide-react';

interface ProfileSetupHeightProps {
  onContinue: () => void;
  onBack: () => void;
}

export function ProfileSetupHeight({ onContinue, onBack }: ProfileSetupHeightProps) {
  const [unit, setUnit] = useState<'cm' | 'in'>('cm');
  const [height, setHeight] = useState(160);
  const [isDragging, setIsDragging] = useState(false);
  const [dragStartX, setDragStartX] = useState(0);
  const [dragStartHeight, setDragStartHeight] = useState(160);
  const containerRef = useRef<HTMLDivElement>(null);

  const handleMouseDown = (e: React.MouseEvent) => {
    setIsDragging(true);
    setDragStartX(e.clientX);
    setDragStartHeight(height);
  };

  const handleTouchStart = (e: React.TouchEvent) => {
    setIsDragging(true);
    setDragStartX(e.touches[0].clientX);
    setDragStartHeight(height);
  };

  const handleMouseMove = (e: MouseEvent) => {
    if (!isDragging) return;
    const diff = e.clientX - dragStartX;
    const heightChange = Math.round(diff / 10); // 10px = 1 unit
    const newHeight = Math.max(140, Math.min(200, dragStartHeight + heightChange));
    setHeight(newHeight);
  };

  const handleTouchMove = (e: TouchEvent) => {
    if (!isDragging) return;
    const diff = e.touches[0].clientX - dragStartX;
    const heightChange = Math.round(diff / 10);
    const newHeight = Math.max(140, Math.min(200, dragStartHeight + heightChange));
    setHeight(newHeight);
  };

  const handleMouseUp = () => {
    setIsDragging(false);
  };

  useEffect(() => {
    if (isDragging) {
      window.addEventListener('mousemove', handleMouseMove);
      window.addEventListener('mouseup', handleMouseUp);
      window.addEventListener('touchmove', handleTouchMove);
      window.addEventListener('touchend', handleMouseUp);

      return () => {
        window.removeEventListener('mousemove', handleMouseMove);
        window.removeEventListener('mouseup', handleMouseUp);
        window.removeEventListener('touchmove', handleTouchMove);
        window.removeEventListener('touchend', handleMouseUp);
      };
    }
  }, [isDragging, dragStartX, dragStartHeight]);

  // Generate ruler marks
  const generateRulerMarks = () => {
    const marks = [];
    for (let i = 140; i <= 200; i++) {
      const offset = (i - height) * 10; // 10px per unit
      marks.push(
        <div
          key={i}
          className="absolute flex flex-col items-center"
          style={{ 
            left: `calc(50% + ${offset}px)`,
            transform: 'translateX(-50%)',
            transition: isDragging ? 'none' : 'left 0.1s ease-out'
          }}
        >
          <div 
            className={`${i % 10 === 0 ? 'w-[2px] h-12 bg-[#ef932d]' : i % 5 === 0 ? 'w-[1.5px] h-8 bg-[#ef932d]/60' : 'w-[1px] h-4 bg-[#ef932d]/30'}`}
          />
          {i % 10 === 0 && (
            <div className="font-['Montserrat_Alternates:Medium',sans-serif] text-[16px] text-[#f58020] mt-2">
              {i}
            </div>
          )}
        </div>
      );
    }
    return marks;
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#ffe0c6] to-[#f5ebc3] relative">
      {/* Status bar placeholder */}
      <div className="h-12" />

      {/* Back button */}
      <div className="px-6 py-4">
        <button
          onClick={onBack}
          className="flex items-center justify-center w-10 h-10 rounded-xl bg-[rgba(255,255,255,0.5)] backdrop-blur-xl border border-white shadow-lg"
        >
          <ArrowLeft className="w-5 h-5 text-[#130b3d]" />
        </button>
      </div>

      {/* Progress indicators */}
      <div className="flex gap-[7px] justify-center mb-20">
        <div className="h-[5px] w-[47px] bg-[#f58020] rounded-full" />
        <div className="h-[5px] w-[47px] bg-[#f58020] rounded-full" />
        <div className="h-[5px] w-[47px] bg-[#f58020] rounded-full" />
        <div className="h-[5px] w-[47px] bg-[#fbeedc] rounded-full" />
      </div>

      {/* Decorative blur */}
      <div className="absolute top-8 right-[-40px] w-40 h-40 opacity-30">
        <div className="w-full h-full rounded-full bg-[#FD587A] blur-[75px]" />
      </div>

      {/* Content */}
      <div className="px-6 flex flex-col items-center">
        {/* Title */}
        <h1 className="font-['Ninetea:Semi_Bold',sans-serif] text-[30px] text-[#f58020] mb-10 text-center">
          ¿Cuál es tu Altura?
        </h1>

        {/* Unit selector */}
        <div className="relative h-[54px] w-[210px] mb-10">
          <div className="absolute inset-0 border border-white rounded-[27.5px]" />
          <div
            className={`absolute top-[4px] h-[47px] w-[106px] bg-[#f58020] rounded-[27.5px] transition-transform duration-300 ${
              unit === 'cm' ? 'translate-x-[101px]' : 'translate-x-[4px]'
            }`}
          />
          <div className="absolute inset-0 flex">
            <button
              onClick={() => setUnit('in')}
              className={`flex-1 font-['Ninetea:Medium',sans-serif] text-[16px] z-10 transition-colors ${
                unit === 'in' ? 'text-white' : 'text-[#f58020]'
              }`}
            >
              in
            </button>
            <button
              onClick={() => setUnit('cm')}
              className={`flex-1 font-['Ninetea:Medium',sans-serif] text-[16px] z-10 transition-colors ${
                unit === 'cm' ? 'text-white' : 'text-[#f58020]'
              }`}
            >
              cm
            </button>
          </div>
        </div>

        {/* Height picker */}
        <div className="w-full max-w-[340px] bg-white/42 border border-[#fbeedc] rounded-[44px] px-8 py-12 mb-10">
          {/* Current height display */}
          <div className="text-center mb-8">
            <div className="font-['Montserrat_Alternates:Medium',sans-serif] text-[81px] text-[#130b3d] leading-none">
              {height}
            </div>
            <div className="font-['Montserrat_Alternates:Medium',sans-serif] text-[14px] text-[#ef932d] mt-2">
              cm
            </div>
          </div>

          {/* Height ruler */}
          <div 
            ref={containerRef}
            className="relative h-24 overflow-hidden cursor-grab active:cursor-grabbing select-none"
            onMouseDown={handleMouseDown}
            onTouchStart={handleTouchStart}
          >
            {/* Ruler marks */}
            <div className="absolute inset-0">
              {generateRulerMarks()}
            </div>
          </div>

          {/* Helper text */}
          <p className="font-['Inter:Light',sans-serif] text-[#130b3d] text-[10px] text-center mt-4">
            Desliza la regla para ajustar
          </p>
        </div>

        {/* Continue button */}
        <button
          onClick={onContinue}
          className="w-full h-[63px] bg-[rgba(245,128,32,0.8)] backdrop-blur-xl border border-white shadow-lg rounded-[31px] flex items-center justify-center gap-2 hover:bg-[rgba(230,116,25,0.8)] transition-colors mb-8 -mt-4"
        >
          <span className="font-['Ninetea:Semi_Bold',sans-serif] text-[#fbeedc] text-[17px]">
            Continuar
          </span>
          <svg width="6" height="12" viewBox="0 0 6 12" fill="none">
            <path d="M1 1L5 6L1 11" stroke="#FBEEDC" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
        </button>
      </div>
    </div>
  );
}
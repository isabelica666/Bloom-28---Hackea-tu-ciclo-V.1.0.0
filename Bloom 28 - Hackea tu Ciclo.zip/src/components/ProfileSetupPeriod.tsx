import { useState } from 'react';
import { ArrowLeft, Calendar } from 'lucide-react';

interface ProfileSetupPeriodProps {
  onContinue: (cycleData: { lastPeriodDate: string; cycleDuration: number; periodDuration: number }) => void;
  onBack: () => void;
}

export function ProfileSetupPeriod({ onContinue, onBack }: ProfileSetupPeriodProps) {
  const [lastPeriodDate, setLastPeriodDate] = useState('');
  const [cycleDuration, setCycleDuration] = useState(28);
  const [periodDuration, setPeriodDuration] = useState(5);

  const handleContinue = () => {
    if (lastPeriodDate) {
      onContinue({ lastPeriodDate, cycleDuration, periodDuration });
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#ffe0c6] to-[#f5ebc3] relative">
      {/* Status bar placeholder */}
      <div className="h-8" />

      {/* Back button */}
      <div className="px-6 py-2">
        <button
          onClick={onBack}
          className="flex items-center justify-center w-10 h-10 rounded-xl bg-[rgba(255,255,255,0.5)] backdrop-blur-xl border border-white shadow-lg"
        >
          <ArrowLeft className="w-5 h-5 text-[#130b3d]" />
        </button>
      </div>

      {/* Progress indicators */}
      <div className="flex gap-[7px] justify-center mb-6">
        <div className="h-[5px] w-[47px] bg-[#f58020] rounded-full" />
        <div className="h-[5px] w-[47px] bg-[#f58020] rounded-full" />
        <div className="h-[5px] w-[47px] bg-[#f58020] rounded-full" />
        <div className="h-[5px] w-[47px] bg-[#f58020] rounded-full" />
      </div>

      {/* Decorative blur */}
      <div className="absolute top-8 right-[-40px] w-40 h-40 opacity-30">
        <div className="w-full h-full rounded-full bg-[#FD587A] blur-[75px]" />
      </div>

      {/* Content */}
      <div className="px-6 flex flex-col items-center">
        {/* Title */}
        <h1 className="font-['Ninetea:Semi_Bold',sans-serif] text-[30px] text-[#f58020] mb-1 text-center">
          Tu Ciclo Menstrual
        </h1>
        <p className="font-['Inter:Regular',sans-serif] text-[#130b3d] text-[14px] text-center mb-5">
          Ayúdanos a entender tu ciclo para mejores predicciones
        </p>

        {/* Form fields */}
        <div className="w-full max-w-[336px] mb-4 space-y-4">
          {/* Last period date */}
          <div>
            <h3 className="font-['Ninetea:Medium',sans-serif] text-[#f58020] text-[19.5px] mb-1.5">
              Fecha del Último Periodo
            </h3>
            <div className="relative">
              <input
                type="date"
                value={lastPeriodDate}
                onChange={(e) => setLastPeriodDate(e.target.value)}
                className="w-full h-[63px] bg-[#fcf1dd] border border-[#fbeedc] rounded-[31px] px-6 pr-14 font-['Ninetea:Medium',sans-serif] text-[#130b3d] text-[12.63px] [&::-webkit-calendar-picker-indicator]:opacity-0 [&::-webkit-calendar-picker-indicator]:absolute [&::-webkit-calendar-picker-indicator]:right-6 [&::-webkit-calendar-picker-indicator]:w-5 [&::-webkit-calendar-picker-indicator]:h-5 [&::-webkit-calendar-picker-indicator]:cursor-pointer"
                style={{
                  colorScheme: 'light'
                }}
              />
              <Calendar className="absolute right-6 top-1/2 -translate-y-1/2 w-5 h-5 text-[#130b3d] pointer-events-none" />
            </div>
            <p className="font-['Inter:Light',sans-serif] text-[#130b3d] text-[9.5px] mt-1.5">
              Primer día de tu último período menstrual
            </p>
          </div>

          {/* Cycle duration slider */}
          <div>
            <h3 className="font-['Ninetea:Regular',sans-serif] text-[#f58020] text-[19.5px] mb-1.5">
              Duración de tu Ciclo (días)
            </h3>
            <div className="flex items-center gap-4 mb-2">
              <div className="flex-1 relative">
                <input
                  type="range"
                  min="21"
                  max="35"
                  value={cycleDuration}
                  onChange={(e) => setCycleDuration(Number(e.target.value))}
                  className="w-full h-2 bg-white rounded-full appearance-none cursor-pointer [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:w-[18px] [&::-webkit-slider-thumb]:h-[18px] [&::-webkit-slider-thumb]:rounded-full [&::-webkit-slider-thumb]:bg-[#f58020] [&::-webkit-slider-thumb]:cursor-pointer [&::-moz-range-thumb]:w-[18px] [&::-moz-range-thumb]:h-[18px] [&::-moz-range-thumb]:rounded-full [&::-moz-range-thumb]:bg-[#f58020] [&::-moz-range-thumb]:border-0 [&::-moz-range-thumb]:cursor-pointer"
                  style={{
                    background: `linear-gradient(to right, #f58020 0%, #f58020 ${((cycleDuration - 21) / (35 - 21)) * 100}%, white ${((cycleDuration - 21) / (35 - 21)) * 100}%, white 100%)`
                  }}
                />
              </div>
              <div className="w-[93px] h-[41px] bg-[#fcf1dd] border border-[#fbeedc] rounded-[31px] flex items-center justify-center">
                <span className="font-['Ninetea:Medium',sans-serif] text-[#130b3d] text-[18.63px]">
                  {cycleDuration} Días
                </span>
              </div>
            </div>
            <p className="font-['Inter:Light',sans-serif] text-[#130b3d] text-[9.5px] mt-1">
              Tiempo entre el primer día de un período y el siguiente
            </p>
          </div>

          {/* Period duration slider */}
          <div>
            <h3 className="font-['Ninetea:Regular',sans-serif] text-[#f58020] text-[19.5px] mb-1.5">
              Duración de tu Período (días)
            </h3>
            <div className="flex items-center gap-4 mb-2">
              <div className="flex-1 relative">
                <input
                  type="range"
                  min="3"
                  max="7"
                  value={periodDuration}
                  onChange={(e) => setPeriodDuration(Number(e.target.value))}
                  className="w-full h-2 bg-white rounded-full appearance-none cursor-pointer [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:w-[18px] [&::-webkit-slider-thumb]:h-[18px] [&::-webkit-slider-thumb]:rounded-full [&::-webkit-slider-thumb]:bg-[#f58020] [&::-webkit-slider-thumb]:cursor-pointer [&::-moz-range-thumb]:w-[18px] [&::-moz-range-thumb]:h-[18px] [&::-moz-range-thumb]:rounded-full [&::-moz-range-thumb]:bg-[#f58020] [&::-moz-range-thumb]:border-0 [&::-moz-range-thumb]:cursor-pointer"
                  style={{
                    background: `linear-gradient(to right, #f58020 0%, #f58020 ${((periodDuration - 3) / (7 - 3)) * 100}%, white ${((periodDuration - 3) / (7 - 3)) * 100}%, white 100%)`
                  }}
                />
              </div>
              <div className="w-[93px] h-[41px] bg-[#fcf1dd] border border-[#fbeedc] rounded-[31px] flex items-center justify-center">
                <span className="font-['Ninetea:Medium',sans-serif] text-[#130b3d] text-[18.63px]">
                  {periodDuration} Días
                </span>
              </div>
            </div>
            <p className="font-['Inter:Light',sans-serif] text-[#130b3d] text-[9.5px] mt-1">
              Número de días que dura tu menstruación
            </p>
          </div>
        </div>

        {/* Info box */}
        <div className="w-full max-w-[345px] bg-gradient-to-b from-[#f7be7e] to-[#fff2e3] border border-[#fbeedc] rounded-[31px] px-6 py-4 mb-4">
          <p className="font-['Inter:Regular',sans-serif] text-[#130b3d] text-[12.63px] text-center leading-tight">
            💡 No te preocupes si no conoces estos datos con exactitud. Puedes ajustarlos más tarde con los datos de tus Wearables
          </p>
        </div>

        {/* Continue button */}
        <button
          onClick={handleContinue}
          disabled={!lastPeriodDate}
          className="w-full max-w-[345px] h-[63px] bg-[rgba(245,128,32,0.8)] backdrop-blur-xl border border-white shadow-lg rounded-[31px] flex items-center justify-center gap-2 hover:bg-[rgba(230,116,25,0.8)] transition-colors mb-6 mt-20 disabled:opacity-50 disabled:cursor-not-allowed"
        >
          <span className="font-['Ninetea:Semi_Bold',sans-serif] text-[#fbeedc] text-[17px]">
            Continuar
          </span>
          <svg width="6" height="12" viewBox="0 0 6 12" fill="none">
            <path d="M1 1L5 6L1 11" stroke="#FBEEDC" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
        </button>
      </div>
    </div>
  );
}
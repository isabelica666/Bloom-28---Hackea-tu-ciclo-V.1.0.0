import { useEffect } from 'react';

interface ProfileSetupWearableLoadingProps {
  onComplete: () => void;
}

export function ProfileSetupWearableLoading({ onComplete }: ProfileSetupWearableLoadingProps) {
  useEffect(() => {
    const timer = setTimeout(() => {
      onComplete();
    }, 2500);

    return () => clearTimeout(timer);
  }, [onComplete]);

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#ffe0c6] to-[#f5ebc3] relative flex items-center justify-center">
      {/* Decorative blur */}
      <div className="absolute top-8 right-[-40px] w-40 h-40 opacity-30">
        <div className="w-full h-full rounded-full bg-[#FD587A] blur-[75px]" />
      </div>

      {/* Content */}
      <div className="px-6 flex flex-col items-center">
        {/* Loading animation */}
        <div className="relative w-[160px] h-[160px] mb-8">
          {/* Outer rotating circle */}
          <div className="absolute inset-0 rounded-full border-4 border-transparent border-t-[#f58020] border-r-[#f58020] animate-spin" />
          
          {/* Middle rotating circle - opposite direction */}
          <div className="absolute inset-4 rounded-full border-4 border-transparent border-b-[#ea4c89] border-l-[#ea4c89] animate-spin-slow" />
          
          {/* Inner circle with icon */}
          <div className="absolute inset-8 rounded-full bg-[#fcf1dd] border-2 border-[#fbeedc] flex items-center justify-center">
            <svg width="60" height="60" viewBox="0 0 60 60" fill="none" className="animate-pulse">
              <rect x="15" y="10" width="30" height="40" rx="6" stroke="#f58020" strokeWidth="3"/>
              <line x1="22" y1="17" x2="38" y2="17" stroke="#f58020" strokeWidth="3" strokeLinecap="round"/>
              <circle cx="30" cy="30" r="5" fill="#ea4c89" className="animate-ping-slow" opacity="0.6"/>
            </svg>
          </div>
        </div>

        {/* Loading text */}
        <h1 className="font-['Ninetea:Semi_Bold',sans-serif] text-[28px] text-[#f58020] mb-2 text-center">
          Conectando...
        </h1>
        <p className="font-['Inter:Regular',sans-serif] text-[#130b3d] text-[14px] text-center max-w-[280px]">
          Estableciendo conexión segura con tu dispositivo
        </p>

        {/* Loading dots animation */}
        <div className="flex gap-2 mt-6">
          <div className="w-3 h-3 bg-[#f58020] rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
          <div className="w-3 h-3 bg-[#ea4c89] rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
          <div className="w-3 h-3 bg-[#f58020] rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
        </div>
      </div>

      <style>{`
        @keyframes spin-slow {
          from {
            transform: rotate(360deg);
          }
          to {
            transform: rotate(0deg);
          }
        }
        
        @keyframes ping-slow {
          0%, 100% {
            transform: scale(1);
            opacity: 0.6;
          }
          50% {
            transform: scale(1.5);
            opacity: 0.3;
          }
        }
        
        .animate-spin-slow {
          animation: spin-slow 2s linear infinite;
        }
        
        .animate-ping-slow {
          animation: ping-slow 1.5s ease-in-out infinite;
        }
      `}</style>
    </div>
  );
}

import { ArrowLeft, CheckCircle2, Heart, Activity, Moon } from 'lucide-react';

interface ProfileSetupWearableSuccessProps {
  onContinue: () => void;
  onBack: () => void;
}

export function ProfileSetupWearableSuccess({ onContinue, onBack }: ProfileSetupWearableSuccessProps) {
  return (
    <div className="min-h-screen bg-gradient-to-b from-[#ffe0c6] to-[#f5ebc3] relative">
      {/* Status bar placeholder */}
      <div className="h-8" />

      {/* Back button */}
      <div className="px-6 py-2">
        <button
          onClick={onBack}
          className="flex items-center justify-center w-10 h-10 rounded-xl bg-[rgba(255,255,255,0.5)] backdrop-blur-xl border border-white shadow-lg"
        >
          <ArrowLeft className="w-5 h-5 text-[#130b3d]" />
        </button>
      </div>

      {/* Progress indicators */}
      <div className="flex gap-[7px] justify-center mb-4">
        <div className="h-[5px] w-[47px] bg-[#f58020] rounded-full" />
        <div className="h-[5px] w-[47px] bg-[#f58020] rounded-full" />
        <div className="h-[5px] w-[47px] bg-[#f58020] rounded-full" />
        <div className="h-[5px] w-[47px] bg-[#f58020] rounded-full" />
      </div>

      {/* Decorative blur */}
      <div className="absolute top-8 right-[-40px] w-40 h-40 opacity-30">
        <div className="w-full h-full rounded-full bg-[#FD587A] blur-[75px]" />
      </div>

      {/* Content */}
      <div className="px-6 flex flex-col items-center">
        {/* Title */}
        <h1 className="font-['Ninetea:Semi_Bold',sans-serif] text-[30px] text-[#f58020] mb-1 text-center">
          ¡Conectado!
        </h1>
        <p className="font-['Inter:Regular',sans-serif] text-[#130b3d] text-[14px] text-center mb-6">
          Tu dispositivo se conectó exitosamente
        </p>

        {/* Success icon circle */}
        <div className="w-[140px] h-[140px] bg-[#fcf1dd] border-2 border-[#f58020] rounded-full flex items-center justify-center mb-6">
          <CheckCircle2 className="w-20 h-20 text-[#f58020]" strokeWidth={2} />
        </div>

        {/* Device info card */}
        <div className="w-full max-w-[335px] bg-[#fcf1dd] border border-[#fbeedc] rounded-[31px] px-6 py-5 mb-4">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="font-['Ninetea:Bold',sans-serif] text-[#130b3d] text-[17px] mb-1">
                Apple Watch Series 8
              </h2>
              <p className="font-['Inter:Regular',sans-serif] text-[#130b3d] text-[13px]">
                Conectado vía Bluetooth
              </p>
            </div>
            <div className="w-12 h-12 bg-gradient-to-b from-[#f7be7e] to-[#fff2e3] rounded-full flex items-center justify-center">
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
                <rect x="6" y="4" width="12" height="16" rx="3" stroke="#130b3d" strokeWidth="2"/>
                <line x1="9" y1="7" x2="15" y2="7" stroke="#130b3d" strokeWidth="2" strokeLinecap="round"/>
              </svg>
            </div>
          </div>

          {/* Metrics being tracked */}
          <div className="space-y-3">
            <div className="flex items-center gap-3">
              <Heart className="w-5 h-5 text-[#ea4c89]" strokeWidth={2} />
              <span className="font-['Inter:Medium',sans-serif] text-[#130b3d] text-[13px]">
                Frecuencia Cardíaca Activa
              </span>
            </div>
            <div className="flex items-center gap-3">
              <Activity className="w-5 h-5 text-[#f58020]" strokeWidth={2} />
              <span className="font-['Inter:Medium',sans-serif] text-[#130b3d] text-[13px]">
                Temperatura Basal Activa
              </span>
            </div>
            <div className="flex items-center gap-3">
              <Moon className="w-5 h-5 text-[#5250a2]" strokeWidth={2} />
              <span className="font-['Inter:Medium',sans-serif] text-[#130b3d] text-[13px]">
                Análisis de Sueño Activo
              </span>
            </div>
          </div>
        </div>

        {/* Info message */}
        <div className="w-full max-w-[345px] bg-gradient-to-b from-[#f7be7e] to-[#fff2e3] border border-[#fbeedc] rounded-[31px] px-6 py-4 mb-4">
          <p className="font-['Inter:Regular',sans-serif] text-[#130b3d] text-[12.63px] text-center">
            Tus datos se sincronizarán automáticamente para ofrecerte recomendaciones más precisas
          </p>
        </div>

        {/* Continue button */}
        <button
          onClick={onContinue}
          className="w-full max-w-[345px] h-[63px] bg-[rgba(245,128,32,0.8)] backdrop-blur-xl border border-white shadow-lg rounded-[31px] flex items-center justify-center gap-2 hover:bg-[rgba(230,116,25,0.8)] transition-colors mb-6"
        >
          <span className="font-['Ninetea:Semi_Bold',sans-serif] text-[#fbeedc] text-[17px]">
            Continuar
          </span>
          <svg width="6" height="12" viewBox="0 0 6 12" fill="none">
            <path d="M1 1L5 6L1 11" stroke="#FBEEDC" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
        </button>
      </div>
    </div>
  );
}
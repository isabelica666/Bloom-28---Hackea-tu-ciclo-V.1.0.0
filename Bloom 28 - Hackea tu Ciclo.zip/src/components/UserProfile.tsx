import { X, QrCode, Share2, Crown, Star, Calendar, Award, LogOut, Settings, Copy, Check } from 'lucide-react';
import { motion } from 'motion/react';
import { useState } from 'react';

interface UserProfileProps {
  userName: string;
  onClose: () => void;
}

export function UserProfile({ userName, onClose }: UserProfileProps) {
  const [copied, setCopied] = useState(false);
  const referralCode = "FEMCYCLE2024";
  
  const handleCopyReferralCode = () => {
    navigator.clipboard.writeText(referralCode);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-end justify-center"
      onClick={onClose}
    >
      <motion.div
        initial={{ y: '100%' }}
        animate={{ y: 0 }}
        exit={{ y: '100%' }}
        transition={{ type: 'spring', damping: 25, stiffness: 300 }}
        onClick={(e) => e.stopPropagation()}
        className="bg-gradient-to-b from-[#ffe0c6] to-[#f5ebc3] w-full max-w-md rounded-t-[32px] max-h-[90vh] overflow-y-auto pb-8"
      >
        {/* Header */}
        <div className="sticky top-0 bg-gradient-to-b from-[#ffe0c6] to-transparent backdrop-blur-xl z-10 px-6 pt-6 pb-4">
          <div className="flex justify-between items-center mb-6">
            <h2 className="font-['Ninetea:Bold',sans-serif] text-[24px] text-[#130b3d]">Mi Perfil</h2>
            <button
              onClick={onClose}
              className="w-10 h-10 rounded-full bg-[rgba(255,255,255,0.5)] backdrop-blur-xl border border-white shadow-lg flex items-center justify-center hover:bg-[rgba(255,255,255,0.7)] transition-all"
            >
              <X className="w-5 h-5 text-[#130b3d]" />
            </button>
          </div>

          {/* Profile Avatar & Info */}
          <div className="flex flex-col items-center">
            <div className="w-24 h-24 rounded-full bg-gradient-to-br from-[#f58020] to-[#ea4c89] flex items-center justify-center text-white font-['Ninetea:Bold',sans-serif] text-[36px] mb-4 shadow-lg">
              {userName.charAt(0).toUpperCase()}
            </div>
            <h3 className="font-['Ninetea:Bold',sans-serif] text-[20px] text-[#130b3d] mb-1">{userName}</h3>
            <div className="flex items-center gap-2 bg-gradient-to-r from-[#f58020] to-[#ef932d] px-4 py-1.5 rounded-full">
              <Crown className="w-4 h-4 text-white" />
              <span className="font-['Inter:Bold',sans-serif] text-[12px] text-white">Premium</span>
            </div>
          </div>
        </div>

        <div className="px-6 space-y-4 mt-4">
          {/* Stats Cards */}
          <div className="grid grid-cols-3 gap-3">
            <div className="bg-[rgba(255,255,255,0.5)] backdrop-blur-xl border border-white shadow-lg rounded-2xl p-4 text-center">
              <Calendar className="w-5 h-5 text-[#2271b8] mx-auto mb-2" />
              <p className="font-['Ninetea:Bold',sans-serif] text-[18px] text-[#130b3d]">128</p>
              <p className="font-['Inter:Regular',sans-serif] text-[10px] text-[#5250a2]">Días</p>
            </div>
            <div className="bg-[rgba(255,255,255,0.5)] backdrop-blur-xl border border-white shadow-lg rounded-2xl p-4 text-center">
              <Star className="w-5 h-5 text-[#f58020] mx-auto mb-2" />
              <p className="font-['Ninetea:Bold',sans-serif] text-[18px] text-[#130b3d]">245</p>
              <p className="font-['Inter:Regular',sans-serif] text-[10px] text-[#5250a2]">Puntos</p>
            </div>
            <div className="bg-[rgba(255,255,255,0.5)] backdrop-blur-xl border border-white shadow-lg rounded-2xl p-4 text-center">
              <Award className="w-5 h-5 text-[#ea4c89] mx-auto mb-2" />
              <p className="font-['Ninetea:Bold',sans-serif] text-[18px] text-[#130b3d]">12</p>
              <p className="font-['Inter:Regular',sans-serif] text-[10px] text-[#5250a2]">Logros</p>
            </div>
          </div>

          {/* Referral Section */}
          <div className="bg-[rgba(255,255,255,0.5)] backdrop-blur-xl border border-white shadow-lg rounded-2xl p-5">
            <div className="flex items-center gap-2 mb-4">
              <Share2 className="w-5 h-5 text-[#f58020]" />
              <h4 className="font-['Ninetea:Semi_Bold',sans-serif] text-[16px] text-[#130b3d]">Comparte y Gana</h4>
            </div>
            
            <p className="font-['Inter:Regular',sans-serif] text-[12px] text-[#5250a2] mb-4">
              Invita a tus amigas y obtén 1 mes gratis por cada una que se suscriba. ¡Ellas también recibirán 1 mes gratis!
            </p>

            {/* QR Code */}
            <div className="bg-white rounded-xl p-4 mb-4 flex justify-center">
              <div className="w-40 h-40 bg-gradient-to-br from-[#2271b8] to-[#5250a2] rounded-lg flex items-center justify-center relative overflow-hidden">
                <QrCode className="w-32 h-32 text-white" />
                <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTYwIiBoZWlnaHQ9IjE2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cmVjdCB3aWR0aD0iMTYwIiBoZWlnaHQ9IjE2MCIgZmlsbD0iI2ZmZiIvPjwvc3ZnPg==')] opacity-10" />
              </div>
            </div>

            {/* Referral Code */}
            <div className="bg-gradient-to-r from-[#f58020] to-[#ef932d] rounded-xl p-3 mb-3">
              <p className="font-['Inter:Regular',sans-serif] text-[10px] text-white/80 text-center mb-1">Tu Código de Referido</p>
              <div className="flex items-center justify-center gap-2">
                <p className="font-['Ninetea:Bold',sans-serif] text-[20px] text-white tracking-wider">{referralCode}</p>
                <button
                  onClick={handleCopyReferralCode}
                  className="bg-white/20 hover:bg-white/30 transition-all p-2 rounded-lg"
                >
                  {copied ? (
                    <Check className="w-4 h-4 text-white" />
                  ) : (
                    <Copy className="w-4 h-4 text-white" />
                  )}
                </button>
              </div>
            </div>

            <button className="w-full bg-[#2271b8] text-white font-['Inter:Bold',sans-serif] py-3 rounded-xl hover:opacity-90 transition-opacity flex items-center justify-center gap-2">
              <Share2 className="w-4 h-4" />
              Compartir Código
            </button>
          </div>

          {/* Subscription Section */}
          <div className="bg-gradient-to-br from-[rgba(34,113,184,0.9)] to-[rgba(82,80,162,0.9)] backdrop-blur-xl border border-white shadow-lg rounded-2xl p-5 text-white">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <Crown className="w-5 h-5 text-[#f58020]" />
                <h4 className="font-['Ninetea:Semi_Bold',sans-serif] text-[16px]">Suscripción Premium</h4>
              </div>
              <span className="bg-[#f58020] px-3 py-1 rounded-full font-['Inter:Bold',sans-serif] text-[10px]">
                Activa
              </span>
            </div>

            <div className="bg-white/10 backdrop-blur-sm rounded-xl p-4 mb-4">
              <div className="flex justify-between items-center mb-3">
                <span className="font-['Inter:Regular',sans-serif] text-[12px] text-white/80">Plan Actual</span>
                <span className="font-['Ninetea:Bold',sans-serif] text-[16px]">Anual</span>
              </div>
              <div className="flex justify-between items-center mb-3">
                <span className="font-['Inter:Regular',sans-serif] text-[12px] text-white/80">Próximo cobro</span>
                <span className="font-['Inter:Bold',sans-serif] text-[14px]">15 Enero 2026</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="font-['Inter:Regular',sans-serif] text-[12px] text-white/80">Precio</span>
                <span className="font-['Ninetea:Bold',sans-serif] text-[18px]">€120/año</span>
              </div>
            </div>

            <div className="space-y-2 mb-4">
              <p className="font-['Inter:Bold',sans-serif] text-[12px] mb-2">Beneficios Premium:</p>
              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  <div className="w-1.5 h-1.5 rounded-full bg-[#f58020]"></div>
                  <p className="font-['Inter:Regular',sans-serif] text-[11px]">Análisis de IA ilimitados</p>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-1.5 h-1.5 rounded-full bg-[#f58020]"></div>
                  <p className="font-['Inter:Regular',sans-serif] text-[11px]">Sincronización con dispositivos wearables</p>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-1.5 h-1.5 rounded-full bg-[#f58020]"></div>
                  <p className="font-['Inter:Regular',sans-serif] text-[11px]">Recomendaciones personalizadas de ejercicio y nutrición</p>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-1.5 h-1.5 rounded-full bg-[#f58020]"></div>
                  <p className="font-['Inter:Regular',sans-serif] text-[11px]">Acceso a la comunidad exclusiva</p>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-1.5 h-1.5 rounded-full bg-[#f58020]"></div>
                  <p className="font-['Inter:Regular',sans-serif] text-[11px]">Integración con apps de fitness</p>
                </div>
              </div>
            </div>

            <button className="w-full bg-white/20 hover:bg-white/30 text-white font-['Inter:Bold',sans-serif] py-2.5 rounded-xl transition-all">
              Gestionar Suscripción
            </button>
          </div>

          {/* Action Buttons */}
          <div className="space-y-3">
            <button className="w-full bg-[rgba(255,255,255,0.5)] backdrop-blur-xl border border-white shadow-lg text-[#130b3d] font-['Inter:Bold',sans-serif] py-3.5 rounded-2xl hover:bg-[rgba(255,255,255,0.7)] transition-all flex items-center justify-center gap-2">
              <Settings className="w-5 h-5 text-[#5250a2]" />
              Configuración
            </button>
            <button className="w-full bg-[rgba(255,255,255,0.5)] backdrop-blur-xl border border-white shadow-lg text-[#ea4c89] font-['Inter:Bold',sans-serif] py-3.5 rounded-2xl hover:bg-[rgba(255,255,255,0.7)] transition-all flex items-center justify-center gap-2">
              <LogOut className="w-5 h-5" />
              Cerrar Sesión
            </button>
          </div>

          {/* App Info */}
          <div className="text-center pt-4 pb-2">
            <p className="font-['Inter:Regular',sans-serif] text-[10px] text-[#5250a2]">
              Bloom 28 AI V.1.0.0
            </p>
            <p className="font-['Inter:Regular',sans-serif] text-[10px] text-[#5250a2] mt-1">
              © 2026 Bloom28. Todos los derechos reservados.
            </p>
          </div>
        </div>
      </motion.div>
    </motion.div>
  );
}
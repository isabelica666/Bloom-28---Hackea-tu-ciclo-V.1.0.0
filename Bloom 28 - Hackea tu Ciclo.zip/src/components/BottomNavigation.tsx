import { Home, Calendar, Activity, Lightbulb, Users, Smartphone } from 'lucide-react';

interface BottomNavigationProps {
  activeTab: string;
  onTabChange: (tab: string) => void;
}

export function BottomNavigation({ activeTab, onTabChange }: BottomNavigationProps) {
  const navItems = [
    { id: 'dashboard', icon: Home, label: 'Inicio' },
    { id: 'calendar', icon: Calendar, label: 'Calendario' },
    { id: 'data', icon: Activity, label: 'Datos' },
    { id: 'recommendations', icon: Lightbulb, label: 'IA' },
    { id: 'community', icon: Users, label: 'Comunidad' },
    { id: 'devices', icon: Smartphone, label: 'Devices' }
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 max-w-md mx-auto px-[8px] pb-[20px]">
      <div className="bg-[rgba(249,249,249,0.3)] backdrop-blur-xl rounded-[40px] border border-white shadow-lg flex items-center justify-around px-[4px] py-0 h-[60px]">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;

          return (
            <button
              key={item.id}
              onClick={() => onTabChange(item.id)}
              className={`flex items-center justify-center gap-[3px] px-[10px] py-[8px] rounded-[20px] transition-all duration-300 relative flex-shrink-0 ${
                isActive 
                  ? 'bg-[#2271b8] border border-[#1a5a94]' 
                  : 'bg-transparent'
              }`}
            >
              <div className="flex items-center justify-center flex-shrink-0">
                <Icon 
                  className={`w-[20px] h-[20px] ${isActive ? 'text-white' : 'text-[#121212]'}`} 
                  strokeWidth={1.5}
                />
              </div>
              {isActive && (
                <p className="font-['Poppins:Medium',sans-serif] text-[10px] text-white leading-[14px] whitespace-nowrap">
                  {item.label}
                </p>
              )}
            </button>
          );
        })}
      </div>
    </nav>
  );
}
import { motion } from 'motion/react';
import { Users, TrendingUp, Award, Flame, Trophy, Star, Target, Heart, Brain, Coffee, Moon, Zap, CheckCircle2 } from 'lucide-react';
import { calculateCycleInfo, getPhaseName, type CycleData } from '../utils/cycleCalculations';

interface CommunityProps {
  cycleData: CycleData;
}

export function Community({ cycleData }: CommunityProps) {
  const cycleInfo = calculateCycleInfo(cycleData);
  const currentPhase = getPhaseName(cycleInfo.currentPhase);
  
  // Sistema de rachas - simulado
  const currentStreak = 7; // Días consecutivos
  const longestStreak = 14;
  const streakTarget = 30;

  // Estadísticas de la comunidad según fase
  const getCommunityInsights = () => {
    const insights = {
      menstrual: [
        { percentage: 62, activity: 'yoga suave', icon: Heart },
        { percentage: 54, activity: 'meditación guiada', icon: Brain },
        { percentage: 48, activity: 'descanso adicional', icon: Moon }
      ],
      follicular: [
        { percentage: 68, activity: 'ejercicios de cardio', icon: Zap },
        { percentage: 59, activity: 'entrenamientos de fuerza', icon: Trophy },
        { percentage: 51, activity: 'actividades sociales', icon: Users }
      ],
      ovulation: [
        { percentage: 71, activity: 'entrenamientos intensos', icon: Flame },
        { percentage: 64, activity: 'actividades al aire libre', icon: TrendingUp },
        { percentage: 57, activity: 'retos personales', icon: Target }
      ],
      luteal: [
        { percentage: 60, activity: 'pilates o yoga', icon: Heart },
        { percentage: 53, activity: 'caminatas ligeras', icon: Moon },
        { percentage: 47, activity: 'autocuidado consciente', icon: Star }
      ]
    };
    return insights[cycleInfo.currentPhase] || insights.follicular;
  };

  const communityInsights = getCommunityInsights();

  // Logros desbloqueados
  const achievements = [
    { id: 1, title: 'Primera Semana', description: '7 días seguidos', unlocked: true, icon: CheckCircle2 },
    { id: 2, title: 'Conectada', description: '14 días seguidos', unlocked: false, icon: Star },
    { id: 3, title: 'Maestra del Ciclo', description: '30 días seguidos', unlocked: false, icon: Trophy },
    { id: 4, title: 'Warrior', description: '90 días seguidos', unlocked: false, icon: Award }
  ];

  // Desafíos semanales
  const weeklyChallenge = {
    title: 'Desafío Semanal',
    description: 'Registra tus síntomas todos los días esta semana',
    progress: 4,
    total: 7
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#ffe0c6] to-[#f5ebc3] pb-24">
      {/* Header */}
      <div className="px-6 pt-12 pb-6">
        <div className="flex items-center gap-3 mb-2">
          <Users className="w-8 h-8 text-[#f58020]" strokeWidth={2} />
          <h1 className="font-['Ninetea:Bold',sans-serif] text-[#130b3d] text-[28px]">Comunidad</h1>
        </div>
        <p className="font-['Inter:Regular',sans-serif] text-[#130b3d] text-sm opacity-80">
          Conecta con tu ciclo junto a miles de usuarias
        </p>
      </div>

      {/* Sistema de Rachas */}
      <div className="px-6 mb-6">
        <motion.div 
          className="bg-gradient-to-br from-[#f58020] to-[#ef932d] rounded-3xl p-6 shadow-lg border border-white/30 relative overflow-hidden"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          {/* Decorative elements */}
          <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full blur-2xl" />
          <div className="absolute bottom-0 left-0 w-24 h-24 bg-white/10 rounded-full blur-xl" />
          
          <div className="relative z-10">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <Flame className="w-8 h-8 text-white" strokeWidth={2} />
                <h2 className="font-['Ninetea:Bold',sans-serif] text-white text-xl">Racha Actual</h2>
              </div>
              <div className="flex flex-col items-end">
                <span className="font-['Ninetea:Bold',sans-serif] text-white text-4xl">{currentStreak}</span>
                <span className="font-['Inter:Regular',sans-serif] text-white/80 text-sm">días</span>
              </div>
            </div>

            <p className="font-['Inter:Medium',sans-serif] text-white text-base mb-4">
              ¡Llevas {currentStreak} días seguidos de conexión con tu ciclo! Tu coach te lo agradece 🌟
            </p>

            {/* Progress bar */}
            <div className="mb-3">
              <div className="flex justify-between items-center mb-2">
                <span className="font-['Inter:Regular',sans-serif] text-white/90 text-xs">
                  Meta: {streakTarget} días
                </span>
                <span className="font-['Inter:Bold',sans-serif] text-white text-xs">
                  {Math.round((currentStreak / streakTarget) * 100)}%
                </span>
              </div>
              <div className="h-3 bg-white/20 rounded-full overflow-hidden">
                <motion.div 
                  className="h-full bg-white rounded-full"
                  initial={{ width: 0 }}
                  animate={{ width: `${(currentStreak / streakTarget) * 100}%` }}
                  transition={{ duration: 1, delay: 0.3 }}
                />
              </div>
            </div>

            <div className="flex items-center gap-2 text-white/90 text-xs font-['Inter:Regular',sans-serif]">
              <Trophy className="w-4 h-4" />
              <span>Racha más larga: {longestStreak} días</span>
            </div>
          </div>
        </motion.div>
      </div>

      {/* Pulso de la Comunidad */}
      <div className="px-6 mb-6">
        <h2 className="font-['Ninetea:Bold',sans-serif] text-[#130b3d] text-lg mb-4 flex items-center gap-2">
          <TrendingUp className="w-6 h-6 text-[#2271b8]" strokeWidth={2} />
          Pulso de la Comunidad
        </h2>
        <div className="bg-[rgba(252,239,221,0.5)] backdrop-blur-xl border border-white shadow-lg rounded-3xl p-5 mb-3">
          <p className="font-['Inter:Medium',sans-serif] text-[#130b3d] text-sm mb-4">
            Hoy en Fase {currentPhase}:
          </p>
          <div className="space-y-4">
            {communityInsights.map((insight, index) => {
              const Icon = insight.icon;
              return (
                <motion.div 
                  key={index}
                  className="flex items-center gap-4"
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.1 }}
                >
                  <div className="flex-shrink-0 w-10 h-10 rounded-full bg-gradient-to-br from-[#2271b8] to-[#ea4c89] flex items-center justify-center">
                    <Icon className="w-5 h-5 text-white" strokeWidth={2} />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-baseline gap-2 mb-1">
                      <span className="font-['Ninetea:Bold',sans-serif] text-[#f58020] text-2xl">
                        {insight.percentage}%
                      </span>
                      <span className="font-['Inter:Regular',sans-serif] text-[#130b3d] text-sm">
                        de usuarias
                      </span>
                    </div>
                    <p className="font-['Inter:Regular',sans-serif] text-[#130b3d] text-sm">
                      eligieron <span className="font-['Inter:Bold',sans-serif]">{insight.activity}</span> para conectar con su cuerpo
                    </p>
                  </div>
                </motion.div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Desafío Semanal */}
      <div className="px-6 mb-6">
        <h2 className="font-['Ninetea:Bold',sans-serif] text-[#130b3d] text-lg mb-4 flex items-center gap-2">
          <Target className="w-6 h-6 text-[#ea4c89]" strokeWidth={2} />
          {weeklyChallenge.title}
        </h2>
        <div className="bg-[rgba(234,76,137,0.1)] backdrop-blur-xl border border-[#ea4c89]/30 shadow-lg rounded-3xl p-5">
          <p className="font-['Inter:Medium',sans-serif] text-[#130b3d] text-sm mb-4">
            {weeklyChallenge.description}
          </p>
          <div className="flex items-center justify-between mb-2">
            <span className="font-['Inter:Regular',sans-serif] text-[#130b3d] text-xs">
              Progreso
            </span>
            <span className="font-['Inter:Bold',sans-serif] text-[#ea4c89] text-sm">
              {weeklyChallenge.progress}/{weeklyChallenge.total}
            </span>
          </div>
          <div className="h-3 bg-white/40 rounded-full overflow-hidden">
            <motion.div 
              className="h-full bg-gradient-to-r from-[#ea4c89] to-[#f58020] rounded-full"
              initial={{ width: 0 }}
              animate={{ width: `${(weeklyChallenge.progress / weeklyChallenge.total) * 100}%` }}
              transition={{ duration: 1 }}
            />
          </div>
        </div>
      </div>

      {/* Logros */}
      <div className="px-6 mb-6">
        <h2 className="font-['Ninetea:Bold',sans-serif] text-[#130b3d] text-lg mb-4 flex items-center gap-2">
          <Award className="w-6 h-6 text-[#f58020]" strokeWidth={2} />
          Tus Logros
        </h2>
        <div className="grid grid-cols-2 gap-3">
          {achievements.map((achievement, index) => {
            const Icon = achievement.icon;
            return (
              <motion.div
                key={achievement.id}
                className={`rounded-2xl p-4 border ${
                  achievement.unlocked
                    ? 'bg-gradient-to-br from-[#f5ebc3] to-[#ffe0c6] border-[#f58020]/30 shadow-md'
                    : 'bg-[rgba(249,249,249,0.3)] border-white/50 opacity-60'
                }`}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: index * 0.1 }}
              >
                <div className={`w-12 h-12 rounded-full mb-3 flex items-center justify-center ${
                  achievement.unlocked
                    ? 'bg-gradient-to-br from-[#f58020] to-[#ef932d]'
                    : 'bg-gray-300'
                }`}>
                  <Icon className={`w-6 h-6 ${achievement.unlocked ? 'text-white' : 'text-gray-500'}`} strokeWidth={2} />
                </div>
                <h3 className={`font-['Ninetea:Bold',sans-serif] text-sm mb-1 ${
                  achievement.unlocked ? 'text-[#130b3d]' : 'text-gray-500'
                }`}>
                  {achievement.title}
                </h3>
                <p className={`font-['Inter:Regular',sans-serif] text-xs ${
                  achievement.unlocked ? 'text-[#130b3d]' : 'text-gray-400'
                }`}>
                  {achievement.description}
                </p>
              </motion.div>
            );
          })}
        </div>
      </div>

      {/* Estadísticas Globales */}
      <div className="px-6 mb-6">
        <h2 className="font-['Ninetea:Bold',sans-serif] text-[#130b3d] text-lg mb-4 flex items-center gap-2">
          <Star className="w-6 h-6 text-[#2271b8]" strokeWidth={2} />
          Estadísticas Globales
        </h2>
        <div className="grid grid-cols-3 gap-3">
          <div className="bg-[rgba(252,239,221,0.5)] backdrop-blur-xl border border-white shadow-lg rounded-2xl p-4 text-center">
            <p className="font-['Ninetea:Bold',sans-serif] text-[#f58020] text-3xl mb-1">
              84k+
            </p>
            <p className="font-['Inter:Regular',sans-serif] text-[#130b3d] text-xs">
              Usuarias Activas
            </p>
          </div>
          <div className="bg-[rgba(252,239,221,0.5)] backdrop-blur-xl border border-white shadow-lg rounded-2xl p-4 text-center">
            <p className="font-['Ninetea:Bold',sans-serif] text-[#ea4c89] text-3xl mb-1">
              2.1M
            </p>
            <p className="font-['Inter:Regular',sans-serif] text-[#130b3d] text-xs">
              Datos Registrados
            </p>
          </div>
          <div className="bg-[rgba(252,239,221,0.5)] backdrop-blur-xl border border-white shadow-lg rounded-2xl p-4 text-center">
            <p className="font-['Ninetea:Bold',sans-serif] text-[#2271b8] text-3xl mb-1">
              96%
            </p>
            <p className="font-['Inter:Regular',sans-serif] text-[#130b3d] text-xs">
              Satisfacción
            </p>
          </div>
        </div>
      </div>

      {/* Motivational Quote */}
      <div className="px-6 mb-8">
        <div className="bg-gradient-to-br from-[#2271b8]/10 to-[#ea4c89]/10 backdrop-blur-xl border border-white shadow-lg rounded-3xl p-6">
          <div className="flex items-start gap-3">
            <Heart className="w-6 h-6 text-[#ea4c89] flex-shrink-0 mt-1" strokeWidth={2} />
            <div>
              <p className="font-['Inter:Medium',sans-serif] text-[#130b3d] text-base italic mb-2">
                "Conocer tu ciclo es conocerte a ti misma. Cada día que registras es un paso hacia el bienestar."
              </p>
              <p className="font-['Inter:Regular',sans-serif] text-[#130b3d] text-sm opacity-70">
                - Comunidad Bloom28
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

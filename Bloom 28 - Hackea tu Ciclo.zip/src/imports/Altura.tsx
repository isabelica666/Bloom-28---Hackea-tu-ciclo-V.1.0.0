import svgPaths from "./svg-o8pzhh2rk1";
import clsx from "clsx";
type Group5Helper1Props = {
  additionalClassNames?: string;
};

function Group5Helper1({ additionalClassNames = "" }: Group5Helper1Props) {
  return (
    <div style={{ "--transform-inner-width": "0", "--transform-inner-height": "0" } as React.CSSProperties} className={clsx("[grid-area:1_/_1] flex h-[17px] items-center justify-center mt-[125.41px] relative w-0", additionalClassNames)}>
      <div className="flex-none rotate-[90deg]">
        <div className="h-0 relative w-[17px]">
          <div className="absolute inset-[-1px_0_0_0]">
            <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 17 1">
              <line id="Line 6" stroke="var(--stroke-0, #F58020)" x2="17" y1="0.5" y2="0.5" />
            </svg>
          </div>
        </div>
      </div>
    </div>
  );
}
type Group5HelperProps = {
  additionalClassNames?: string;
};

function Group5Helper({ additionalClassNames = "" }: Group5HelperProps) {
  return (
    <div style={{ "--transform-inner-width": "0", "--transform-inner-height": "0" } as React.CSSProperties} className={clsx("[grid-area:1_/_1] flex h-[25px] items-center justify-center mt-[121.41px] relative w-0", additionalClassNames)}>
      <div className="flex-none rotate-[90deg]">
        <div className="h-0 relative w-[25px]">
          <div className="absolute inset-[-1px_0_0_0]">
            <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 25 1">
              <line id="Line 2" stroke="var(--stroke-0, #EF932D)" x2="25" y1="0.5" y2="0.5" />
            </svg>
          </div>
        </div>
      </div>
    </div>
  );
}

function VuesaxLinearArrowSquareLeft() {
  return (
    <div className="absolute contents inset-0" data-name="vuesax/linear/arrow-square-left">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 40 40">
        <g id="arrow-square-left">
          <path d={svgPaths.p3647d300} id="Vector" stroke="var(--stroke-0, #BDBDBD)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d={svgPaths.pe03b900} id="Vector_2" stroke="var(--stroke-0, #292929)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <g id="Vector_3" opacity="0"></g>
        </g>
      </svg>
    </div>
  );
}

function VuesaxLinearArrowSquareLeft1() {
  return (
    <div className="relative shrink-0 size-[40px]" data-name="vuesax/linear/arrow-square-left">
      <VuesaxLinearArrowSquareLeft />
    </div>
  );
}

function Frame3() {
  return (
    <div className="absolute content-stretch flex items-center justify-center left-[40px] top-[8px] w-[265px]">
      <div className="basis-0 flex flex-col font-['Poppins:Medium',sans-serif] grow justify-center leading-[0] min-h-px min-w-px not-italic relative shrink-0 text-[#121212] text-[18px] text-center">
        <p className="leading-[24px]">&nbsp;</p>
      </div>
    </div>
  );
}

function TitleSection() {
  return (
    <div className="content-stretch flex h-[40px] items-center justify-between px-0 py-px relative shrink-0 w-[345px]" data-name="Title Section">
      <VuesaxLinearArrowSquareLeft1 />
      <Frame3 />
    </div>
  );
}

function Frame1() {
  return (
    <div className="content-stretch flex flex-col items-center justify-center relative shrink-0 w-full">
      <TitleSection />
    </div>
  );
}

function Frame2() {
  return (
    <div className="absolute content-stretch flex flex-col items-start left-[24px] top-[68px] w-[345px]">
      <Frame1 />
    </div>
  );
}

function Group() {
  return (
    <div className="absolute contents left-[90.9px] top-[105px]">
      <div className="absolute bg-[#f58020] h-[5px] left-[90.9px] rounded-[51px] top-[105px] w-[47.471px]" />
      <div className="absolute bg-[#f58020] h-[5px] left-[145.68px] rounded-[51px] top-[105px] w-[47.471px]" />
      <div className="absolute bg-[#f58020] h-[5px] left-[200.45px] rounded-[51px] top-[105px] w-[47.471px]" />
      <div className="absolute bg-[#fbeedc] h-[5px] left-[255.23px] rounded-[51px] top-[105px] w-[47.471px]" />
    </div>
  );
}

function Group2() {
  return (
    <div className="grid-cols-[max-content] grid-rows-[max-content] inline-grid leading-[0] place-items-start relative shrink-0">
      <div className="[grid-area:1_/_1] border border-solid border-white h-[54px] ml-0 mt-0 rounded-[27.5px] w-[210px]" />
      <p className="[grid-area:1_/_1] font-['Ninetea:Medium',sans-serif] leading-[1.212] ml-[57.5px] mt-[18px] not-italic relative text-[#f58020] text-[16px] text-center translate-x-[-50%] w-[44px]">in</p>
      <div className="[grid-area:1_/_1] bg-[#f58020] h-[47px] ml-[101.5px] mt-[4px] rounded-[27.5px] w-[106px]" />
      <p className="[grid-area:1_/_1] font-['Ninetea:Medium',sans-serif] leading-[1.212] ml-[154.5px] mt-[18px] not-italic relative text-[16px] text-center text-white translate-x-[-50%] w-[44px]">cm</p>
    </div>
  );
}

function Group1() {
  return (
    <div className="[grid-area:1_/_1] grid-cols-[max-content] grid-rows-[max-content] inline-grid ml-0 mt-0 place-items-start relative">
      <div className="[grid-area:1_/_1] flex h-[48px] items-center justify-center ml-[170px] mt-[98.41px] relative w-0" style={{ "--transform-inner-width": "0", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="flex-none rotate-[90deg]">
          <div className="h-0 relative w-[48px]">
            <div className="absolute inset-[-2px_0_0_0]">
              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 48 2">
                <line id="Line 1" stroke="var(--stroke-0, #EF932D)" strokeWidth="2" x2="48" y1="1" y2="1" />
              </svg>
            </div>
          </div>
        </div>
      </div>
      <Group5Helper additionalClassNames="ml-[104px]" />
      <Group5Helper1 additionalClassNames="ml-[156px]" />
      <Group5Helper1 additionalClassNames="ml-[91px]" />
      <Group5Helper1 additionalClassNames="ml-[222px]" />
      <Group5Helper1 additionalClassNames="ml-[287px]" />
      <Group5Helper1 additionalClassNames="ml-[26px]" />
      <Group5Helper1 additionalClassNames="ml-[143px]" />
      <Group5Helper1 additionalClassNames="ml-[78px]" />
      <Group5Helper1 additionalClassNames="ml-[209px]" />
      <Group5Helper1 additionalClassNames="ml-[274px]" />
      <Group5Helper1 additionalClassNames="ml-[339px]" />
      <Group5Helper1 additionalClassNames="ml-[13px]" />
      <Group5Helper1 additionalClassNames="ml-[130px]" />
      <Group5Helper1 additionalClassNames="ml-[65px]" />
      <Group5Helper1 additionalClassNames="ml-[196px]" />
      <Group5Helper1 additionalClassNames="ml-[261px]" />
      <Group5Helper1 additionalClassNames="ml-[326px]" />
      <Group5Helper1 additionalClassNames="ml-0" />
      <Group5Helper1 additionalClassNames="ml-[117px]" />
      <Group5Helper1 additionalClassNames="ml-[52px]" />
      <Group5Helper1 additionalClassNames="ml-[183px]" />
      <Group5Helper1 additionalClassNames="ml-[248px]" />
      <Group5Helper1 additionalClassNames="ml-[313px]" />
      <Group5Helper additionalClassNames="ml-[39px]" />
      <Group5Helper additionalClassNames="ml-[235px]" />
      <Group5Helper additionalClassNames="ml-[300px]" />
      <p className="[grid-area:1_/_1] font-['Montserrat_Alternates:Medium',sans-serif] leading-[1.212] ml-[170px] mt-0 not-italic relative text-[#130b3d] text-[81px] text-center text-nowrap translate-x-[-50%]">160</p>
      <p className="[grid-area:1_/_1] font-['Montserrat_Alternates:Medium',sans-serif] leading-[1.212] ml-[170px] mt-[157.41px] not-italic relative text-[#ef932d] text-[14px] text-center text-nowrap translate-x-[-50%]">kg</p>
      <p className="[grid-area:1_/_1] font-['Montserrat_Alternates:Medium',sans-serif] leading-[1.212] ml-[104.5px] mt-[91.41px] not-italic relative text-[#f58020] text-[20px] text-center text-nowrap translate-x-[-50%]">150</p>
      <p className="[grid-area:1_/_1] font-['Montserrat_Alternates:Medium',sans-serif] leading-[1.212] ml-[235.5px] mt-[91.41px] not-italic relative text-[#f58020] text-[20px] text-center text-nowrap translate-x-[-50%]">170</p>
      <p className="[grid-area:1_/_1] font-['Montserrat_Alternates:Medium',sans-serif] leading-[1.212] ml-[300px] mt-[91.41px] not-italic relative text-[#f58020] text-[20px] text-center text-nowrap translate-x-[-50%]">180</p>
      <p className="[grid-area:1_/_1] font-['Montserrat_Alternates:Medium',sans-serif] leading-[1.212] ml-[39.5px] mt-[91.41px] not-italic relative text-[#f58020] text-[20px] text-center text-nowrap translate-x-[-50%]">140</p>
    </div>
  );
}

function Group3() {
  return (
    <div className="[grid-area:1_/_1] grid-cols-[max-content] grid-rows-[max-content] inline-grid ml-[111.5px] mt-[54px] place-items-start relative">
      <Group1 />
    </div>
  );
}

function Group4() {
  return (
    <div className="grid-cols-[max-content] grid-rows-[max-content] inline-grid leading-[0] place-items-start relative shrink-0">
      <div className="[grid-area:1_/_1] bg-[rgba(255,255,255,0.42)] border border-[#fbeedc] border-solid h-[282px] ml-0 mt-0 rounded-[44px] w-[562px]" />
      <Group3 />
    </div>
  );
}

function Frame() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[40px] h-[560px] items-center justify-center left-[-27px] overflow-clip px-[50px] py-[13px] top-[148px] w-[440px]">
      <p className="font-['Ninetea:Semi_Bold',sans-serif] leading-[1.212] not-italic relative shrink-0 text-[#f58020] text-[30px] text-center w-[289px]">Cuál es tu Altura?</p>
      <Group2 />
      <Group4 />
    </div>
  );
}

function RegisterButton() {
  return (
    <div className="absolute contents left-[calc(50%+0.3px)] top-[750px] translate-x-[-50%]" data-name="Register (Button)">
      <div className="absolute bg-[#f58020] inset-[88.03%_6.72%_5.75%_6.87%] rounded-[30.943px]" />
      <p className="absolute font-['Ninetea:Semi_Bold',sans-serif] h-[22px] leading-[normal] left-[calc(50%-1.15px)] not-italic text-[#fbeedc] text-[16.878px] text-center top-[767px] translate-x-[-50%] w-[101.301px]">{`Continuar `}</p>
      <div className="absolute h-[12px] left-[244.9px] top-[772px] w-[5.477px]">
        <div className="absolute inset-[-5.62%_-5.33%_-5.62%_-13.48%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 7 14">
            <path d={svgPaths.p1773d800} id="Vector 33" stroke="var(--stroke-0, #FBEEDC)" strokeWidth="2" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function HomeIndicator() {
  return (
    <div className="absolute bottom-0 h-[34px] left-1/2 translate-x-[-50%] w-[393px]" data-name="Home Indicator">
      <div className="absolute h-[34px] left-0 right-0 top-0" data-name="Background" />
      <div className="absolute bottom-[7.67px] flex h-[5px] items-center justify-center left-1/2 translate-x-[-50%] w-[139.938px]">
        <div className="flex-none rotate-[180deg] scale-y-[-100%]">
          <div className="bg-[#121212] h-[5px] rounded-[100px] w-[139.938px]" data-name="Home Indicator" />
        </div>
      </div>
    </div>
  );
}

function IOsIconSmallMobileSignal() {
  return (
    <div className="h-[16px] relative shrink-0 w-[20px]" data-name="iOS / icon / small / Mobile Signal">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 16">
        <g id="iOS / icon / small / Mobile Signal">
          <path d={svgPaths.p15d4ae30} fill="var(--fill-0, #121212)" id="icon" />
        </g>
      </svg>
    </div>
  );
}

function IOsIconSmallWifi() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="iOS / icon / small / Wifi">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="iOS / icon / small / Wifi">
          <path d={svgPaths.p382fcb80} fill="var(--fill-0, #121212)" id="icon" />
        </g>
      </svg>
    </div>
  );
}

function IOsIconSmallBattery() {
  return (
    <div className="h-[16px] relative shrink-0 w-[25px]" data-name="iOS / icon / small / battery">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 25 16">
        <g clipPath="url(#clip0_22_439)" id="iOS / icon / small / battery">
          <path d={svgPaths.p15509f50} id="outline border" opacity="0.35" stroke="var(--stroke-0, #121212)" />
          <path d={svgPaths.p307e0200} fill="var(--fill-0, #121212)" id="node" opacity="0.4" />
          <path d={svgPaths.p365f7580} fill="var(--fill-0, #121212)" id="charge" />
        </g>
        <defs>
          <clipPath id="clip0_22_439">
            <rect fill="white" height="16" width="25" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function IOsIconStatusBar() {
  return (
    <div className="absolute content-stretch flex gap-[2px] items-start right-[15px] top-[15px]" data-name="iOS / icon / status-bar">
      <IOsIconSmallMobileSignal />
      <IOsIconSmallWifi />
      <IOsIconSmallBattery />
    </div>
  );
}

function StatusBar() {
  return (
    <div className="absolute h-[44px] left-0 overflow-clip top-0 w-[393px]" data-name="Status bar">
      <div className="absolute h-[30px] left-1/2 top-[-2px] translate-x-[-50%] w-[219px]" data-name="notch">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 219 30">
          <path d={svgPaths.p7f98200} fill="var(--fill-0, #121212)" id="notch" />
        </svg>
      </div>
      <p className="absolute font-['SF_Pro_Text:Semibold',sans-serif] leading-[21px] left-[32px] not-italic text-[#121212] text-[15px] text-nowrap top-[13px] tracking-[-0.32px]">9:41</p>
      <IOsIconStatusBar />
    </div>
  );
}

export default function Altura() {
  return (
    <div className="bg-gradient-to-b from-[#ffe0c6] overflow-clip relative rounded-[32px] size-full to-[#f5ebc3]" data-name="altura">
      <StatusBar />
      <div className="absolute flex inset-[3.29%_-26.93%_65.95%_67.18%] items-center justify-center">
        <div className="flex-none h-[179.29px] rotate-[226.129deg] skew-x-[6.174deg] w-[172.813px]">
          <div className="relative size-full">
            <div className="absolute inset-[-83.66%_-86.8%]">
              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 473 480">
                <g filter="url(#filter0_f_22_468)" id="Ellipse 7" opacity="0.8">
                  <ellipse cx="236.407" cy="239.645" fill="var(--fill-0, #FD587A)" fillOpacity="0.24" rx="86.4067" ry="89.6449" />
                </g>
                <defs>
                  <filter colorInterpolationFilters="sRGB" filterUnits="userSpaceOnUse" height="479.29" id="filter0_f_22_468" width="472.813" x="0" y="0">
                    <feFlood floodOpacity="0" result="BackgroundImageFix" />
                    <feBlend in="SourceGraphic" in2="BackgroundImageFix" mode="normal" result="shape" />
                    <feGaussianBlur result="effect1_foregroundBlur_22_468" stdDeviation="75" />
                  </filter>
                </defs>
              </svg>
            </div>
          </div>
        </div>
      </div>
      <p className="absolute font-['Poppins:Regular',sans-serif] leading-[0] left-[196.5px] not-italic text-[#121212] text-[0px] text-[12px] text-center text-nowrap top-[910px] translate-x-[-50%]">
        <span className="capitalize leading-[1.3]">Already have an Account?</span>
        <span className="leading-[18px]"> </span>
        <span className="capitalize font-['Poppins:Medium',sans-serif] leading-[18px] text-[#3b82f6]">Login</span>
      </p>
      <Frame2 />
      <Group />
      <Frame />
      <RegisterButton />
      <HomeIndicator />
    </div>
  );
}
import svgPaths from "./svg-z5ti3j6fri";

function VuesaxLinearStatus() {
  return (
    <div className="absolute contents inset-0" data-name="vuesax/linear/status">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="status">
          <path d={svgPaths.p154ebb40} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeMiterlimit="10" strokeWidth="1.5" />
          <path d={svgPaths.p4cb340} id="Vector_2" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeMiterlimit="10" strokeWidth="1.5" />
          <path d={svgPaths.p92c0000} id="Vector_3" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeMiterlimit="10" strokeWidth="1.5" />
          <path d="M23.5 0.5V23.5H0.5V0.5H23.5Z" id="Vector_4" opacity="0" stroke="var(--stroke-0, white)" />
        </g>
      </svg>
    </div>
  );
}

function VuesaxLinearStatus1() {
  return (
    <div className="relative size-[24px]" data-name="vuesax/linear/status">
      <VuesaxLinearStatus />
    </div>
  );
}

function IconContainer() {
  return (
    <div className="bg-[#292929] content-stretch flex gap-[4px] items-center justify-center px-[16px] py-[8px] relative rounded-[20px] shrink-0 w-[95px]" data-name="Icon container">
      <div aria-hidden="true" className="absolute border border-[#121212] border-solid inset-0 pointer-events-none rounded-[20px]" />
      <div className="flex items-center justify-center relative shrink-0">
        <div className="flex-none scale-y-[-100%]">
          <VuesaxLinearStatus1 />
        </div>
      </div>
      <p className="css-ew64yg font-['Poppins:Medium',sans-serif] leading-[16px] not-italic relative shrink-0 text-[12px] text-center text-white">Cycle</p>
    </div>
  );
}

function BottomNavCycle() {
  return (
    <div className="content-stretch flex h-[60px] items-center px-0 py-[10px] relative shrink-0" data-name="Bottom Nav/Cycle">
      <IconContainer />
    </div>
  );
}

function MessageBalloonAi() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="message-balloon-ai-1">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="message-balloon-ai-1">
          <path d={svgPaths.p653f480} id="vector" stroke="var(--stroke-0, #121212)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d={svgPaths.p18204ec0} id="vector_2" stroke="var(--stroke-0, #121212)" strokeWidth="1.09091" />
          <path d="M15 14H9" id="vector_3" stroke="var(--stroke-0, #121212)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d="M12 11H9" id="vector_4" stroke="var(--stroke-0, #121212)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function BottomNavAiAssistant() {
  return (
    <div className="content-stretch flex items-center overflow-clip p-[20px] relative shrink-0" data-name="Bottom Nav/Ai assistant">
      <MessageBalloonAi />
    </div>
  );
}

function VuesaxLinearBook() {
  return (
    <div className="absolute contents inset-0" data-name="vuesax/linear/book">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="book">
          <path d={svgPaths.p75c9200} id="Vector" stroke="var(--stroke-0, #121212)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d="M12 5.49V20.49" id="Vector_2" stroke="var(--stroke-0, #121212)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d="M7.75 8.49H5.5" id="Vector_3" stroke="var(--stroke-0, #121212)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d="M8.5 11.49H5.5" id="Vector_4" stroke="var(--stroke-0, #121212)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <g id="Vector_5" opacity="0"></g>
        </g>
      </svg>
    </div>
  );
}

function VuesaxLinearBook1() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="vuesax/linear/book">
      <VuesaxLinearBook />
    </div>
  );
}

function BottomNavContent() {
  return (
    <div className="content-stretch flex items-center overflow-clip p-[20px] relative shrink-0" data-name="Bottom Nav/Content">
      <VuesaxLinearBook1 />
    </div>
  );
}

export default function BottomNav() {
  return (
    <div className="bg-[rgba(249,249,249,0.3)] content-stretch flex items-center justify-between px-[8px] py-0 relative rounded-[40px] size-full" data-name="Bottom Nav">
      <div aria-hidden="true" className="absolute border border-solid border-white inset-0 pointer-events-none rounded-[40px]" />
      <BottomNavCycle />
      <BottomNavAiAssistant />
      <BottomNavContent />
    </div>
  );
}
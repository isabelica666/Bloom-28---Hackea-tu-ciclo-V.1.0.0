import svgPaths from "./svg-x4mwo688o2";
import clsx from "clsx";
type GroupUltimoEriodoHelper2Props = {
  additionalClassNames?: string;
};

function GroupUltimoEriodoHelper2({ additionalClassNames = "" }: GroupUltimoEriodoHelper2Props) {
  return (
    <div className={clsx("absolute left-[174.22px] size-[18px]", additionalClassNames)}>
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 18 18">
        <circle cx="9" cy="9" fill="var(--fill-0, #F58020)" id="Ellipse 5" r="9" />
      </svg>
    </div>
  );
}
type GroupUltimoEriodoHelper1Props = {
  additionalClassNames?: string;
};

function GroupUltimoEriodoHelper1({ additionalClassNames = "" }: GroupUltimoEriodoHelper1Props) {
  return (
    <div className={clsx("absolute h-0 left-[29.22px] w-[153px]", additionalClassNames)}>
      <div className="absolute inset-[-6px_0_0_0]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 153 6">
          <line id="Line 30" stroke="var(--stroke-0, #F58020)" strokeLinecap="round" strokeWidth="6" x1="3" x2="150" y1="3" y2="3" />
        </svg>
      </div>
    </div>
  );
}
type GroupUltimoEriodoHelperProps = {
  additionalClassNames?: string;
};

function GroupUltimoEriodoHelper({ additionalClassNames = "" }: GroupUltimoEriodoHelperProps) {
  return (
    <div className={clsx("absolute h-0 left-[29.22px] w-[226px]", additionalClassNames)}>
      <div className="absolute inset-[-6px_0_0_0]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 226 6">
          <line id="Line 29" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeWidth="6" x1="3" x2="223" y1="3" y2="3" />
        </svg>
      </div>
    </div>
  );
}
type CalendarHelperProps = {
  additionalClassNames?: string;
};

function CalendarHelper({ additionalClassNames = "" }: CalendarHelperProps) {
  return (
    <div className={clsx("absolute flex items-center justify-center", additionalClassNames)}>
      <div className="flex-none h-px rotate-[90deg] scale-y-[-100%] w-[3px]">
        <div className="relative size-full" data-name="Line">
          <div className="absolute inset-[-25%]">
            <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 5 2">
              <path d="M0.75 0.75H3.75" id="Line" stroke="var(--stroke-0, #130B3D)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
            </svg>
          </div>
        </div>
      </div>
    </div>
  );
}

function Helper() {
  return (
    <div className="absolute inset-[-25%_-6.82%]">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 13 2">
        <g id="Group 218">
          <path d="M0.75 0.75H1.75" id="Line" stroke="var(--stroke-0, #130B3D)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d="M5.75 0.75H6.75" id="Line_2" stroke="var(--stroke-0, #130B3D)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d="M10.75 0.75H11.75" id="Line_3" stroke="var(--stroke-0, #130B3D)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function VuesaxLinearArrowSquareLeft() {
  return (
    <div className="absolute contents inset-0" data-name="vuesax/linear/arrow-square-left">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 40 40">
        <g id="arrow-square-left">
          <path d={svgPaths.p3647d300} id="Vector" stroke="var(--stroke-0, #BDBDBD)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d={svgPaths.pe03b900} id="Vector_2" stroke="var(--stroke-0, #292929)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <g id="Vector_3" opacity="0"></g>
        </g>
      </svg>
    </div>
  );
}

function VuesaxLinearArrowSquareLeft1() {
  return (
    <div className="relative shrink-0 size-[40px]" data-name="vuesax/linear/arrow-square-left">
      <VuesaxLinearArrowSquareLeft />
    </div>
  );
}

function Frame2() {
  return (
    <div className="absolute content-stretch flex items-center justify-center left-[40px] top-[8px] w-[265px]">
      <div className="basis-0 flex flex-col font-['Poppins:Medium',sans-serif] grow justify-center leading-[0] min-h-px min-w-px not-italic relative shrink-0 text-[#121212] text-[18px] text-center">
        <p className="leading-[24px]">&nbsp;</p>
      </div>
    </div>
  );
}

function TitleSection() {
  return (
    <div className="content-stretch flex h-[40px] items-center justify-between px-0 py-px relative shrink-0 w-[345px]" data-name="Title Section">
      <VuesaxLinearArrowSquareLeft1 />
      <Frame2 />
    </div>
  );
}

function Frame() {
  return (
    <div className="content-stretch flex flex-col items-center justify-center relative shrink-0 w-full">
      <TitleSection />
    </div>
  );
}

function Frame1() {
  return (
    <div className="absolute content-stretch flex flex-col items-start left-[24px] top-[68px] w-[345px]">
      <Frame />
    </div>
  );
}

function RegisterButton() {
  return (
    <div className="absolute contents left-[calc(50%+0.3px)] top-[750px] translate-x-[-50%]" data-name="Register (Button)">
      <div className="absolute bg-[#f58020] inset-[88.03%_6.72%_5.75%_6.87%] rounded-[30.943px]" />
      <p className="absolute font-['Ninetea:Semi_Bold',sans-serif] h-[22px] leading-[normal] left-[calc(50%-1.15px)] not-italic text-[#fbeedc] text-[16.878px] text-center top-[767px] translate-x-[-50%] w-[101.301px]">{`Continuar `}</p>
      <div className="absolute h-[12px] left-[244.9px] top-[772px] w-[5.477px]">
        <div className="absolute inset-[-5.62%_-5.33%_-5.62%_-13.48%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 7 14">
            <path d={svgPaths.p1773d800} id="Vector 33" stroke="var(--stroke-0, #FBEEDC)" strokeWidth="2" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Text() {
  return (
    <div className="absolute contents left-[29.39px] right-[27.88px] top-[146px]" data-name="Text">
      <div className="absolute font-['Ninetea:Bold',sans-serif] h-[78.723px] leading-[1.3] left-[29.39px] not-italic right-[27.88px] text-[#fbeedc] text-[0px] text-center top-[146px] tracking-[-0.34px]">
        <p className="mb-[2.250382423400879px] text-[#f58020] text-[30px]">Tu Ciclo Menstrual</p>
        <p className="font-['Inter:Regular',sans-serif] font-normal text-[#130b3d] text-[14px]">Ayúdanos a entender tu ciclo para mejores predicciones</p>
      </div>
    </div>
  );
}

function EnterYourEmailInput() {
  return (
    <div className="absolute contents left-[24px] top-[651.6px]" data-name="Enter your email (Input)">
      <div className="absolute h-[75.397px] left-[24px] top-[651.6px] w-[345px]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 345 76">
          <path d={svgPaths.p35a1f00} fill="url(#paint0_linear_24_1300)" id="Rectangle 4" opacity="0.5" stroke="var(--stroke-0, #FBEEDC)" strokeWidth="1.12519" />
          <defs>
            <linearGradient gradientUnits="userSpaceOnUse" id="paint0_linear_24_1300" x1="172.964" x2="172.964" y1="75.397" y2="4.39697">
              <stop stopColor="#FFF2E3" />
              <stop offset="1" stopColor="#F7BE7E" />
            </linearGradient>
          </defs>
        </svg>
      </div>
      <div className="absolute flex flex-col font-['Inter:Regular',sans-serif] font-normal h-[40.539px] justify-end leading-[0] left-[192.33px] not-italic text-[12.63px] text-center text-white top-[716.54px] translate-x-[-50%] translate-y-[-100%] w-[307.903px]">
        <p className="leading-[1.25]">
          <span>{`💡 `}</span>
          <span className="text-[#130b3d]">No te preocupes si no conoces estos datos con exactitud. Puedes ajustarlos más tarde con los datos de tus Wearables</span>
        </p>
      </div>
    </div>
  );
}

function EnterYourPasswordInput() {
  return (
    <div className="absolute contents left-[272.02px] top-[426px]" data-name="Enter your password (Input)">
      <div className="absolute bg-[#fcf1dd] border-[#fbeedc] border-[1.125px] border-solid h-[41px] left-[272.02px] rounded-[30.943px] top-[426px] w-[92.802px]" />
      <div className="absolute flex flex-col font-['Ninetea:Medium',sans-serif] justify-end leading-[0] left-[317.52px] not-italic text-[#130b3d] text-[18.63px] text-center top-[459px] translate-x-[-50%] translate-y-[-100%] w-[91px]">
        <p className="leading-[1.25]">28 Días</p>
      </div>
    </div>
  );
}

function EnterYourPasswordInput1() {
  return (
    <div className="absolute contents left-[272.02px] top-[531px]" data-name="Enter your password (Input)">
      <div className="absolute bg-[#fcf1dd] border-[#fbeedc] border-[1.125px] border-solid h-[41px] left-[272.02px] rounded-[30.943px] top-[531px] w-[92.802px]" />
      <div className="absolute flex flex-col font-['Ninetea:Medium',sans-serif] justify-end leading-[0] left-[317.52px] not-italic text-[#130b3d] text-[18.63px] text-center top-[564px] translate-x-[-50%] translate-y-[-100%] w-[91px]">
        <p className="leading-[1.25]">5 Días</p>
      </div>
    </div>
  );
}

function Group1() {
  return (
    <div className="absolute bottom-[45.83%] left-[27.08%] right-[27.08%] top-1/2">
      <Helper />
    </div>
  );
}

function Group2() {
  return (
    <div className="absolute inset-[66.67%_27.08%_29.17%_27.08%]">
      <Helper />
    </div>
  );
}

function Group3() {
  return (
    <div className="absolute bottom-[29.17%] contents left-[27.08%] right-[27.08%] top-1/2">
      <Group1 />
      <Group2 />
    </div>
  );
}

function Calendar() {
  return (
    <div className="absolute contents left-[3px] top-[2px]" data-name="Calendar">
      <div className="absolute left-[3px] rounded-[5px] size-[18px] top-[3.5px]">
        <div aria-hidden="true" className="absolute border-[#130b3d] border-[1.5px] border-solid inset-[-0.75px] pointer-events-none rounded-[5.75px]" />
      </div>
      <div className="absolute inset-[33.33%_12.5%_62.5%_12.5%]" data-name="Line">
        <div className="absolute inset-[-25%_0]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 18 2">
            <path d="M0 0.75H18" id="Line" stroke="var(--stroke-0, #130B3D)" strokeLinejoin="round" strokeWidth="1.5" />
          </svg>
        </div>
      </div>
      <CalendarHelper additionalClassNames="inset-[8.33%_29.17%_79.17%_66.67%]" />
      <CalendarHelper additionalClassNames="inset-[8.33%_66.67%_79.17%_29.17%]" />
      <Group3 />
    </div>
  );
}

function IconexLightCalendar() {
  return (
    <div className="absolute inset-[34.74%_11.7%_62.44%_82.19%]" data-name="Iconex/Light/Calendar">
      <Calendar />
    </div>
  );
}

function EnterYourEmailInput1() {
  return (
    <div className="absolute contents left-[29.66px] top-[277px]" data-name="Enter your email (Input)">
      <div className="absolute bg-[#fcf1dd] border-[#fbeedc] border-[1.125px] border-solid h-[63.011px] left-[29.66px] rounded-[30.943px] top-[277px] w-[335.562px]" />
      <div className="absolute flex flex-col font-['Ninetea:Medium',sans-serif] justify-end leading-[0] left-[48px] not-italic text-[#130b3d] text-[12.63px] top-[317px] translate-y-[-100%] w-[175px]">
        <p className="leading-[1.25]">Fecha del Último Periodo</p>
      </div>
      <IconexLightCalendar />
    </div>
  );
}

function GroupUltimoEriodo() {
  return (
    <div className="absolute contents left-[29.22px] top-[244px]" data-name="Group ultimo eriodo">
      <EnterYourPasswordInput />
      <EnterYourPasswordInput1 />
      <EnterYourEmailInput1 />
      <div className="absolute flex flex-col font-['Inter:Light',sans-serif] font-light justify-end leading-[0] left-[29.22px] not-italic text-[#130b3d] text-[9.5px] top-[357px] translate-y-[-100%] w-[336px]">
        <p className="leading-[normal]">Primer día de tu último período menstrual</p>
      </div>
      <div className="absolute flex flex-col font-['Inter:Light',sans-serif] font-light justify-end leading-[0] left-[29.22px] not-italic text-[#130b3d] text-[9.5px] top-[478px] translate-y-[-100%] w-[336px]">
        <p className="leading-[normal]">Tiempo entre el primer día de un período y el siguiente</p>
      </div>
      <div className="absolute flex flex-col font-['Inter:Light',sans-serif] font-light justify-end leading-[0] left-[29.22px] not-italic text-[#130b3d] text-[9.5px] top-[583px] translate-y-[-100%] w-[336px]">
        <p className="leading-[normal]">Número de días que dura tu menstruación</p>
      </div>
      <div className="absolute flex flex-col font-['Ninetea:Regular',sans-serif] justify-end leading-[0] left-[29.22px] not-italic text-[#f58020] text-[19.5px] top-[426px] translate-y-[-100%] w-[336px]">
        <p className="leading-[normal]">Duración de tu Ciclo (días)</p>
      </div>
      <div className="absolute flex flex-col font-['Ninetea:Medium',sans-serif] justify-end leading-[0] left-[29.22px] not-italic text-[#f58020] text-[19.5px] top-[268px] translate-y-[-100%] w-[336px]">
        <p className="leading-[1.25]">Fecha del Último Periodo</p>
      </div>
      <div className="absolute flex flex-col font-['Ninetea:Regular',sans-serif] justify-end leading-[0] left-[29.22px] not-italic text-[#f58020] text-[19.5px] top-[531px] translate-y-[-100%] w-[336px]">
        <p className="leading-[normal]">Duración de tu Período (días)</p>
      </div>
      <GroupUltimoEriodoHelper additionalClassNames="top-[450px]" />
      <GroupUltimoEriodoHelper additionalClassNames="top-[555px]" />
      <GroupUltimoEriodoHelper1 additionalClassNames="top-[450px]" />
      <GroupUltimoEriodoHelper1 additionalClassNames="top-[555px]" />
      <GroupUltimoEriodoHelper2 additionalClassNames="top-[438px]" />
      <GroupUltimoEriodoHelper2 additionalClassNames="top-[543px]" />
    </div>
  );
}

function Group4() {
  return (
    <div className="absolute contents left-[24px] top-[calc(50%+10.5px)] translate-y-[-50%]">
      <Text />
      <EnterYourEmailInput />
      <GroupUltimoEriodo />
    </div>
  );
}

function Group() {
  return (
    <div className="absolute contents left-[94px] top-[105px]">
      <div className="absolute bg-[#f58020] h-[5px] left-[94px] rounded-[51px] top-[105px] w-[47.471px]" />
      <div className="absolute bg-[#f58020] h-[5px] left-[148.77px] rounded-[51px] top-[105px] w-[47.471px]" />
      <div className="absolute bg-[#f58020] h-[5px] left-[203.55px] rounded-[51px] top-[105px] w-[47.471px]" />
      <div className="absolute bg-[#f58020] h-[5px] left-[258.32px] rounded-[51px] top-[105px] w-[47.471px]" />
    </div>
  );
}

function HomeIndicator() {
  return (
    <div className="absolute bottom-0 h-[34px] left-1/2 translate-x-[-50%] w-[393px]" data-name="Home Indicator">
      <div className="absolute h-[34px] left-0 right-0 top-0" data-name="Background" />
      <div className="absolute bottom-[7.67px] flex h-[5px] items-center justify-center left-1/2 translate-x-[-50%] w-[139.938px]">
        <div className="flex-none rotate-[180deg] scale-y-[-100%]">
          <div className="bg-[#121212] h-[5px] rounded-[100px] w-[139.938px]" data-name="Home Indicator" />
        </div>
      </div>
    </div>
  );
}

function IOsIconSmallMobileSignal() {
  return (
    <div className="h-[16px] relative shrink-0 w-[20px]" data-name="iOS / icon / small / Mobile Signal">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 16">
        <g id="iOS / icon / small / Mobile Signal">
          <path d={svgPaths.p15d4ae30} fill="var(--fill-0, #121212)" id="icon" />
        </g>
      </svg>
    </div>
  );
}

function IOsIconSmallWifi() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="iOS / icon / small / Wifi">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="iOS / icon / small / Wifi">
          <path d={svgPaths.p382fcb80} fill="var(--fill-0, #121212)" id="icon" />
        </g>
      </svg>
    </div>
  );
}

function IOsIconSmallBattery() {
  return (
    <div className="h-[16px] relative shrink-0 w-[25px]" data-name="iOS / icon / small / battery">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 25 16">
        <g clipPath="url(#clip0_25_2056)" id="iOS / icon / small / battery">
          <path d={svgPaths.p15509f50} id="outline border" opacity="0.35" stroke="var(--stroke-0, #121212)" />
          <path d={svgPaths.p307e0200} fill="var(--fill-0, #121212)" id="node" opacity="0.4" />
          <path d={svgPaths.p365f7580} fill="var(--fill-0, #121212)" id="charge" />
        </g>
        <defs>
          <clipPath id="clip0_25_2056">
            <rect fill="white" height="16" width="25" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function IOsIconStatusBar() {
  return (
    <div className="absolute content-stretch flex gap-[2px] items-start right-[15px] top-[15px]" data-name="iOS / icon / status-bar">
      <IOsIconSmallMobileSignal />
      <IOsIconSmallWifi />
      <IOsIconSmallBattery />
    </div>
  );
}

function StatusBar() {
  return (
    <div className="absolute h-[44px] left-0 overflow-clip top-0 w-[393px]" data-name="Status bar">
      <div className="absolute h-[30px] left-1/2 top-[-2px] translate-x-[-50%] w-[219px]" data-name="notch">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 219 30">
          <path d={svgPaths.p7f98200} fill="var(--fill-0, #121212)" id="notch" />
        </svg>
      </div>
      <p className="absolute font-['SF_Pro_Text:Semibold',sans-serif] leading-[21px] left-[32px] not-italic text-[#121212] text-[15px] text-nowrap top-[13px] tracking-[-0.32px]">9:41</p>
      <IOsIconStatusBar />
    </div>
  );
}

export default function Periodo() {
  return (
    <div className="bg-gradient-to-b from-[#ffe0c6] overflow-clip relative rounded-[32px] size-full to-[#f5ebc3]" data-name="periodo">
      <StatusBar />
      <div className="absolute flex inset-[3.29%_-26.93%_65.95%_67.18%] items-center justify-center">
        <div className="flex-none h-[179.29px] rotate-[226.129deg] skew-x-[6.174deg] w-[172.813px]">
          <div className="relative size-full">
            <div className="absolute inset-[-83.66%_-86.8%]">
              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 473 480">
                <g filter="url(#filter0_f_25_2087)" id="Ellipse 7" opacity="0.8">
                  <ellipse cx="236.407" cy="239.645" fill="var(--fill-0, #FD587A)" fillOpacity="0.24" rx="86.4067" ry="89.6449" />
                </g>
                <defs>
                  <filter colorInterpolationFilters="sRGB" filterUnits="userSpaceOnUse" height="479.29" id="filter0_f_25_2087" width="472.813" x="0" y="0">
                    <feFlood floodOpacity="0" result="BackgroundImageFix" />
                    <feBlend in="SourceGraphic" in2="BackgroundImageFix" mode="normal" result="shape" />
                    <feGaussianBlur result="effect1_foregroundBlur_25_2087" stdDeviation="75" />
                  </filter>
                </defs>
              </svg>
            </div>
          </div>
        </div>
      </div>
      <p className="absolute font-['Poppins:Regular',sans-serif] leading-[0] left-[196.5px] not-italic text-[#121212] text-[0px] text-[12px] text-center text-nowrap top-[910px] translate-x-[-50%]">
        <span className="capitalize leading-[1.3]">Already have an Account?</span>
        <span className="leading-[18px]"> </span>
        <span className="capitalize font-['Poppins:Medium',sans-serif] leading-[18px] text-[#3b82f6]">Login</span>
      </p>
      <Frame1 />
      <RegisterButton />
      <Group4 />
      <Group />
      <HomeIndicator />
    </div>
  );
}
import svgPaths from "./svg-c4hswlwme5";
import clsx from "clsx";
type Wrapper1Props = {
  additionalClassNames?: string;
};

function Wrapper1({ children, additionalClassNames = "" }: React.PropsWithChildren<Wrapper1Props>) {
  return (
    <div className={additionalClassNames}>
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 1534 138">
        {children}
      </svg>
    </div>
  );
}
type WrapperProps = {
  additionalClassNames?: string;
};

function Wrapper({ children, additionalClassNames = "" }: React.PropsWithChildren<WrapperProps>) {
  return <Wrapper1 additionalClassNames={clsx("absolute h-[137.2px] mix-blend-multiply top-[39.2px] w-[1533.254px]", additionalClassNames)}>{children}</Wrapper1>;
}
type IconexLightHeartProps = {
  additionalClassNames?: string;
};

function IconexLightHeart({ additionalClassNames = "" }: IconexLightHeartProps) {
  return (
    <div className={clsx("absolute", additionalClassNames)}>
      <div className="absolute h-[14.11px] left-[1.49px] top-[2.23px] w-[14.853px]" data-name="Heart">
        <div className="absolute inset-[-3.95%_-3.75%_3.2%_-3.75%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 15">
            <path d={svgPaths.p2dd68700} id="Heart" stroke="var(--stroke-0, #F58020)" strokeWidth="1.11395" />
          </svg>
        </div>
      </div>
    </div>
  );
}
type DateDayProps = {
  text: string;
  text1: string;
};

function DateDay({ text, text1 }: DateDayProps) {
  return (
    <div className="content-stretch flex flex-col gap-[1.782px] items-start leading-[0] not-italic relative shrink-0 text-center">
      <div className="flex flex-col font-['Poppins:Medium',sans-serif] h-[21.382px] justify-center relative shrink-0 text-[#130b3d] text-[16.036px] w-full">
        <p className="leading-[21.382px]">{text}</p>
      </div>
      <div className="flex flex-col font-['Poppins:Regular',sans-serif] h-[12.473px] justify-center relative shrink-0 text-[#7c7c7c] text-[10.691px] w-full">
        <p className="leading-[normal]">{text1}</p>
      </div>
    </div>
  );
}

function WaveHelper() {
  return (
    <Wrapper1 additionalClassNames="h-[137.2px] relative w-[1533.254px]">
      <g id="2" style={{ mixBlendMode: "multiply" }}>
        <path d={svgPaths.p27fc73c0} fill="#FFE0C6" />
      </g>
    </Wrapper1>
  );
}
type CycleDaysDaysProps = {
  additionalClassNames?: string;
};

function CycleDaysDays({ additionalClassNames = "" }: CycleDaysDaysProps) {
  return (
    <div className={clsx("absolute size-[3.564px]", additionalClassNames)}>
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 4 4">
        <circle cx="1.78182" cy="1.78182" fill="url(#paint0_linear_30_2805)" id="Days" r="1.78182" />
        <defs>
          <linearGradient gradientUnits="userSpaceOnUse" id="paint0_linear_30_2805" x1="4.13778" x2="-1.08889" y1="3.30626" y2="-1.90365e-07">
            <stop stopColor="#EF932D" />
            <stop offset="1" stopColor="#F58020" />
          </linearGradient>
        </defs>
      </svg>
    </div>
  );
}

function IconexLightFire({ className }: { className?: string }) {
  return (
    <div className={className} data-name="Iconex/Light/Fire">
      <div className="absolute inset-[12.5%_20.83%]" data-name="Fire">
        <div className="absolute inset-[-3.63%_-5.36%_-4%_-5.36%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 21">
            <g id="Fire">
              <path d={svgPaths.p2a57f600} id="Vector" stroke="var(--stroke-0, #130B3D)" strokeWidth="1.5" />
            </g>
          </svg>
        </div>
      </div>
    </div>
  );
}

function IconexLightUser({ className }: { className?: string }) {
  return (
    <div className={className} data-name="Iconex/Light/User">
      <div className="absolute h-[17.5px] left-[5px] top-[3px] w-[14px]" data-name="User">
        <div className="absolute inset-[-4.29%_-5.36%_-2.58%_-5.36%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 19">
            <g id="User">
              <circle cx="4" cy="4" id="Ellipse 33" r="4" stroke="var(--stroke-0, #2B3F6C)" strokeWidth="1.5" transform="matrix(-1 0 0 1 11.75 0.75)" />
              <path d={svgPaths.pb33f700} id="Rectangle 2" stroke="var(--stroke-0, #2B3F6C)" strokeWidth="1.5" />
            </g>
          </svg>
        </div>
      </div>
    </div>
  );
}

function VuesaxLinearEdit() {
  return (
    <div className="absolute contents inset-0" data-name="vuesax/linear/edit">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 8 8">
        <g id="edit">
          <path d={svgPaths.p1b863800} id="Vector" stroke="var(--stroke-0, #121212)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.5" />
          <path d={svgPaths.p108d2c00} id="Vector_2" stroke="var(--stroke-0, #121212)" strokeLinecap="round" strokeLinejoin="round" strokeMiterlimit="10" strokeWidth="0.5" />
          <path d={svgPaths.p3be38db0} id="Vector_3" stroke="var(--stroke-0, #121212)" strokeLinecap="round" strokeLinejoin="round" strokeMiterlimit="10" strokeWidth="0.5" />
          <g id="Vector_4" opacity="0"></g>
        </g>
      </svg>
    </div>
  );
}

function VuesaxLinearEdit1() {
  return (
    <div className="relative shrink-0 size-[8px]" data-name="vuesax/linear/edit">
      <VuesaxLinearEdit />
    </div>
  );
}

function Frame() {
  return (
    <div className="bg-[#f9f9f9] content-stretch flex items-center justify-center mr-[-14px] p-[7px] relative rounded-[15px] shrink-0 size-[14px]">
      <div aria-hidden="true" className="absolute border-[#121212] border-[0.3px] border-solid inset-0 pointer-events-none rounded-[15px]" />
      <VuesaxLinearEdit1 />
    </div>
  );
}

function ProfilePicture() {
  return (
    <div className="content-stretch flex items-end pl-0 pr-[14px] py-0 relative shrink-0" data-name="Profile Picture">
      <IconexLightUser className="mr-[-14px] relative shrink-0 size-[24px]" />
      <Frame />
    </div>
  );
}

function Group() {
  return (
    <div className="grid-cols-[max-content] grid-rows-[max-content] inline-grid leading-[normal] not-italic place-items-start relative shrink-0 text-[#130b3d] text-nowrap">
      <p className="[grid-area:1_/_1] font-['Cal_Sans:Regular',sans-serif] ml-0 mt-0 relative text-[19.373px]">Bloom</p>
      <p className="[grid-area:1_/_1] font-['Gebuk:Regular',sans-serif] ml-[55.84px] mt-[1.34px] relative text-[21.708px]">28</p>
    </div>
  );
}

function BrandLogo() {
  return (
    <div className="content-stretch flex gap-[3.464px] items-center justify-center relative shrink-0 w-[229.5px]" data-name="Brand Logo">
      <Group />
    </div>
  );
}

function VuesaxLinearCalendar() {
  return (
    <div className="absolute contents inset-0" data-name="vuesax/linear/calendar">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="calendar">
          <path d="M8 2V5" id="Vector" stroke="var(--stroke-0, #130B3D)" strokeLinecap="round" strokeLinejoin="round" strokeMiterlimit="10" strokeWidth="1.5" />
          <path d="M16 2V5" id="Vector_2" stroke="var(--stroke-0, #130B3D)" strokeLinecap="round" strokeLinejoin="round" strokeMiterlimit="10" strokeWidth="1.5" />
          <path d="M3.5 9.09H20.5" id="Vector_3" stroke="var(--stroke-0, #130B3D)" strokeLinecap="round" strokeLinejoin="round" strokeMiterlimit="10" strokeWidth="1.5" />
          <path d={svgPaths.pb7b9300} id="Vector_4" stroke="var(--stroke-0, #130B3D)" strokeLinecap="round" strokeLinejoin="round" strokeMiterlimit="10" strokeWidth="1.5" />
          <g id="Vector_5" opacity="0"></g>
          <path d="M15.6947 13.7H15.7037" id="Vector_6" stroke="var(--stroke-0, #130B3D)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
          <path d="M15.6947 16.7H15.7037" id="Vector_7" stroke="var(--stroke-0, #130B3D)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
          <path d="M11.9955 13.7H12.0045" id="Vector_8" stroke="var(--stroke-0, #130B3D)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
          <path d="M11.9955 16.7H12.0045" id="Vector_9" stroke="var(--stroke-0, #130B3D)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
          <path d="M8.29431 13.7H8.30329" id="Vector_10" stroke="var(--stroke-0, #130B3D)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
          <path d="M8.29431 16.7H8.30329" id="Vector_11" stroke="var(--stroke-0, #130B3D)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
        </g>
      </svg>
    </div>
  );
}

function VuesaxLinearCalendar1() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="vuesax/linear/calendar">
      <VuesaxLinearCalendar />
    </div>
  );
}

function NotifCalender() {
  return (
    <div className="content-stretch flex items-center justify-end relative shrink-0" data-name="Notif + Calender">
      <VuesaxLinearCalendar1 />
    </div>
  );
}

function TitlePage() {
  return (
    <div className="content-stretch flex items-center justify-between relative shrink-0 w-[345px]" data-name="Title page">
      <ProfilePicture />
      <BrandLogo />
      <NotifCalender />
    </div>
  );
}

function TitleSection() {
  return (
    <div className="bg-gradient-to-b content-stretch flex from-[#ef932d] items-center pb-[16px] pt-[24px] px-[24px] relative shrink-0 to-[#ffe0c6] w-[393px]" data-name="Title Section">
      <TitlePage />
    </div>
  );
}

function Today() {
  return (
    <div className="absolute left-[110.47px] size-[21.382px] top-[187.98px]" data-name="Today">
      <div className="absolute flex items-center justify-center left-0 size-[21.382px] top-0">
        <div className="flex-none rotate-[180deg] scale-y-[-100%]">
          <div className="relative size-[21.382px]">
            <div className="absolute inset-[-17.5%_-22.5%_-27.5%_-22.5%]">
              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 31 31">
                <g filter="url(#filter0_d_30_2793)" id="Ellipse 2615">
                  <circle cx="15.5018" cy="14.4327" fill="var(--fill-0, white)" r="10.6909" />
                  <circle cx="15.5018" cy="14.4327" r="10.0227" stroke="url(#paint0_linear_30_2793)" strokeWidth="1.33636" />
                </g>
                <defs>
                  <filter colorInterpolationFilters="sRGB" filterUnits="userSpaceOnUse" height="31.0036" id="filter0_d_30_2793" width="31.0036" x="0" y="0">
                    <feFlood floodOpacity="0" result="BackgroundImageFix" />
                    <feColorMatrix in="SourceAlpha" result="hardAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" />
                    <feMorphology in="SourceAlpha" operator="dilate" radius="0.534545" result="effect1_dropShadow_30_2793" />
                    <feOffset dy="1.06909" />
                    <feGaussianBlur stdDeviation="2.13818" />
                    <feComposite in2="hardAlpha" operator="out" />
                    <feColorMatrix type="matrix" values="0 0 0 0 0.992157 0 0 0 0 0.345098 0 0 0 0 0.478431 0 0 0 0.12 0" />
                    <feBlend in2="BackgroundImageFix" mode="normal" result="effect1_dropShadow_30_2793" />
                    <feBlend in="SourceGraphic" in2="effect1_dropShadow_30_2793" mode="normal" result="shape" />
                  </filter>
                  <linearGradient gradientUnits="userSpaceOnUse" id="paint0_linear_30_2793" x1="29.6376" x2="-1.72242" y1="23.5794" y2="3.74182">
                    <stop stopColor="#EF932D" />
                    <stop offset="1" stopColor="#C294EC" />
                  </linearGradient>
                </defs>
              </svg>
            </div>
          </div>
        </div>
      </div>
      <p className="absolute font-['Poppins:Medium',sans-serif] leading-[14.255px] left-[calc(50%-4.59px)] not-italic text-[#f58020] text-[10.691px] text-nowrap top-[calc(50%-6.82px)]">14</p>
    </div>
  );
}

function CycleDays() {
  return (
    <div className="absolute left-[7.13px] rounded-[320.727px] size-[199.564px] top-[7.13px]" data-name="Cycle days">
      <CycleDaysDays additionalClassNames="left-[196px] top-[76.62px]" />
      <CycleDaysDays additionalClassNames="left-[197.78px] top-[99.78px]" />
      <CycleDaysDays additionalClassNames="left-[195.11px] top-[121.16px]" />
      <div className="absolute left-[1.78px] size-[3.564px] top-[1.78px]" data-name="Days">
        <div className="absolute inset-[-12.5%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 5 5">
            <circle cx="2.22727" cy="2.22727" fill="url(#paint0_linear_30_2828)" id="Days" r="1.78182" stroke="url(#paint1_linear_30_2828)" strokeDasharray="1.78 19.6" strokeWidth="0.890909" />
            <defs>
              <linearGradient gradientUnits="userSpaceOnUse" id="paint0_linear_30_2828" x1="4.58323" x2="-0.643434" y1="3.75172" y2="0.445454">
                <stop stopColor="#EF932D" />
                <stop offset="1" stopColor="#F58020" />
              </linearGradient>
              <linearGradient gradientUnits="userSpaceOnUse" id="paint1_linear_30_2828" x1="4.58323" x2="-0.643434" y1="3.75172" y2="0.445454">
                <stop stopColor="#FFCCD5" />
                <stop offset="1" stopColor="#C294EC" />
              </linearGradient>
            </defs>
          </svg>
        </div>
      </div>
      <div className="absolute left-[122.05px] size-[3.564px] top-[0.89px]" data-name="Days">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 4 4">
          <circle cx="1.78182" cy="1.78182" fill="url(#paint0_linear_30_2803)" id="Days" r="1.78182" />
          <defs>
            <linearGradient gradientUnits="userSpaceOnUse" id="paint0_linear_30_2803" x1="4.13778" x2="-1.08889" y1="3.30626" y2="-1.90365e-07">
              <stop stopColor="#EF932D" />
              <stop offset="1" stopColor="#F58020" />
            </linearGradient>
          </defs>
        </svg>
      </div>
      <CycleDaysDays additionalClassNames="left-[143.44px] top-[8.91px]" />
      <CycleDaysDays additionalClassNames="left-[162.15px] top-[21.38px]" />
      <CycleDaysDays additionalClassNames="left-[177.29px] top-[37.42px]" />
      <CycleDaysDays additionalClassNames="left-[188.87px] top-[57.02px]" />
      <CycleDaysDays additionalClassNames="left-[187.98px] top-[142.55px]" />
      <CycleDaysDays additionalClassNames="left-[176.4px] top-[160.36px]" />
      <CycleDaysDays additionalClassNames="left-[160.36px] top-[176.4px]" />
      <CycleDaysDays additionalClassNames="left-[141.65px] top-[187.98px]" />
      <CycleDaysDays additionalClassNames="left-[121.16px] top-[195.11px]" />
      <CycleDaysDays additionalClassNames="left-[98.89px] top-[197.78px]" />
      <CycleDaysDays additionalClassNames="left-[76.62px] top-[196px]" />
      <CycleDaysDays additionalClassNames="left-[56.13px] top-[188.87px]" />
      <CycleDaysDays additionalClassNames="left-[36.53px] top-[176.4px]" />
      <CycleDaysDays additionalClassNames="left-[21.38px] top-[162.15px]" />
      <CycleDaysDays additionalClassNames="left-[8.91px] top-[143.44px]" />
      <CycleDaysDays additionalClassNames="left-[0.89px] top-[122.05px]" />
      <CycleDaysDays additionalClassNames="left-[-1.78px] top-[99.78px]" />
      <CycleDaysDays additionalClassNames="left-0 top-[77.51px]" />
      <CycleDaysDays additionalClassNames="left-[8.02px] top-[55.24px]" />
      <CycleDaysDays additionalClassNames="left-[19.6px] top-[36.53px]" />
      <CycleDaysDays additionalClassNames="left-[35.64px] top-[20.49px]" />
      <CycleDaysDays additionalClassNames="left-[56.13px] top-[7.13px]" />
      <CycleDaysDays additionalClassNames="left-[77.51px] top-0" />
      <CycleDaysDays additionalClassNames="left-[98px] top-[-1.78px]" />
      <Today />
    </div>
  );
}

function Wave() {
  return (
    <div className="absolute left-[35.64px] rounded-[231.636px] size-[142.545px] top-[35.64px]" data-name="Wave">
      <div className="overflow-clip relative rounded-[inherit] size-full">
        <Wrapper additionalClassNames="left-[-509.6px]">
          <g id="4" style={{ mixBlendMode: "multiply" }}>
            <path d={svgPaths.p2467b500} fill="var(--fill-0, #FFE0C6)" />
          </g>
        </Wrapper>
        <Wrapper additionalClassNames="left-[-336.76px]">
          <g id="3" style={{ mixBlendMode: "multiply" }}>
            <path d={svgPaths.p27fc73c0} fill="#FFE0C6" />
          </g>
        </Wrapper>
        <div className="absolute flex h-[137.2px] items-center justify-center left-[-1033.45px] mix-blend-multiply top-[41.87px] w-[1533.254px]">
          <div className="flex-none rotate-[180deg] scale-y-[-100%]">
            <WaveHelper />
          </div>
        </div>
        <div className="absolute flex h-[137.2px] items-center justify-center left-[-1118.98px] mix-blend-multiply top-[81.07px] w-[1533.254px]">
          <div className="flex-none rotate-[180deg] scale-y-[-100%]">
            <WaveHelper />
          </div>
        </div>
        <p className="absolute font-['Ninetea:Medium',sans-serif] leading-[17.818px] left-[calc(50%-31.45px)] not-italic text-[#130b3d] text-[12.473px] text-nowrap top-[39.2px]">Ovulation</p>
        <p className="absolute font-['Poppins:Bold',sans-serif] leading-[24.945px] left-[calc(50%-30.56px)] not-italic text-[17.818px] text-white top-[73.05px] w-[60.582px]">Day 14</p>
      </div>
      <div aria-hidden="true" className="absolute border-[#eadbf9] border-[0.891px] border-solid inset-[-0.446px] pointer-events-none rounded-[232.082px]" />
    </div>
  );
}

function Cycle() {
  return (
    <div className="relative rounded-[320.727px] shrink-0 size-[213.818px]" data-name="Cycle">
      <div aria-hidden="true" className="absolute border-[#fad1a3] border-[14.255px] border-solid inset-0 pointer-events-none rounded-[320.727px]" />
      <CycleDays />
      <Wave />
    </div>
  );
}

function PredicationCycle() {
  return (
    <div className="content-stretch flex flex-col gap-[14.255px] items-center relative shrink-0 w-[213.818px]" data-name="Predication + Cycle">
      <p className="font-['Ninetea:Medium',sans-serif] leading-[17.818px] min-w-full not-italic relative shrink-0 text-[#130b3d] text-[12.473px] text-center w-[min-content]">Next period in 5 days</p>
      <Cycle />
    </div>
  );
}

function Indicator() {
  return <div className="absolute bg-[#ef932d] h-[71.273px] left-[calc(50%-0.57px)] rounded-[7.127px] top-[calc(50%+0.18px)] translate-x-[-50%] translate-y-[-50%] w-[52.564px]" data-name="Indicator" />;
}

function Today1() {
  return (
    <div className="content-stretch flex flex-col font-['Poppins:Medium',sans-serif] gap-[1.782px] items-center leading-[0] not-italic relative shrink-0 text-[#f5ebc3] text-center" data-name="Today">
      <div className="flex flex-col h-[21.382px] justify-center relative shrink-0 text-[17.818px] w-full">
        <p className="leading-[21.382px]">21</p>
      </div>
      <div className="flex flex-col h-[12.473px] justify-center relative shrink-0 text-[12.473px] w-full">
        <p className="leading-[17.818px]">Ju</p>
      </div>
    </div>
  );
}

function DateSection() {
  return (
    <div className="content-stretch flex items-start justify-between relative shrink-0 w-full" data-name="Date Section">
      <Indicator />
      <DateDay text="18" text1="Lu" />
      <DateDay text="19" text1="Ma" />
      <DateDay text="20" text1="Mie" />
      <Today1 />
      <DateDay text="22" text1="Vi" />
      <DateDay text="23" text1="Sa" />
      <DateDay text="24" text1="Do" />
    </div>
  );
}

function Calender() {
  return (
    <div className="content-stretch flex flex-col items-center relative shrink-0 w-[307.364px]" data-name="Calender">
      <DateSection />
    </div>
  );
}

function CycleCalender() {
  return (
    <div className="content-stretch flex flex-col gap-[42.764px] items-center relative shrink-0 w-full" data-name="cycle + calender">
      <PredicationCycle />
      <Calender />
    </div>
  );
}

function Btns() {
  return (
    <div className="content-stretch flex gap-[3.564px] items-center justify-center px-[21.382px] py-[10.691px] relative rounded-[21.382px] shrink-0 w-[148.782px]" data-name="BTNS">
      <div aria-hidden="true" className="absolute border-[#f58020] border-[0.891px] border-solid inset-0 pointer-events-none rounded-[21.382px]" />
      <p className="font-['Ninetea:Medium',sans-serif] leading-[21.382px] not-italic relative shrink-0 text-[#f58020] text-[12.473px] text-center text-nowrap" dir="auto">
        Sintomas
      </p>
    </div>
  );
}

function Btns1() {
  return (
    <div className="bg-[#f58020] content-stretch flex gap-[3.564px] items-center justify-center px-[21.382px] py-[10.691px] relative rounded-[21.382px] shrink-0 w-[148.782px]" data-name="BTNS">
      <p className="font-['Ninetea:Medium',sans-serif] leading-[21.382px] not-italic relative shrink-0 text-[12.473px] text-center text-nowrap text-white" dir="auto">
        Periodo
      </p>
    </div>
  );
}

function Buttons() {
  return (
    <div className="content-stretch flex gap-[10.691px] items-center relative shrink-0 w-full" data-name="Buttons">
      <Btns />
      <Btns1 />
    </div>
  );
}

function CycleSection() {
  return (
    <div className="content-stretch flex flex-col gap-[49.891px] items-start relative shrink-0 w-[307.364px]" data-name="cycle section">
      <CycleCalender />
      <Buttons />
    </div>
  );
}

function Frame1() {
  return (
    <div className="content-stretch flex flex-col gap-[7.127px] items-center relative shrink-0 w-full">
      <TitleSection />
      <CycleSection />
    </div>
  );
}

function Frame2() {
  return (
    <div className="absolute content-stretch flex flex-col h-[767.964px] items-start left-px top-[74px] w-[392px]">
      <Frame1 />
    </div>
  );
}

function HomeIndicator() {
  return (
    <div className="absolute bottom-0 h-[34px] left-1/2 translate-x-[-50%] w-[393px]" data-name="Home Indicator">
      <div className="absolute h-[34px] left-0 right-0 top-0" data-name="Background" />
      <div className="absolute bottom-[7.67px] flex h-[5px] items-center justify-center left-1/2 translate-x-[-50%] w-[139.938px]">
        <div className="flex-none rotate-[180deg] scale-y-[-100%]">
          <div className="bg-[#121212] h-[5px] rounded-[100px] w-[139.938px]" data-name="Home Indicator" />
        </div>
      </div>
    </div>
  );
}

function IOsIconSmallMobileSignal() {
  return (
    <div className="h-[16px] relative shrink-0 w-[20px]" data-name="iOS / icon / small / Mobile Signal">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 16">
        <g id="iOS / icon / small / Mobile Signal">
          <path d={svgPaths.p15d4ae30} fill="var(--fill-0, #121212)" id="icon" />
        </g>
      </svg>
    </div>
  );
}

function IOsIconSmallWifi() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="iOS / icon / small / Wifi">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="iOS / icon / small / Wifi">
          <path d={svgPaths.p382fcb80} fill="var(--fill-0, #121212)" id="icon" />
        </g>
      </svg>
    </div>
  );
}

function IOsIconSmallBattery() {
  return (
    <div className="h-[16px] relative shrink-0 w-[25px]" data-name="iOS / icon / small / battery">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 25 16">
        <g clipPath="url(#clip0_25_2056)" id="iOS / icon / small / battery">
          <path d={svgPaths.p15509f50} id="outline border" opacity="0.35" stroke="var(--stroke-0, #121212)" />
          <path d={svgPaths.p307e0200} fill="var(--fill-0, #121212)" id="node" opacity="0.4" />
          <path d={svgPaths.p365f7580} fill="var(--fill-0, #121212)" id="charge" />
        </g>
        <defs>
          <clipPath id="clip0_25_2056">
            <rect fill="white" height="16" width="25" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function IOsIconStatusBar() {
  return (
    <div className="absolute content-stretch flex gap-[2px] items-start right-[15px] top-[15px]" data-name="iOS / icon / status-bar">
      <IOsIconSmallMobileSignal />
      <IOsIconSmallWifi />
      <IOsIconSmallBattery />
    </div>
  );
}

function StatusBar() {
  return (
    <div className="absolute h-[44px] left-0 overflow-clip top-0 w-[393px]" data-name="Status bar">
      <div className="absolute h-[30px] left-1/2 top-[-2px] translate-x-[-50%] w-[219px]" data-name="notch">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 219 30">
          <path d={svgPaths.p7f98200} fill="var(--fill-0, #121212)" id="notch" />
        </svg>
      </div>
      <p className="absolute font-['SF_Pro_Text:Semibold',sans-serif] leading-[21px] left-[32px] not-italic text-[#121212] text-[15px] text-nowrap top-[13px] tracking-[-0.32px]">9:41</p>
      <IOsIconStatusBar />
    </div>
  );
}

export default function Perfil() {
  return (
    <div className="bg-gradient-to-b from-[#ffe0c6] overflow-clip relative rounded-[32px] size-full to-[#f5ebc3]" data-name="perfil">
      <div className="absolute flex inset-[3.29%_-26.93%_65.95%_67.18%] items-center justify-center">
        <div className="flex-none h-[199.256px] rotate-[230.904deg] skew-x-[15.084deg] w-[189.917px]">
          <div className="relative size-full">
            <div className="absolute inset-[-75.28%_-78.98%]">
              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 490 500">
                <g filter="url(#filter0_f_30_2789)" id="Ellipse 7" opacity="0.8">
                  <ellipse cx="244.958" cy="249.628" fill="var(--fill-0, #FD587A)" fillOpacity="0.24" rx="94.9584" ry="99.6278" />
                </g>
                <defs>
                  <filter colorInterpolationFilters="sRGB" filterUnits="userSpaceOnUse" height="499.256" id="filter0_f_30_2789" width="489.917" x="0" y="0">
                    <feFlood floodOpacity="0" result="BackgroundImageFix" />
                    <feBlend in="SourceGraphic" in2="BackgroundImageFix" mode="normal" result="shape" />
                    <feGaussianBlur result="effect1_foregroundBlur_30_2789" stdDeviation="75" />
                  </filter>
                </defs>
              </svg>
            </div>
          </div>
        </div>
      </div>
      <p className="absolute font-['Ninetea:Semi_Bold',sans-serif] leading-[21.955px] left-[134px] not-italic text-[#130b3d] text-[15.368px] text-nowrap top-[590px]">Métricas de Hoy</p>
      <Frame2 />
      <div className="absolute bg-[#fcefdd] h-[124.455px] left-[25px] rounded-[17px] top-[621px] w-[103.842px]" />
      <div className="absolute bg-gradient-to-b from-[#ef932d] h-[137px] left-[25px] rounded-[17px] to-[#ffe0c6] top-[822px] w-[343px]" />
      <div className="absolute bg-[#fcefdd] h-[43px] left-[25px] rounded-[67px] top-[762px] w-[343px]" />
      <div className="absolute bg-gradient-to-l from-[#ef932d] h-[43px] left-[25px] rounded-[67px] to-[#2271b8] top-[762px] w-[285px]" />
      <div className="absolute bg-[#fcefdd] h-[124.455px] left-[144px] rounded-[17px] top-[621px] w-[103.842px]" />
      <div className="absolute bg-[#fcefdd] h-[124.455px] left-[264px] rounded-[17px] top-[621px] w-[103.842px]" />
      <div className="absolute font-['Ninetea:Semi_Bold',sans-serif] leading-[12.8px] left-[calc(50%-120.5px)] not-italic text-[#ef932d] text-[12.473px] text-center text-nowrap top-[711px] translate-x-[-50%]">
        <p className="mb-0">Temperatura</p>
        <p>Basal</p>
      </div>
      <p className="absolute font-['Ninetea:Semi_Bold',sans-serif] h-[7px] leading-[12.8px] left-[calc(50%-70px)] not-italic text-[#130b3d] text-[22.47px] text-center top-[844px] translate-x-[-50%] w-[161px]">Insight del Día</p>
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal h-[69px] leading-[16.8px] left-[calc(50%-150.5px)] not-italic text-[#130b3d] text-[12.473px] top-[874px] w-[306px]">Tu temperatura basal esta aumentando, lo que sugiere que te acercas a la ovulación. Excelente momento para ejercicios de alta intensidad y consumo de proteína magra.</p>
      <IconexLightFire className="absolute inset-[83.13%_10.43%_14.38%_83.46%]" />
      <p className="absolute font-['Ninetea:Bold',sans-serif] leading-[12.8px] left-[calc(50%-115.5px)] not-italic text-[#130b3d] text-[0px] text-center text-nowrap top-[664px] translate-x-[-50%]">
        <span className="text-[35.47px]">36°</span>
        <span className="font-['Ninetea:Semi_Bold',sans-serif] text-[27.47px]">c</span>
      </p>
      <p className="absolute font-['Ninetea:Bold',sans-serif] leading-[12.8px] left-[calc(50%-1px)] not-italic text-[#130b3d] text-[35.47px] text-center text-nowrap top-[664px] translate-x-[-50%]">68</p>
      <p className="absolute font-['Ninetea:Bold',sans-serif] leading-[12.8px] left-[calc(50%+120px)] not-italic text-[#130b3d] text-[35.47px] text-center text-nowrap top-[664px] translate-x-[-50%]">85%</p>
      <div className="absolute font-['Ninetea:Semi_Bold',sans-serif] leading-[12.8px] left-[calc(50%-2px)] not-italic text-[#ef932d] text-[12.473px] text-center text-nowrap top-[711px] translate-x-[-50%]">
        <p className="mb-0">Frecuencia</p>
        <p>Cardíaca</p>
      </div>
      <p className="absolute font-['Ninetea:Medium',sans-serif] leading-[12.8px] left-[calc(50%-0.5px)] not-italic text-[#130b3d] text-[8.47px] text-center text-nowrap top-[687px] translate-x-[-50%]">BPM</p>
      <p className="absolute font-['Ninetea:Medium',sans-serif] leading-[12.8px] left-[calc(50%+121px)] not-italic text-[#130b3d] text-[8.47px] text-center text-nowrap top-[687px] translate-x-[-50%]">8 horas</p>
      <div className="absolute font-['Ninetea:Semi_Bold',sans-serif] leading-[12.8px] left-[calc(50%+120.5px)] not-italic text-[#ef932d] text-[12.473px] text-center text-nowrap top-[711px] translate-x-[-50%]">
        <p className="mb-0">Calidad</p>
        <p>del Sueño</p>
      </div>
      <p className="absolute font-['Ninetea:Semi_Bold',sans-serif] leading-[17.818px] left-[calc(50%-104px)] not-italic text-[#fbeedc] text-[12.473px] text-center text-nowrap top-[775px] translate-x-[-50%]">Nivel De Energía</p>
      <p className="absolute font-['Ninetea:Semi_Bold',sans-serif] leading-[17.818px] left-[calc(50%+82px)] not-italic text-[#fbeedc] text-[12.473px] text-center text-nowrap top-[775px] translate-x-[-50%]">85%</p>
      <IconexLightHeart additionalClassNames="inset-[62.4%_87.81%_36.23%_7.61%]" />
      <IconexLightHeart additionalClassNames="inset-[62.4%_57.02%_36.23%_38.4%]" />
      <IconexLightHeart additionalClassNames="inset-[62.55%_25.98%_36.08%_69.44%]" />
      <HomeIndicator />
      <StatusBar />
    </div>
  );
}
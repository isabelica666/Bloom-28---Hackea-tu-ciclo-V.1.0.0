import svgPaths from "./svg-tqfrqrn5ii";
import clsx from "clsx";
type IconexLightShareHelperProps = {
  additionalClassNames?: string;
};

function IconexLightShareHelper({ additionalClassNames = "" }: IconexLightShareHelperProps) {
  return (
    <div className={clsx("absolute size-[12.5px]", additionalClassNames)}>
      <div className="absolute inset-[-15%]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 17 17">
          <circle cx="8.125" cy="8.125" id="Ellipse 44" r="6.25" stroke="var(--stroke-0, #2B3F6C)" strokeWidth="3.75" />
        </svg>
      </div>
    </div>
  );
}

function IconexLightHeartbeat({ className }: { className?: string }) {
  return (
    <div className={className} data-name="Iconex/Light/Heartbeat">
      <div className="absolute contents left-[2px] top-[2px]" data-name="Heartbeat">
        <div className="absolute left-[2px] rounded-[5px] size-[20px] top-[2px]">
          <div aria-hidden="true" className="absolute border-[#2b3f6c] border-[1.5px] border-solid inset-[-0.75px] pointer-events-none rounded-[5.75px]" />
        </div>
        <div className="absolute bottom-[33.33%] flex items-center justify-center left-1/4 right-1/4 top-[37.5%]">
          <div className="flex-none h-[7px] rotate-[180deg] w-[12px]">
            <div className="relative size-full" data-name="Line">
              <div className="absolute inset-[-10.71%_-6.25%]">
                <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 9">
                  <path d={svgPaths.pfc0bc90} id="Line" stroke="var(--stroke-0, #2B3F6C)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
                </svg>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function IconexLightLightning({ className }: { className?: string }) {
  return (
    <div className={className} data-name="Iconex/Light/Lightning">
      <div className="absolute contents left-[5px] top-[2px]" data-name="Lightning">
        <div className="absolute h-[20px] left-[5px] top-[2px] w-[14px]" data-name="Union">
          <div className="absolute inset-[-1.74%_-1.84%]">
            <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 15 21">
              <path d={svgPaths.p31ae2300} id="Union" stroke="var(--stroke-0, #2B3F6C)" strokeWidth="1.5" />
            </svg>
          </div>
        </div>
      </div>
    </div>
  );
}

function IconexLightHeart({ className }: { className?: string }) {
  return (
    <div className={className} data-name="Iconex/Light/Heart">
      <div className="absolute h-[19px] left-[2px] top-[3px] w-[20px]" data-name="Heart">
        <div className="absolute inset-[-3.95%_-3.75%_3.2%_-3.75%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 22 20">
            <path d={svgPaths.p1bae4400} id="Heart" stroke="var(--stroke-0, #2B3F6C)" strokeWidth="1.5" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function IconexLightShare({ className }: { className?: string }) {
  return (
    <div className={className} data-name="Iconex/Light/Share">
      <div className="absolute contents left-[7.5px] top-[5px]" data-name="Share">
        <IconexLightShareHelper additionalClassNames="left-[37.5px] top-[5px]" />
        <IconexLightShareHelper additionalClassNames="left-[7.5px] top-[22.5px]" />
        <div className="absolute flex inset-[18.75%_37.5%_52.08%_33.33%] items-center justify-center">
          <div className="flex-none h-[5.303px] rotate-[315deg] scale-y-[-100%] w-[19.445px]">
            <div className="relative size-full" data-name="Line">
              <div className="absolute inset-[-35.36%_-9.64%]">
                <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 10">
                  <path d={svgPaths.p2508ed00} id="Line" stroke="var(--stroke-0, #2B3F6C)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="3.75" />
                </svg>
              </div>
            </div>
          </div>
        </div>
        <div className="absolute bottom-[18.75%] flex items-center justify-center left-[31.25%] right-[37.5%] top-1/2">
          <div className="flex-none h-[5.303px] rotate-[225deg] w-[21.213px]">
            <div className="relative size-full" data-name="Line">
              <div className="absolute inset-[-35.36%_-8.84%]">
                <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 25 10">
                  <path d={svgPaths.p1135f200} id="Line" stroke="var(--stroke-0, #2B3F6C)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="3.75" />
                </svg>
              </div>
            </div>
          </div>
        </div>
        <IconexLightShareHelper additionalClassNames="left-[37.5px] top-[42.5px]" />
      </div>
    </div>
  );
}

function VuesaxLinearArrowSquareLeft() {
  return (
    <div className="absolute contents inset-0" data-name="vuesax/linear/arrow-square-left">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 40 40">
        <g id="arrow-square-left">
          <path d={svgPaths.p3647d300} id="Vector" stroke="var(--stroke-0, #BDBDBD)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d={svgPaths.pe03b900} id="Vector_2" stroke="var(--stroke-0, #292929)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <g id="Vector_3" opacity="0"></g>
        </g>
      </svg>
    </div>
  );
}

function VuesaxLinearArrowSquareLeft1() {
  return (
    <div className="relative shrink-0 size-[40px]" data-name="vuesax/linear/arrow-square-left">
      <VuesaxLinearArrowSquareLeft />
    </div>
  );
}

function Frame2() {
  return (
    <div className="absolute content-stretch flex items-center justify-center left-[40px] top-[8px] w-[265px]">
      <div className="basis-0 flex flex-col font-['Poppins:Medium',sans-serif] grow justify-center leading-[0] min-h-px min-w-px not-italic relative shrink-0 text-[#121212] text-[18px] text-center">
        <p className="leading-[24px]">&nbsp;</p>
      </div>
    </div>
  );
}

function TitleSection() {
  return (
    <div className="content-stretch flex h-[40px] items-center justify-between px-0 py-px relative shrink-0 w-[345px]" data-name="Title Section">
      <VuesaxLinearArrowSquareLeft1 />
      <Frame2 />
    </div>
  );
}

function Frame() {
  return (
    <div className="content-stretch flex flex-col items-center justify-center relative shrink-0 w-full">
      <TitleSection />
    </div>
  );
}

function Frame1() {
  return (
    <div className="absolute content-stretch flex flex-col items-start left-[24px] top-[68px] w-[345px]">
      <Frame />
    </div>
  );
}

function RegisterButton() {
  return (
    <div className="absolute contents left-[calc(50%+0.3px)] top-[750px] translate-x-[-50%]" data-name="Register (Button)">
      <div className="absolute bg-[#f58020] inset-[88.03%_6.72%_5.75%_6.87%] rounded-[30.943px]" />
      <p className="absolute font-['Ninetea:Semi_Bold',sans-serif] h-[22px] leading-[normal] left-[calc(50%-2px)] not-italic text-[#fbeedc] text-[16.878px] text-center top-[767px] translate-x-[-50%] w-[195px]">Conectar Dispositivo</p>
      <div className="absolute h-[12px] left-[290.9px] top-[772px] w-[5.477px]">
        <div className="absolute inset-[-5.62%_-5.33%_-5.62%_-13.48%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 7 14">
            <path d={svgPaths.p1773d800} id="Vector 33" stroke="var(--stroke-0, #FBEEDC)" strokeWidth="2" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Text() {
  return (
    <div className="absolute contents left-[27px] right-[26px] top-[128px]" data-name="Text">
      <div className="absolute font-['Ninetea:Bold',sans-serif] h-[92px] leading-[1.3] left-[27px] not-italic right-[26px] text-[#fbeedc] text-[0px] text-center top-[128px] tracking-[-0.34px]">
        <p className="mb-[2.250382423400879px] text-[#f58020] text-[30px]">Conectar Wearable</p>
        <p className="font-['Inter:Regular',sans-serif] font-normal text-[#130b3d] text-[14px]">Obtén datos mas precisos conectando tu dispositivo</p>
      </div>
    </div>
  );
}

function Group() {
  return (
    <div className="absolute contents left-[27px] right-[26px] top-[128px]">
      <Text />
    </div>
  );
}

function EnterYourEmailInput() {
  return (
    <div className="absolute contents left-[140.56px] top-[221px]" data-name="Enter your email (Input)">
      <div className="absolute bg-[#fcf1dd] border-[#fbeedc] border-[0.952px] border-solid left-[140.56px] rounded-[149.71px] size-[115.001px] top-[221px]" />
    </div>
  );
}

function EnterYourEmailInput1() {
  return (
    <div className="absolute contents left-0 top-[361.75px]" data-name="Enter your email (Input)">
      <IconexLightLightning className="absolute inset-[67.02%_81.68%_30.16%_12.21%]" />
      <IconexLightHeartbeat className="absolute inset-[60.68%_81.68%_36.5%_12.21%]" />
      <div className="absolute bg-[#fcf1dd] border-[#fbeedc] border-[1.125px] border-solid h-[274.349px] left-[33px] rounded-[30.943px] top-[361.75px] w-[335.562px]" />
      <div className="absolute flex flex-col font-['Ninetea:Bold',sans-serif] h-[17px] justify-end leading-[0] left-[196.5px] not-italic text-[#130b3d] text-[15.63px] text-center top-[408px] translate-x-[-50%] translate-y-[-100%] w-[393px]">
        <p className="leading-[1.25]">Por qué conectar un wearable?</p>
      </div>
      <div className="absolute flex flex-col font-['Ninetea:Bold',sans-serif] h-[17px] justify-end leading-[0] left-[83px] not-italic text-[#f58020] text-[15.63px] top-[450px] translate-y-[-100%] w-[263px]">
        <p className="leading-[1.25]">Frecuencia Cardíaca</p>
      </div>
      <div className="absolute flex flex-col font-['Ninetea:Bold',sans-serif] h-[17px] justify-end leading-[0] left-[83px] not-italic text-[#f58020] text-[15.63px] top-[526px] translate-y-[-100%] w-[263px]">
        <p className="leading-[1.25]">Temperatura Basal</p>
      </div>
      <div className="absolute flex flex-col font-['Ninetea:Bold',sans-serif] h-[17px] justify-end leading-[0] left-[83px] not-italic text-[#f58020] text-[15.63px] top-[583px] translate-y-[-100%] w-[263px]">
        <p className="leading-[1.25]">Actividad y Sueño</p>
      </div>
      <div className="absolute flex flex-col font-['Inter:Medium',sans-serif] font-medium h-[17px] justify-end leading-[0] left-[83px] not-italic text-[#130b3d] text-[13.63px] top-[488px] translate-y-[-100%] w-[273px]">
        <p className="leading-[1.25]">Monitorea cambios relacionados con tu ciclo</p>
      </div>
      <div className="absolute flex flex-col font-['Inter:Medium',sans-serif] font-medium h-[17px] justify-end leading-[0] left-[83px] not-italic text-[#130b3d] text-[13.63px] top-[545px] translate-y-[-100%] w-[273px]">
        <p className="leading-[1.25]">Predicciones más precisas de oculación</p>
      </div>
      <div className="absolute flex flex-col font-['Inter:Medium',sans-serif] font-medium h-[17px] justify-end leading-[0] left-[83px] not-italic text-[#130b3d] text-[13.63px] top-[616px] translate-y-[-100%] w-[273px]">
        <p className="leading-[1.25]">Comprende cómo afecta tu ciclo a tu energía</p>
      </div>
      <IconexLightHeart className="absolute inset-[51.88%_81.68%_45.31%_12.21%]" />
    </div>
  );
}

function HomeIndicator() {
  return (
    <div className="absolute bottom-0 h-[34px] left-1/2 translate-x-[-50%] w-[393px]" data-name="Home Indicator">
      <div className="absolute h-[34px] left-0 right-0 top-0" data-name="Background" />
      <div className="absolute bottom-[7.67px] flex h-[5px] items-center justify-center left-1/2 translate-x-[-50%] w-[139.938px]">
        <div className="flex-none rotate-[180deg] scale-y-[-100%]">
          <div className="bg-[#121212] h-[5px] rounded-[100px] w-[139.938px]" data-name="Home Indicator" />
        </div>
      </div>
    </div>
  );
}

function IOsIconSmallMobileSignal() {
  return (
    <div className="h-[16px] relative shrink-0 w-[20px]" data-name="iOS / icon / small / Mobile Signal">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 16">
        <g id="iOS / icon / small / Mobile Signal">
          <path d={svgPaths.p15d4ae30} fill="var(--fill-0, #121212)" id="icon" />
        </g>
      </svg>
    </div>
  );
}

function IOsIconSmallWifi() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="iOS / icon / small / Wifi">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="iOS / icon / small / Wifi">
          <path d={svgPaths.p382fcb80} fill="var(--fill-0, #121212)" id="icon" />
        </g>
      </svg>
    </div>
  );
}

function IOsIconSmallBattery() {
  return (
    <div className="h-[16px] relative shrink-0 w-[25px]" data-name="iOS / icon / small / battery">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 25 16">
        <g clipPath="url(#clip0_24_1287)" id="iOS / icon / small / battery">
          <path d={svgPaths.p15509f50} id="outline border" opacity="0.35" stroke="var(--stroke-0, #121212)" />
          <path d={svgPaths.p307e0200} fill="var(--fill-0, #121212)" id="node" opacity="0.4" />
          <path d={svgPaths.p365f7580} fill="var(--fill-0, #121212)" id="charge" />
        </g>
        <defs>
          <clipPath id="clip0_24_1287">
            <rect fill="white" height="16" width="25" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function IOsIconStatusBar() {
  return (
    <div className="absolute content-stretch flex gap-[2px] items-start right-[15px] top-[15px]" data-name="iOS / icon / status-bar">
      <IOsIconSmallMobileSignal />
      <IOsIconSmallWifi />
      <IOsIconSmallBattery />
    </div>
  );
}

function StatusBar() {
  return (
    <div className="absolute h-[44px] left-0 overflow-clip top-0 w-[393px]" data-name="Status bar">
      <div className="absolute h-[30px] left-1/2 top-[-2px] translate-x-[-50%] w-[219px]" data-name="notch">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 219 30">
          <path d={svgPaths.p7f98200} fill="var(--fill-0, #121212)" id="notch" />
        </svg>
      </div>
      <p className="absolute font-['SF_Pro_Text:Semibold',sans-serif] leading-[21px] left-[32px] not-italic text-[#121212] text-[15px] text-nowrap top-[13px] tracking-[-0.32px]">9:41</p>
      <IOsIconStatusBar />
    </div>
  );
}

export default function ConectarWeareable() {
  return (
    <div className="bg-gradient-to-b from-[#ffe0c6] overflow-clip relative rounded-[32px] size-full to-[#f5ebc3]" data-name="conectar weareable">
      <StatusBar />
      <div className="absolute flex inset-[3.29%_-26.93%_65.95%_67.18%] items-center justify-center">
        <div className="flex-none h-[179.29px] rotate-[226.129deg] skew-x-[6.174deg] w-[172.813px]">
          <div className="relative size-full">
            <div className="absolute inset-[-83.66%_-86.8%]">
              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 473 480">
                <g filter="url(#filter0_f_24_1314)" id="Ellipse 7" opacity="0.8">
                  <ellipse cx="236.407" cy="239.645" fill="var(--fill-0, #FD587A)" fillOpacity="0.24" rx="86.4067" ry="89.6449" />
                </g>
                <defs>
                  <filter colorInterpolationFilters="sRGB" filterUnits="userSpaceOnUse" height="479.29" id="filter0_f_24_1314" width="472.813" x="0" y="0">
                    <feFlood floodOpacity="0" result="BackgroundImageFix" />
                    <feBlend in="SourceGraphic" in2="BackgroundImageFix" mode="normal" result="shape" />
                    <feGaussianBlur result="effect1_foregroundBlur_24_1314" stdDeviation="75" />
                  </filter>
                </defs>
              </svg>
            </div>
          </div>
        </div>
      </div>
      <p className="absolute font-['Poppins:Regular',sans-serif] leading-[0] left-[196.5px] not-italic text-[#121212] text-[0px] text-[12px] text-center text-nowrap top-[910px] translate-x-[-50%]">
        <span className="capitalize leading-[1.3]">Already have an Account?</span>
        <span className="leading-[18px]"> </span>
        <span className="capitalize font-['Poppins:Medium',sans-serif] leading-[18px] text-[#3b82f6]">Login</span>
      </p>
      <Frame1 />
      <RegisterButton />
      <Group />
      <div className="absolute h-[57px] left-[24px] top-[648px] w-[345px]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 345 57">
          <path d={svgPaths.pc4dd980} fill="url(#paint0_linear_24_1461)" id="Rectangle 4" opacity="0.5" stroke="var(--stroke-0, #FBEEDC)" strokeWidth="1.12519" />
          <defs>
            <linearGradient gradientUnits="userSpaceOnUse" id="paint0_linear_24_1461" x1="172.964" x2="172.964" y1="57" y2="3.3241">
              <stop stopColor="#FFF2E3" />
              <stop offset="1" stopColor="#F7BE7E" />
            </linearGradient>
          </defs>
        </svg>
      </div>
      <div className="absolute flex flex-col font-['Inter:Regular',sans-serif] font-normal h-[40.539px] justify-end leading-[0] left-[192.33px] not-italic text-[#130b3d] text-[12.63px] text-center top-[694.54px] translate-x-[-50%] translate-y-[-100%] w-[307.903px]">
        <p className="leading-[1.25]">Compatible con Apple Watch, Fitbit, Garmin, Oura Ring, y más</p>
      </div>
      <EnterYourEmailInput />
      <IconexLightShare className="absolute inset-[29.11%_42.24%_63.85%_42.49%]" />
      <EnterYourEmailInput1 />
      <HomeIndicator />
    </div>
  );
}
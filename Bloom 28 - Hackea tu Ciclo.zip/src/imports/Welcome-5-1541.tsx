import svgPaths from "./svg-zr31ynpj7r";

function Group() {
  return (
    <div className="absolute contents leading-[normal] left-[2.3px] not-italic text-[#130b3d] top-[20.84px]">
      <p className="absolute font-['Cal_Sans:Regular',sans-serif] h-[32.912px] left-[2.3px] text-[24.574px] top-[20.84px] w-[72.845px]">Bloom</p>
      <p className="absolute font-['Gebuk:Regular',sans-serif] h-[29.401px] left-[75.14px] text-[27.865px] top-[22.59px] w-[32.473px]">28</p>
    </div>
  );
}

function Group2() {
  return (
    <div className="absolute contents left-[29.49px] top-[-54px]">
      <p className="absolute font-['Gebuk:Regular',sans-serif] h-[76.699px] leading-[normal] left-[29.49px] not-italic text-[#130b3d] text-[84.139px] top-[-54px] w-[84.712px]">8</p>
    </div>
  );
}

function Group1() {
  return (
    <div className="absolute contents left-[2.3px] top-[-54px]">
      <Group />
      <Group2 />
    </div>
  );
}

function PeriaLogo() {
  return (
    <div className="relative shrink-0 size-[104px]" data-name="Peria Logo">
      <Group1 />
    </div>
  );
}

function Frame3() {
  return (
    <div className="content-stretch flex flex-col gap-[40px] h-[269px] items-center justify-center relative shrink-0 w-[287px]">
      <PeriaLogo />
    </div>
  );
}

function Frame() {
  return (
    <div className="content-stretch flex flex-col gap-[8px] items-center justify-center not-italic relative shrink-0 text-center">
      <p className="font-['Ninetea:Bold',sans-serif] leading-[40px] relative shrink-0 text-[#f58020] text-[28px] w-[271px]">
        <span className="text-[#130b3d]">Tu Ciclo,</span>
        <span>{` Tu Poder`}</span>
      </p>
      <p className="font-['Inter:Regular',sans-serif] font-normal leading-[1.3] relative shrink-0 text-[#130b3d] text-[18px] tracking-[-0.18px] w-[271px]">Conecta con tu cuerpo y toma el poder de tu salud menstrual</p>
    </div>
  );
}

function Frame1() {
  return (
    <div className="content-stretch flex flex-col items-center relative shrink-0 w-full">
      <Frame />
    </div>
  );
}

function Frame2() {
  return (
    <div className="content-stretch flex flex-col h-[118px] items-center justify-center relative shrink-0 w-full">
      <Frame1 />
    </div>
  );
}

function Btns() {
  return (
    <div className="bg-[#f58020] relative rounded-[24px] shrink-0 w-full" data-name="BTNS">
      <div className="flex flex-row items-center justify-center size-full">
        <div className="content-stretch flex gap-[4px] items-center justify-center px-[24px] py-[12px] relative w-full">
          <p className="font-['Ninetea:Medium',sans-serif] leading-[24px] not-italic relative shrink-0 text-[14px] text-center text-nowrap text-white whitespace-pre" dir="auto">
            Iniciar Sesión
          </p>
        </div>
      </div>
    </div>
  );
}

function Btns1() {
  return (
    <div className="bg-[rgba(255,255,255,0.42)] relative rounded-[24px] shrink-0 w-full" data-name="BTNS">
      <div aria-hidden="true" className="absolute border border-solid border-white inset-0 pointer-events-none rounded-[24px]" />
      <div className="flex flex-row items-center justify-center size-full">
        <div className="content-stretch flex gap-[4px] items-center justify-center px-[24px] py-[12px] relative w-full">
          <p className="font-['Ninetea:Medium',sans-serif] leading-[24px] not-italic relative shrink-0 text-[#f58020] text-[14px] text-center text-nowrap whitespace-pre" dir="auto">
            Regístrate
          </p>
        </div>
      </div>
    </div>
  );
}

function Frame5() {
  return (
    <div className="content-stretch flex flex-col gap-[8px] items-center justify-center relative shrink-0 w-[345px]">
      <Btns />
      <Btns1 />
    </div>
  );
}

function Frame4() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[36px] items-center justify-center left-[24px] top-[133.5px] w-[345px]">
      <Frame3 />
      <Frame2 />
      <Frame5 />
    </div>
  );
}

function IOsIconSmallMobileSignal() {
  return (
    <div className="h-[16px] relative shrink-0 w-[20px]" data-name="iOS / icon / small / Mobile Signal">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 16">
        <g id="iOS / icon / small / Mobile Signal">
          <path d={svgPaths.p15d4ae30} fill="var(--fill-0, #121212)" id="icon" />
        </g>
      </svg>
    </div>
  );
}

function IOsIconSmallWifi() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="iOS / icon / small / Wifi">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="iOS / icon / small / Wifi">
          <path d={svgPaths.p382fcb80} fill="var(--fill-0, #121212)" id="icon" />
        </g>
      </svg>
    </div>
  );
}

function IOsIconSmallBattery() {
  return (
    <div className="h-[16px] relative shrink-0 w-[25px]" data-name="iOS / icon / small / battery">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 25 16">
        <g clipPath="url(#clip0_5_1106)" id="iOS / icon / small / battery">
          <path d={svgPaths.p15509f50} id="outline border" opacity="0.35" stroke="var(--stroke-0, #121212)" />
          <path d={svgPaths.p307e0200} fill="var(--fill-0, #121212)" id="node" opacity="0.4" />
          <path d={svgPaths.p365f7580} fill="var(--fill-0, #121212)" id="charge" />
        </g>
        <defs>
          <clipPath id="clip0_5_1106">
            <rect fill="white" height="16" width="25" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function IOsIconStatusBar() {
  return (
    <div className="absolute content-stretch flex gap-[2px] items-start right-[15px] top-[15px]" data-name="iOS / icon / status-bar">
      <IOsIconSmallMobileSignal />
      <IOsIconSmallWifi />
      <IOsIconSmallBattery />
    </div>
  );
}

function StatusBar() {
  return (
    <div className="absolute h-[44px] left-0 overflow-clip top-0 w-[393px]" data-name="Status bar">
      <div className="absolute h-[30px] left-1/2 top-[-2px] translate-x-[-50%] w-[219px]" data-name="notch">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 219 30">
          <path d={svgPaths.p7f98200} fill="var(--fill-0, #121212)" id="notch" />
        </svg>
      </div>
      <p className="absolute font-['SF_Pro_Text:Semibold',sans-serif] leading-[21px] left-[32px] not-italic text-[#121212] text-[15px] text-nowrap top-[13px] tracking-[-0.32px] whitespace-pre">9:41</p>
      <IOsIconStatusBar />
    </div>
  );
}

function HomeIndicator() {
  return (
    <div className="absolute bottom-0 h-[34px] left-1/2 translate-x-[-50%] w-[393px]" data-name="Home Indicator">
      <div className="absolute h-[34px] left-0 right-0 top-0" data-name="Background" />
      <div className="absolute bottom-[7.67px] flex h-[5px] items-center justify-center left-1/2 translate-x-[-50%] w-[139.938px]">
        <div className="flex-none rotate-[180deg] scale-y-[-100%]">
          <div className="bg-[#121212] h-[5px] rounded-[100px] w-[139.938px]" data-name="Home Indicator" />
        </div>
      </div>
    </div>
  );
}

export default function Welcome() {
  return (
    <div className="bg-gradient-to-b from-[#ffe0c6] overflow-clip relative rounded-[32px] size-full to-[#f5ebc3]" data-name="Welcome">
      <HomeIndicator />
      <div className="absolute flex inset-[6.34%_-28.87%_61.76%_66.92%] items-center justify-center">
        <div className="flex-none h-[186.378px] rotate-[226.129deg] skew-x-[6.174deg] w-[178.744px]">
          <div className="relative size-full">
            <div className="absolute inset-[-91.85%_-95.77%]">
              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 522 529">
                <g filter="url(#filter0_f_5_1122)" id="Ellipse 7" opacity="0.8">
                  <ellipse cx="260.561" cy="264.378" fill="var(--fill-0, #FD587A)" fillOpacity="0.24" rx="89.3719" ry="93.1892" />
                </g>
                <defs>
                  <filter colorInterpolationFilters="sRGB" filterUnits="userSpaceOnUse" height="528.755" id="filter0_f_5_1122" width="521.121" x="0" y="0">
                    <feFlood floodOpacity="0" result="BackgroundImageFix" />
                    <feBlend in="SourceGraphic" in2="BackgroundImageFix" mode="normal" result="shape" />
                    <feGaussianBlur result="effect1_foregroundBlur_5_1122" stdDeviation="85.5943" />
                  </filter>
                </defs>
              </svg>
            </div>
          </div>
        </div>
      </div>
      <div className="absolute flex inset-[36.97%_55.73%_24.25%_-44.27%] items-center justify-center">
        <div className="flex-none h-[243.129px] rotate-[221.503deg] skew-x-[356.979deg] w-[236.982px]">
          <div className="relative size-full">
            <div className="absolute inset-[-65.43%_-67.13%]">
              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 556 562">
                <g filter="url(#filter0_f_5_1124)" id="Ellipse 8" opacity="0.8">
                  <ellipse cx="277.579" cy="280.652" fill="var(--fill-0, #C294EC)" fillOpacity="0.44" rx="118.491" ry="121.564" />
                </g>
                <defs>
                  <filter colorInterpolationFilters="sRGB" filterUnits="userSpaceOnUse" height="561.304" id="filter0_f_5_1124" width="555.157" x="0" y="0">
                    <feFlood floodOpacity="0" result="BackgroundImageFix" />
                    <feBlend in="SourceGraphic" in2="BackgroundImageFix" mode="normal" result="shape" />
                    <feGaussianBlur result="effect1_foregroundBlur_5_1124" stdDeviation="79.5438" />
                  </filter>
                </defs>
              </svg>
            </div>
          </div>
        </div>
      </div>
      <Frame4 />
      <StatusBar />
    </div>
  );
}
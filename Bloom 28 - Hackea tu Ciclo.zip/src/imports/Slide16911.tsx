export default function Slide() {
  return (
    <div className="relative size-full" data-name="Slide 16:9 - 11">
      <div className="absolute bg-gradient-to-b from-[#130b3d] h-[445px] left-[65px] to-[#2271b8] top-[160px] w-[568px]" data-name="Rectangle" />
      <div className="absolute bg-gradient-to-b from-[#f58020] h-[445px] left-[1272px] to-[#f5ebc3] top-[160px] w-[576px]" data-name="Rectangle" />
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal h-[142px] leading-[normal] left-[975px] not-italic text-[#fbeedc] text-[24px] top-[195px] w-[198px]">Azul Neuronal</p>
      <div className="absolute bg-gradient-to-b from-[#2271b8] h-[445px] left-[682px] to-[#5250a2] top-[160px] w-[549px]" data-name="Rectangle" />
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal h-[142px] leading-[normal] left-[91px] not-italic text-[#fbeedc] text-[24px] top-[185px] w-[280px]">Noche Regenerativa</p>
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal h-[142px] leading-[normal] left-[547.5px] not-italic text-[#fbeedc] text-[24px] text-center top-[185px] translate-x-[-50%] w-[151px]">130B3D</p>
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal h-[142px] leading-[normal] left-[516px] not-italic text-[#fbeedc] text-[24px] top-[556px] w-[151px]">2271B8</p>
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal h-[142px] leading-[normal] left-[1130px] not-italic text-[#fbeedc] text-[24px] top-[185px] w-[151px]">2271B8</p>
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal h-[142px] leading-[normal] left-[91px] not-italic text-[#fbeedc] text-[24px] top-[556px] w-[198px]">Claridad Folicular</p>
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal h-[142px] leading-[normal] left-[705px] not-italic text-[#fbeedc] text-[24px] top-[185px] w-[198px]">Claridad Folicular</p>
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal h-[142px] leading-[normal] left-[1114px] not-italic text-[#fbeedc] text-[24px] top-[556px] w-[179px]">5250A2</p>
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal h-[142px] leading-[normal] left-[705px] not-italic text-[#fbeedc] text-[24px] top-[556px] w-[198px]">Poder Intuitivo</p>
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal h-[142px] leading-[normal] left-[1741px] not-italic text-[#130b3d] text-[24px] top-[185px] w-[179px]">5250A2</p>
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal h-[142px] leading-[normal] left-[1293px] not-italic text-[#130b3d] text-[24px] top-[185px] w-[347px]">Energía Ovulatoria</p>
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal h-[142px] leading-[normal] left-[1740px] not-italic text-[#130b3d] text-[24px] top-[561px] w-[179px]">F5EBC3</p>
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal h-[142px] leading-[normal] left-[1293px] not-italic text-[#130b3d] text-[24px] top-[556px] w-[198px]">Lienzo Personal</p>
      <p className="absolute font-['Ninetea:Regular',sans-serif] leading-[43px] left-[1831px] not-italic text-[30px] text-black text-nowrap text-right top-[78px] translate-x-[-100%] whitespace-pre">Gradientes</p>
      <div className="absolute font-['Ninetea:Bold',sans-serif] h-[432px] leading-[0] left-[75px] not-italic text-[0px] text-black top-[632px] w-[548px]">
        <p className="leading-[26px] mb-0 text-[23px]">
          <span className="font-['Inter:Bold',sans-serif] font-bold">{`Pantallas de carga: `}</span>
          <span className="font-['Inter:Regular',sans-serif] font-normal">{`Usarlo al iniciar la app puede simbolizar que Bloom28 "despierta" con la usuaria, procesando sus datos para ofrecerle una guía clara para el día.`}</span>
        </p>
        <p className="leading-[26px] mb-0 text-[23px]">
          <span className="font-['Inter:Bold',sans-serif] font-bold">{`Sección de Descanso: `}</span>
          <span className="font-['Inter:Regular',sans-serif] font-normal">Ideal como fondo para las analíticas de sueño, mostrando la transición de la noche (datos) al día (consejos prácticos para mejorar la recuperación).</span>
        </p>
        <p className="leading-[26px] text-[23px]">
          <span className="font-['Inter:Bold',sans-serif] font-bold">{`Tarjetas de datos (Data Cards): `}</span>
          <span className="font-['Inter:Regular',sans-serif] font-normal">Puede usarse sutilmente en tarjetas que presenten datos biométricos (ej. temperatura basal, RHR) para darles un aspecto tecnológico pero sereno.</span>
        </p>
      </div>
      <div className="absolute font-['Ninetea:Bold',sans-serif] h-[432px] leading-[0] left-[684px] not-italic text-[0px] text-black top-[632px] w-[548px]">
        <p className="leading-[26px] mb-0 text-[23px]">
          <span className="font-['Inter:Bold',sans-serif] font-bold">{`Acompañamiento Emocional: `}</span>
          <span className="font-['Inter:Regular',sans-serif] font-normal">{`Perfecto para la interfaz donde la usuaria registra sus emociones mediante texto o voz (NLP). El gradiente refuerza la idea de que la app está "escuchando" y conectando con su estado anímico.`}</span>
        </p>
        <p className="leading-[26px] mb-0 text-[23px]">
          <span className="font-['Inter:Bold',sans-serif] font-bold">{`Insights y Reportes: `}</span>
          <span className="font-['Inter:Regular',sans-serif] font-normal">Utilícenlo en las pantallas que resumen los patrones del ciclo. El paso del azul (claridad) al púrpura (intuición) comunica visualmente que se está revelando un conocimiento más profundo sobre sí misma.</span>
        </p>
        <p className="leading-[26px] text-[23px]">
          <span className="font-['Inter:Bold',sans-serif] font-bold">{`Contenido de Mindfulness: `}</span>
          <span className="font-['Inter:Regular',sans-serif] font-normal">Como fondo para las recomendaciones de meditación o ejercicios de autoconocimiento, fortaleciendo la conexión mente-cuerpo.</span>
        </p>
      </div>
      <div className="absolute font-['Ninetea:Bold',sans-serif] h-[432px] leading-[0] left-[1272px] not-italic text-[0px] text-black top-[632px] w-[548px]">
        <p className="leading-[26px] mb-0 text-[23px]">
          <span className="font-['Inter:Bold',sans-serif] font-bold">{`Recomendaciones de Entrenamiento: `}</span>
          <span className="font-['Inter:Regular',sans-serif] font-normal">{`Es ideal para esta sección. Pueden usar la parte más intensa del naranja ("Energía Ovulatoria") para destacar los entrenamientos de alta intensidad sugeridos en la fase folicular tardía u ovulatoria.`}</span>
        </p>
        <p className="leading-[26px] mb-0 text-[23px]">
          <span className="font-['Inter:Bold',sans-serif] font-bold">{`Botones y Call-to-Action (CTAs): `}</span>
          <span className="font-['Inter:Regular',sans-serif] font-normal">{`Su alta visibilidad lo hace perfecto para botones principales como "Registrar mi día" o "Ver mi plan de hoy", impulsando la interacción.`}</span>
        </p>
        <p className="leading-[26px] text-[23px]">
          <span className="font-['Inter:Bold',sans-serif] font-bold">{`Dashboard Dinámico: `}</span>
          <span className="font-['Inter:Regular',sans-serif] font-normal">La aplicación podría mostrar este gradiente de forma más o menos intensa en el dashboard principal según el nivel de energía predicho para la usuaria ese día, convirtiendo la interfaz en un reflejo visual de su estado físico.</span>
        </p>
      </div>
    </div>
  );
}
export default function Slide() {
  return (
    <div className="relative size-full" data-name="Slide 16:9 - 9">
      <p className="absolute font-['Ninetea:Regular',sans-serif] leading-[43px] left-[1856px] not-italic text-[30px] text-black text-nowrap text-right top-[79px] translate-x-[-100%] whitespace-pre">Paleta de color</p>
      <p className="absolute font-['Ninetea:Regular',sans-serif] h-[246px] leading-[43px] left-[75px] not-italic text-[30px] text-black top-[216px] w-[1781px]">
        <span className="font-['Inter:Bold',sans-serif] font-bold">Uso de la paleta de color:</span>
        <span className="font-['Inter:Regular',sans-serif] font-normal">{` "Noche Regenerativa" y "Lienzo Personal" como colores base para fondos y textos, para asegurar una buena legibilidad. "Claridad Folicular" y "Poder Intuitivo" pueden usarse para elementos de interfaz, botones y gráficos informativos. "Energía Ovulatoria" debería reservarse para los call-to-action más importantes, notificaciones de picos de energía o logros.`}</span>
      </p>
      <div className="absolute bg-[#130b3d] h-[524px] left-[75px] top-[484px] w-[516px]" data-name="Rectangle" />
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal h-[142px] leading-[normal] left-[110px] not-italic text-[#fbeedc] text-[34px] top-[938px] w-[151px]">130B3D</p>
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal h-[142px] leading-[normal] left-[110px] not-italic text-[#fbeedc] text-[34px] top-[849px] w-[280px]">Noche Regenerativa</p>
      <div className="absolute bg-[#2271b8] h-[524px] left-[591px] top-[484px] w-[377px]" data-name="Rectangle" />
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal h-[142px] leading-[normal] left-[625px] not-italic text-[#fbeedc] text-[34px] top-[938px] w-[151px]">2271B8</p>
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal h-[142px] leading-[normal] left-[625px] not-italic text-[#fbeedc] text-[34px] top-[849px] w-[198px]">Claridad Folicular</p>
      <div className="absolute bg-[#5250a2] h-[524px] left-[968px] top-[484px] w-[317px]" data-name="Rectangle" />
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal h-[142px] leading-[normal] left-[997px] not-italic text-[#fbeedc] text-[34px] top-[938px] w-[179px]">5250A2</p>
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal h-[142px] leading-[normal] left-[997px] not-italic text-[#fbeedc] text-[34px] top-[849px] w-[198px]">Poder Intuitivo</p>
      <div className="absolute bg-[#f58020] h-[524px] left-[1285px] top-[484px] w-[315px]" data-name="Rectangle" />
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal h-[142px] leading-[normal] left-[1317px] not-italic text-[#130b3d] text-[34px] top-[938px] w-[179px]">5250A2</p>
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal h-[142px] leading-[normal] left-[1317px] not-italic text-[#130b3d] text-[34px] top-[849px] w-[198px]">Energía Ovulatoria</p>
      <div className="absolute bg-[#f5ebc3] h-[524px] left-[1600px] top-[484px] w-[256px]" data-name="Rectangle" />
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal h-[142px] leading-[normal] left-[1638px] not-italic text-[#130b3d] text-[34px] top-[938px] w-[179px]">F5EBC3</p>
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal h-[142px] leading-[normal] left-[1645px] not-italic text-[#130b3d] text-[34px] top-[849px] w-[198px]">Lienzo Personal</p>
    </div>
  );
}
import svgPaths from "./svg-nb1k2hgc5x";

function VuesaxLinearArrowSquareLeft() {
  return (
    <div className="absolute contents inset-0" data-name="vuesax/linear/arrow-square-left">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 40 40">
        <g id="arrow-square-left">
          <path d={svgPaths.p3647d300} id="Vector" stroke="var(--stroke-0, #BDBDBD)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d={svgPaths.pe03b900} id="Vector_2" stroke="var(--stroke-0, #292929)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <g id="Vector_3" opacity="0"></g>
        </g>
      </svg>
    </div>
  );
}

function VuesaxLinearArrowSquareLeft1() {
  return (
    <div className="relative shrink-0 size-[40px]" data-name="vuesax/linear/arrow-square-left">
      <VuesaxLinearArrowSquareLeft />
    </div>
  );
}

function Frame2() {
  return (
    <div className="absolute content-stretch flex items-center justify-center left-[40px] top-[8px] w-[265px]">
      <div className="basis-0 flex flex-col font-['Poppins:Medium',sans-serif] grow justify-center leading-[0] min-h-px min-w-px not-italic relative shrink-0 text-[#121212] text-[18px] text-center">
        <p className="leading-[24px]">&nbsp;</p>
      </div>
    </div>
  );
}

function TitleSection() {
  return (
    <div className="content-stretch flex h-[40px] items-center justify-between px-0 py-px relative shrink-0 w-[345px]" data-name="Title Section">
      <VuesaxLinearArrowSquareLeft1 />
      <Frame2 />
    </div>
  );
}

function Frame() {
  return (
    <div className="content-stretch flex flex-col items-center justify-center relative shrink-0 w-full">
      <TitleSection />
    </div>
  );
}

function Frame1() {
  return (
    <div className="absolute content-stretch flex flex-col items-start left-[24px] top-[68px] w-[345px]">
      <Frame />
    </div>
  );
}

function Text() {
  return (
    <div className="absolute contents left-[42.23px] right-[26.73px] top-[180.68px]" data-name="Text">
      <div className="absolute font-['Ninetea:Bold',sans-serif] leading-[1.3] left-[42.23px] not-italic right-[26.73px] text-[#fbeedc] text-[30.434px] top-[180.68px] tracking-[-0.3043px]">
        <p className="mb-[2.01437px] text-[#f58020]">{`Bienvenida! `}</p>
        <p className="text-[#130b3d]">Nos alegra verte otra vez!</p>
      </div>
    </div>
  );
}

function Group() {
  return (
    <div className="absolute inset-[24.13%_10%]" data-name="Group">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 18 12">
        <g id="Group">
          <path d={svgPaths.p37ea0d00} fill="var(--fill-0, #130B3D)" id="Vector" />
        </g>
      </svg>
    </div>
  );
}

function FluentEye20Filled() {
  return (
    <div className="absolute left-[328.1px] overflow-clip rounded-[27.698px] size-[22.158px] top-[438.49px]" data-name="fluent:eye-20-filled">
      <Group />
    </div>
  );
}

function EnterYourPasswordInput() {
  return (
    <div className="absolute contents left-[33px] top-[421.37px]" data-name="Enter your password (Input)">
      <div className="absolute bg-[rgba(255,255,255,0.42)] border-[1.007px] border-solid border-white h-[56.402px] left-[33px] rounded-[27.698px] top-[421.37px] w-[333.378px]" />
      <FluentEye20Filled />
      <div className="absolute flex flex-col font-['Ninetea:Medium',sans-serif] justify-end leading-[0] left-[51.13px] not-italic text-[#130b3d] text-[13.093px] text-nowrap top-[458.52px] translate-y-[-100%]">
        <p className="leading-[1.25] whitespace-pre">Contraseña</p>
      </div>
    </div>
  );
}

function EnterYourEmailInput() {
  return (
    <div className="absolute contents left-[33px] top-[349.86px]" data-name="Enter your email (Input)">
      <div className="absolute bg-[rgba(255,255,255,0.42)] border-[1.007px] border-solid border-white h-[56.402px] left-[33px] rounded-[27.698px] top-[349.86px] w-[333.378px]" />
      <div className="absolute flex flex-col font-['Ninetea:Medium',sans-serif] justify-end leading-[0] left-[51.13px] not-italic text-[#130b3d] text-[13.093px] text-nowrap top-[387.01px] translate-y-[-100%]">
        <p className="leading-[1.25] whitespace-pre">Email</p>
      </div>
    </div>
  );
}

function RegisterButton() {
  return (
    <div className="absolute contents left-[calc(50%+3.27px)] top-[566.48px] translate-x-[-50%]" data-name="Register (Button)">
      <div className="absolute bg-[#f58020] inset-[66.49%_6.8%_27.94%_8.47%] rounded-[27.698px]" />
      <p className="absolute font-['Ninetea:Semi_Bold',sans-serif] h-[19.693px] leading-[normal] left-[calc(50%+1.86px)] not-italic text-[#fbeedc] text-[15.108px] text-center top-[581.7px] translate-x-[-50%] w-[99.328px]">Ingresar</p>
    </div>
  );
}

function Group1() {
  return (
    <div className="absolute contents left-[33px] top-[calc(50%-28.7px)] translate-y-[-50%]">
      <Text />
      <EnterYourPasswordInput />
      <EnterYourEmailInput />
      <RegisterButton />
      <div className="absolute flex flex-col font-['Ninetea:Semi_Bold',sans-serif] justify-end leading-[0] left-[365.6px] not-italic text-[#130b3d] text-[12.086px] text-nowrap text-right top-[509.89px] translate-x-[-100%] translate-y-[-100%]">
        <p className="leading-[normal] whitespace-pre">Olvidaste tu contraseña?</p>
      </div>
    </div>
  );
}

function HomeIndicator() {
  return (
    <div className="absolute bottom-0 h-[34px] left-1/2 translate-x-[-50%] w-[393px]" data-name="Home Indicator">
      <div className="absolute h-[34px] left-0 right-0 top-0" data-name="Background" />
      <div className="absolute bottom-[7.67px] flex h-[5px] items-center justify-center left-1/2 translate-x-[-50%] w-[139.938px]">
        <div className="flex-none rotate-[180deg] scale-y-[-100%]">
          <div className="bg-[#121212] h-[5px] rounded-[100px] w-[139.938px]" data-name="Home Indicator" />
        </div>
      </div>
    </div>
  );
}

function IOsIconSmallMobileSignal() {
  return (
    <div className="h-[16px] relative shrink-0 w-[20px]" data-name="iOS / icon / small / Mobile Signal">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 16">
        <g id="iOS / icon / small / Mobile Signal">
          <path d={svgPaths.p15d4ae30} fill="var(--fill-0, #121212)" id="icon" />
        </g>
      </svg>
    </div>
  );
}

function IOsIconSmallWifi() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="iOS / icon / small / Wifi">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="iOS / icon / small / Wifi">
          <path d={svgPaths.p382fcb80} fill="var(--fill-0, #121212)" id="icon" />
        </g>
      </svg>
    </div>
  );
}

function IOsIconSmallBattery() {
  return (
    <div className="h-[16px] relative shrink-0 w-[25px]" data-name="iOS / icon / small / battery">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 25 16">
        <g clipPath="url(#clip0_8_2169)" id="iOS / icon / small / battery">
          <path d={svgPaths.p15509f50} id="outline border" opacity="0.35" stroke="var(--stroke-0, #121212)" />
          <path d={svgPaths.p307e0200} fill="var(--fill-0, #121212)" id="node" opacity="0.4" />
          <path d={svgPaths.p365f7580} fill="var(--fill-0, #121212)" id="charge" />
        </g>
        <defs>
          <clipPath id="clip0_8_2169">
            <rect fill="white" height="16" width="25" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function IOsIconStatusBar() {
  return (
    <div className="absolute content-stretch flex gap-[2px] items-start right-[15px] top-[15px]" data-name="iOS / icon / status-bar">
      <IOsIconSmallMobileSignal />
      <IOsIconSmallWifi />
      <IOsIconSmallBattery />
    </div>
  );
}

function StatusBar() {
  return (
    <div className="absolute h-[44px] left-0 overflow-clip top-0 w-[393px]" data-name="Status bar">
      <div className="absolute h-[30px] left-1/2 top-[-2px] translate-x-[-50%] w-[219px]" data-name="notch">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 219 30">
          <path d={svgPaths.p7f98200} fill="var(--fill-0, #121212)" id="notch" />
        </svg>
      </div>
      <p className="absolute font-['SF_Pro_Text:Semibold',sans-serif] leading-[21px] left-[32px] not-italic text-[#121212] text-[15px] text-nowrap top-[13px] tracking-[-0.32px] whitespace-pre">9:41</p>
      <IOsIconStatusBar />
    </div>
  );
}

export default function ContinueWithEmail() {
  return (
    <div className="bg-gradient-to-b from-[#ffe0c6] overflow-clip relative rounded-[32px] size-full to-[#f5ebc3]" data-name="Continue With Email">
      <StatusBar />
      <div className="absolute flex inset-[3.29%_-26.93%_65.95%_67.18%] items-center justify-center">
        <div className="flex-none h-[179.29px] rotate-[226.129deg] skew-x-[6.174deg] w-[172.813px]">
          <div className="relative size-full">
            <div className="absolute inset-[-83.66%_-86.8%]">
              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 473 480">
                <g filter="url(#filter0_f_8_2194)" id="Ellipse 7" opacity="0.8">
                  <ellipse cx="236.407" cy="239.645" fill="var(--fill-0, #FD587A)" fillOpacity="0.24" rx="86.4067" ry="89.6449" />
                </g>
                <defs>
                  <filter colorInterpolationFilters="sRGB" filterUnits="userSpaceOnUse" height="479.29" id="filter0_f_8_2194" width="472.813" x="0" y="0">
                    <feFlood floodOpacity="0" result="BackgroundImageFix" />
                    <feBlend in="SourceGraphic" in2="BackgroundImageFix" mode="normal" result="shape" />
                    <feGaussianBlur result="effect1_foregroundBlur_8_2194" stdDeviation="75" />
                  </filter>
                </defs>
              </svg>
            </div>
          </div>
        </div>
      </div>
      <p className="absolute font-['Poppins:Regular',sans-serif] leading-[0] left-[196.5px] not-italic text-[#121212] text-[0px] text-[12px] text-center text-nowrap top-[910px] translate-x-[-50%] whitespace-pre">
        <span className="capitalize leading-[1.3]">Already have an Account?</span>
        <span className="leading-[18px]"> </span>
        <span className="capitalize font-['Poppins:Medium',sans-serif] leading-[18px] text-blue-500">Login</span>
      </p>
      <Frame1 />
      <Group1 />
      <div className="absolute font-['Poppins:SemiBold',sans-serif] leading-[1.4] left-[calc(50%+2.26px)] not-italic text-[0px] text-[16.112px] text-center text-nowrap text-white top-[756.24px] tracking-[0.1611px] translate-x-[-50%] whitespace-pre">
        <p className="font-['Ninetea:Medium',sans-serif] mb-0">
          <span className="text-[#130b3d]">No tienes una cuenta?</span>{" "}
        </p>
        <p className="font-['Ninetea:Bold',sans-serif] text-[#f58020]">Regístrate Ahora</p>
      </div>
      <p className="absolute font-['Gebuk:Regular',sans-serif] leading-[normal] left-[199.7px] not-italic text-[#130b3d] text-[63.629px] text-center text-nowrap top-[67px] translate-x-[-50%] whitespace-pre">8</p>
      <HomeIndicator />
    </div>
  );
}
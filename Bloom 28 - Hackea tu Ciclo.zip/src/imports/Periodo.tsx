import svgPaths from "./svg-i764xgpwgl";

function VuesaxLinearArrowSquareLeft() {
  return (
    <div className="absolute contents inset-0" data-name="vuesax/linear/arrow-square-left">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 40 40">
        <g id="arrow-square-left">
          <path d={svgPaths.p3647d300} id="Vector" stroke="var(--stroke-0, #BDBDBD)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <path d={svgPaths.pe03b900} id="Vector_2" stroke="var(--stroke-0, #292929)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
          <g id="Vector_3" opacity="0"></g>
        </g>
      </svg>
    </div>
  );
}

function VuesaxLinearArrowSquareLeft1() {
  return (
    <div className="relative shrink-0 size-[40px]" data-name="vuesax/linear/arrow-square-left">
      <VuesaxLinearArrowSquareLeft />
    </div>
  );
}

function Frame2() {
  return (
    <div className="absolute content-stretch flex items-center justify-center left-[40px] top-[8px] w-[265px]">
      <div className="basis-0 flex flex-col font-['Poppins:Medium',sans-serif] grow justify-center leading-[0] min-h-px min-w-px not-italic relative shrink-0 text-[#121212] text-[18px] text-center">
        <p className="leading-[24px]">&nbsp;</p>
      </div>
    </div>
  );
}

function TitleSection() {
  return (
    <div className="content-stretch flex h-[40px] items-center justify-between px-0 py-px relative shrink-0 w-[345px]" data-name="Title Section">
      <VuesaxLinearArrowSquareLeft1 />
      <Frame2 />
    </div>
  );
}

function Frame() {
  return (
    <div className="content-stretch flex flex-col items-center justify-center relative shrink-0 w-full">
      <TitleSection />
    </div>
  );
}

function Frame1() {
  return (
    <div className="absolute content-stretch flex flex-col items-start left-[24px] top-[68px] w-[345px]">
      <Frame />
    </div>
  );
}

function RegisterButton() {
  return (
    <div className="absolute contents left-[calc(50%+0.3px)] top-[750px] translate-x-[-50%]" data-name="Register (Button)">
      <div className="absolute bg-[#f58020] inset-[88.03%_6.72%_5.75%_6.87%] rounded-[30.943px]" />
      <p className="absolute font-['Ninetea:Semi_Bold',sans-serif] h-[22px] leading-[normal] left-[calc(50%-1.15px)] not-italic text-[#fbeedc] text-[16.878px] text-center top-[767px] translate-x-[-50%] w-[101.301px]">{`Continuar `}</p>
      <div className="absolute h-[12px] left-[244.9px] top-[772px] w-[5.477px]">
        <div className="absolute inset-[-5.62%_-5.33%_-5.62%_-13.48%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 7 14">
            <path d={svgPaths.p1773d800} id="Vector 33" stroke="var(--stroke-0, #FBEEDC)" strokeWidth="2" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Text() {
  return (
    <div className="absolute contents left-[29.39px] right-[27.88px] top-[146px]" data-name="Text">
      <div className="absolute font-['Ninetea:Bold',sans-serif] h-[78.723px] leading-[1.3] left-[29.39px] not-italic right-[27.88px] text-[#fbeedc] text-[0px] text-center top-[146px] tracking-[-0.34px]">
        <p className="mb-[2.250382423400879px] text-[#f58020] text-[30px]">Tu Ciclo Menstrual</p>
        <p className="font-['Inter:Regular',sans-serif] font-normal text-[#130b3d] text-[14px]">Ayúdanos a entender tu ciclo para mejores predicciones</p>
      </div>
    </div>
  );
}

function EnterYourEmailInput() {
  return (
    <div className="absolute contents left-[24px] top-[651.6px]" data-name="Enter your email (Input)">
      <div className="absolute h-[75.397px] left-[24px] top-[651.6px] w-[345px]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 345 76">
          <path d={svgPaths.p35a1f00} fill="url(#paint0_linear_24_1300)" id="Rectangle 4" opacity="0.5" stroke="var(--stroke-0, #FBEEDC)" strokeWidth="1.12519" />
          <defs>
            <linearGradient gradientUnits="userSpaceOnUse" id="paint0_linear_24_1300" x1="172.964" x2="172.964" y1="75.397" y2="4.39697">
              <stop stopColor="#FFF2E3" />
              <stop offset="1" stopColor="#F7BE7E" />
            </linearGradient>
          </defs>
        </svg>
      </div>
      <div className="absolute flex flex-col font-['Inter:Regular',sans-serif] font-normal h-[40.539px] justify-end leading-[0] left-[192.33px] not-italic text-[12.63px] text-center text-white top-[716.54px] translate-x-[-50%] translate-y-[-100%] w-[307.903px]">
        <p className="leading-[1.25]">
          <span>{`💡 `}</span>
          <span className="text-[#130b3d]">No te preocupes si no conoces estos datos con exactitud. Puedes ajustarlos más tarde con los datos de tus Wearables</span>
        </p>
      </div>
    </div>
  );
}

function Group1() {
  return (
    <div className="absolute contents left-[24px] top-[146px]">
      <Text />
      <EnterYourEmailInput />
    </div>
  );
}

function Group() {
  return (
    <div className="absolute contents left-[94px] top-[105px]">
      <div className="absolute bg-[#f58020] h-[5px] left-[94px] rounded-[51px] top-[105px] w-[47.471px]" />
      <div className="absolute bg-[#f58020] h-[5px] left-[148.77px] rounded-[51px] top-[105px] w-[47.471px]" />
      <div className="absolute bg-[#f58020] h-[5px] left-[203.55px] rounded-[51px] top-[105px] w-[47.471px]" />
      <div className="absolute bg-[#f58020] h-[5px] left-[258.32px] rounded-[51px] top-[105px] w-[47.471px]" />
    </div>
  );
}

function HomeIndicator() {
  return (
    <div className="absolute bottom-0 h-[34px] left-1/2 translate-x-[-50%] w-[393px]" data-name="Home Indicator">
      <div className="absolute h-[34px] left-0 right-0 top-0" data-name="Background" />
      <div className="absolute bottom-[7.67px] flex h-[5px] items-center justify-center left-1/2 translate-x-[-50%] w-[139.938px]">
        <div className="flex-none rotate-[180deg] scale-y-[-100%]">
          <div className="bg-[#121212] h-[5px] rounded-[100px] w-[139.938px]" data-name="Home Indicator" />
        </div>
      </div>
    </div>
  );
}

function IOsIconSmallMobileSignal() {
  return (
    <div className="h-[16px] relative shrink-0 w-[20px]" data-name="iOS / icon / small / Mobile Signal">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 16">
        <g id="iOS / icon / small / Mobile Signal">
          <path d={svgPaths.p15d4ae30} fill="var(--fill-0, #121212)" id="icon" />
        </g>
      </svg>
    </div>
  );
}

function IOsIconSmallWifi() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="iOS / icon / small / Wifi">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="iOS / icon / small / Wifi">
          <path d={svgPaths.p382fcb80} fill="var(--fill-0, #121212)" id="icon" />
        </g>
      </svg>
    </div>
  );
}

function IOsIconSmallBattery() {
  return (
    <div className="h-[16px] relative shrink-0 w-[25px]" data-name="iOS / icon / small / battery">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 25 16">
        <g clipPath="url(#clip0_24_1287)" id="iOS / icon / small / battery">
          <path d={svgPaths.p15509f50} id="outline border" opacity="0.35" stroke="var(--stroke-0, #121212)" />
          <path d={svgPaths.p307e0200} fill="var(--fill-0, #121212)" id="node" opacity="0.4" />
          <path d={svgPaths.p365f7580} fill="var(--fill-0, #121212)" id="charge" />
        </g>
        <defs>
          <clipPath id="clip0_24_1287">
            <rect fill="white" height="16" width="25" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function IOsIconStatusBar() {
  return (
    <div className="absolute content-stretch flex gap-[2px] items-start right-[15px] top-[15px]" data-name="iOS / icon / status-bar">
      <IOsIconSmallMobileSignal />
      <IOsIconSmallWifi />
      <IOsIconSmallBattery />
    </div>
  );
}

function StatusBar() {
  return (
    <div className="absolute h-[44px] left-0 overflow-clip top-0 w-[393px]" data-name="Status bar">
      <div className="absolute h-[30px] left-1/2 top-[-2px] translate-x-[-50%] w-[219px]" data-name="notch">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 219 30">
          <path d={svgPaths.p7f98200} fill="var(--fill-0, #121212)" id="notch" />
        </svg>
      </div>
      <p className="absolute font-['SF_Pro_Text:Semibold',sans-serif] leading-[21px] left-[32px] not-italic text-[#121212] text-[15px] text-nowrap top-[13px] tracking-[-0.32px]">9:41</p>
      <IOsIconStatusBar />
    </div>
  );
}

export default function Periodo() {
  return (
    <div className="bg-gradient-to-b from-[#ffe0c6] overflow-clip relative rounded-[32px] size-full to-[#f5ebc3]" data-name="periodo">
      <StatusBar />
      <div className="absolute flex inset-[3.29%_-26.93%_65.95%_67.18%] items-center justify-center">
        <div className="flex-none h-[179.29px] rotate-[226.129deg] skew-x-[6.174deg] w-[172.813px]">
          <div className="relative size-full">
            <div className="absolute inset-[-83.66%_-86.8%]">
              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 473 480">
                <g filter="url(#filter0_f_24_1314)" id="Ellipse 7" opacity="0.8">
                  <ellipse cx="236.407" cy="239.645" fill="var(--fill-0, #FD587A)" fillOpacity="0.24" rx="86.4067" ry="89.6449" />
                </g>
                <defs>
                  <filter colorInterpolationFilters="sRGB" filterUnits="userSpaceOnUse" height="479.29" id="filter0_f_24_1314" width="472.813" x="0" y="0">
                    <feFlood floodOpacity="0" result="BackgroundImageFix" />
                    <feBlend in="SourceGraphic" in2="BackgroundImageFix" mode="normal" result="shape" />
                    <feGaussianBlur result="effect1_foregroundBlur_24_1314" stdDeviation="75" />
                  </filter>
                </defs>
              </svg>
            </div>
          </div>
        </div>
      </div>
      <p className="absolute font-['Poppins:Regular',sans-serif] leading-[0] left-[196.5px] not-italic text-[#121212] text-[0px] text-[12px] text-center text-nowrap top-[910px] translate-x-[-50%]">
        <span className="capitalize leading-[1.3]">Already have an Account?</span>
        <span className="leading-[18px]"> </span>
        <span className="capitalize font-['Poppins:Medium',sans-serif] leading-[18px] text-[#3b82f6]">Login</span>
      </p>
      <Frame1 />
      <RegisterButton />
      <Group1 />
      <Group />
      <HomeIndicator />
    </div>
  );
}
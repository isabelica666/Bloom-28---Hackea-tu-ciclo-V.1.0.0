export type CyclePhase = 'menstrual' | 'folicular' | 'ovulación' | 'lútea';

export function getCyclePhase(): CyclePhase {
  // Simulación basada en el día actual del mes
  const today = new Date().getDate();
  const dayInCycle = today % 28 || 28;

  if (dayInCycle <= 5) return 'menstrual';
  if (dayInCycle <= 12) return 'folicular';
  if (dayInCycle <= 15) return 'ovulación';
  return 'lútea';
}

export function getDaysInPhase(): number {
  const today = new Date().getDate();
  const dayInCycle = today % 28 || 28;

  if (dayInCycle <= 5) return dayInCycle;
  if (dayInCycle <= 12) return dayInCycle - 5;
  if (dayInCycle <= 15) return dayInCycle - 12;
  return dayInCycle - 15;
}

export function getDaysUntilNextPhase(): number {
  const today = new Date().getDate();
  const dayInCycle = today % 28 || 28;

  if (dayInCycle <= 5) return 6 - dayInCycle;
  if (dayInCycle <= 12) return 13 - dayInCycle;
  if (dayInCycle <= 15) return 16 - dayInCycle;
  return 29 - dayInCycle;
}

type CyclePhase = 'menstrual' | 'folicular' | 'ovulacion' | 'lutea';

export interface BiometricValues {
  temperature: number;
  heartRate: number;
  sleepQuality: number;
  sleepHours: number;
  sleepDuration: number;  // Alias para compatibilidad con Dashboard
}

// Valores base según la fase del ciclo
const phaseBaselines: Record<CyclePhase, BiometricValues> = {
  menstrual: {
    temperature: 36.2,
    heartRate: 68,
    sleepQuality: 75,
    sleepHours: 7.8,
    sleepDuration: 7.8
  },
  folicular: {
    temperature: 36.3,
    heartRate: 65,
    sleepQuality: 85,
    sleepHours: 8.2,
    sleepDuration: 8.2
  },
  ovulacion: {
    temperature: 36.6,
    heartRate: 70,
    sleepQuality: 88,
    sleepHours: 8.0,
    sleepDuration: 8.0
  },
  lutea: {
    temperature: 36.7,
    heartRate: 67,
    sleepQuality: 80,
    sleepHours: 7.5,
    sleepDuration: 7.5
  }
};

/**
 * Normaliza el nombre de la fase al formato esperado
 */
function normalizePhase(phase: any): CyclePhase {
  if (!phase || typeof phase !== 'string') {
    return 'folicular'; // Valor por defecto
  }
  
  const normalizedPhase = phase.toLowerCase();
  
  // Mapeo de posibles variaciones
  if (normalizedPhase === 'menstrual' || normalizedPhase === 'menstruación') return 'menstrual';
  if (normalizedPhase === 'folicular' || normalizedPhase === 'follicular') return 'folicular';
  if (normalizedPhase === 'ovulacion' || normalizedPhase === 'ovulación') return 'ovulacion';
  if (normalizedPhase === 'lutea' || normalizedPhase === 'lútea') return 'lutea';
  
  // Valor por defecto si no coincide
  return 'folicular';
}

/**
 * Obtiene los valores biométricos actuales según la fase del ciclo
 */
export function getCurrentBiometrics(phase: any): BiometricValues {
  const normalizedPhase = normalizePhase(phase);
  return phaseBaselines[normalizedPhase];
}

/**
 * Genera datos de los últimos 7 días con variación natural
 */
export function generateLast7DaysData(phase: any) {
  const normalizedPhase = normalizePhase(phase);
  const baseline = phaseBaselines[normalizedPhase];
  
  if (!baseline) {
    // Fallback en caso de error
    console.error('Phase not found:', phase, 'normalized:', normalizedPhase);
    return [];
  }
  
  const days: Date[] = [];
  const today = new Date();
  
  for (let i = 6; i >= 0; i--) {
    const date = new Date(today);
    date.setDate(today.getDate() - i);
    days.push(date);
  }
  
  return days.map((date) => {
    const formatDate = (d: Date): string => {
      const day = d.getDate();
      const month = d.getMonth() + 1;
      return `${day}/${month}`;
    };

    return {
      day: formatDate(date),
      temp: Number((baseline.temperature + (Math.random() * 0.2 - 0.1)).toFixed(1)),
      heartRate: baseline.heartRate + Math.floor(Math.random() * 4 - 2),
      heartRateSleep: baseline.heartRate - 8 + Math.floor(Math.random() * 3 - 1),
      sleepQuality: Math.min(100, Math.max(0, baseline.sleepQuality + Math.floor(Math.random() * 10 - 5))),
      sleepHours: Number((baseline.sleepHours + (Math.random() * 0.6 - 0.3)).toFixed(1)),
      sleepDuration: Number((baseline.sleepDuration + (Math.random() * 0.6 - 0.3)).toFixed(1))
    };
  });
}

/**
 * Calcula promedios de los últimos 7 días
 */
export function calculateAverages(data: ReturnType<typeof generateLast7DaysData>) {
  if (!data || data.length === 0) {
    // Valores por defecto si no hay datos
    return {
      avgTemp: '36.3',
      avgHeartRate: 65,
      avgSleepQuality: 85,
      avgSleepHours: '8.0'
    };
  }
  
  const avgTemp = (data.reduce((sum, d) => sum + d.temp, 0) / data.length).toFixed(1);
  const avgHeartRate = Math.round(data.reduce((sum, d) => sum + d.heartRate, 0) / data.length);
  const avgSleepQuality = Math.round(data.reduce((sum, d) => sum + d.sleepQuality, 0) / data.length);
  const avgSleepHours = (data.reduce((sum, d) => sum + d.sleepHours, 0) / data.length).toFixed(1);
  
  return {
    avgTemp,
    avgHeartRate,
    avgSleepQuality,
    avgSleepHours
  };
}
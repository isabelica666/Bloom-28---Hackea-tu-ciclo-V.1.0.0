export interface CycleData {
  lastPeriodDate: string;
  cycleDuration: number;
  periodDuration: number;
}

export interface CycleInfo {
  currentDay: number;
  currentPhase: 'menstrual' | 'follicular' | 'ovulation' | 'luteal';
  daysUntilNextPeriod: number;
  nextPeriodDate: Date;
}

export function calculateCycleInfo(cycleData: CycleData): CycleInfo {
  const lastPeriod = new Date(cycleData.lastPeriodDate);
  const today = new Date();
  
  // Calculate days since last period started
  const daysSinceLastPeriod = Math.floor((today.getTime() - lastPeriod.getTime()) / (1000 * 60 * 60 * 24));
  
  // Calculate current day in cycle (1-28 or custom cycle length)
  const currentDay = (daysSinceLastPeriod % cycleData.cycleDuration) + 1;
  
  // Calculate days until next period
  const daysUntilNextPeriod = cycleData.cycleDuration - currentDay + 1;
  
  // Calculate next period date
  const nextPeriodDate = new Date(lastPeriod);
  nextPeriodDate.setDate(lastPeriod.getDate() + cycleData.cycleDuration * Math.floor(daysSinceLastPeriod / cycleData.cycleDuration + 1));
  
  // Determine current phase
  let currentPhase: 'menstrual' | 'follicular' | 'ovulation' | 'luteal';
  
  if (currentDay <= cycleData.periodDuration) {
    currentPhase = 'menstrual';
  } else if (currentDay <= Math.floor(cycleData.cycleDuration / 2) - 2) {
    currentPhase = 'follicular';
  } else if (currentDay <= Math.floor(cycleData.cycleDuration / 2) + 2) {
    currentPhase = 'ovulation';
  } else {
    currentPhase = 'luteal';
  }
  
  return {
    currentDay,
    currentPhase,
    daysUntilNextPeriod,
    nextPeriodDate
  };
}

export function getPhaseName(phase: 'menstrual' | 'follicular' | 'ovulation' | 'luteal'): string {
  const phaseNames = {
    menstrual: 'Menstrual',
    follicular: 'Folicular',
    ovulation: 'Ovulación',
    luteal: 'Lútea'
  };
  return phaseNames[phase];
}

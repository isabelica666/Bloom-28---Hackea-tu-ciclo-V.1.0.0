
  # Bloom 28 - Hackea tu Ciclo

  This is a code bundle for Bloom 28 - Hackea tu Ciclo. The original project is available at https://www.figma.com/design/6je830810G2w6xdp5nVfjs/Bloom-28---Hackea-tu-Ciclo.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  